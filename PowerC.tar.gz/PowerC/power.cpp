
// ##################################################################################
// #################################################################################
// COSMICATLASS
// COSMologIcal
// CATalogs for
// LArge
// Scale
// Structure
# include "FileOutput.h"
# include "PowerSpectrumF.h"
# include "NumericalMethods.h"
using namespace std;

// ##################################################################################
// ##################################################################################

int main(int argc, char *argv[]){

  time_t start_all;
  time(&start_all);
  char temp;
  string par_file_bam;

  int NTHREADS=omp_get_max_threads();
  omp_set_num_threads(NTHREADS);

  ScreenOutput So(start_all);

  if(argc==1){
    So.usage(argv[0]);
    exit(1);
  }
  while((temp =  getopt(argc, argv, "ha:p:")) != -1)
    {
      if(temp=='h')
        So.usage(argv[0]);

      else if (temp=='a')  // Show authors
        So.author();



      else if(temp=='p')   // to mesure Power spectrum
        {
#ifndef _POWER_
        So.message_warning("Pre-processor directive _POWER_ IS NOT defined. Please define it in def.h");
        exit(0);
#endif
          So.message(start_all);
          par_file_bam = argv[2];
          Params params(par_file_bam);
          PowerSpectrumF cPSF(params);
          cPSF.compute_power_spectrum(true,false);
#ifdef _USE_REDSHIFT_BINS_
          if(params._sys_of_coord_g()==0)
          {
              So.message_warning("Asking for redshift bins while providing cartessian coordinates. Check input parameter file and def.h");
              exit(0);
          }
#endif

          So.message_time(start_all);
        }
    }


  return 0;
}
