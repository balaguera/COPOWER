#include "Catalog.h"

// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //

// This is the last function aded, Sep 24 2020
// Meant to analyze the cat, and to be run under the option (updated at the same date) -c at executation time
void Catalog::analyze_cat(){
    this->So.enter(__PRETTY_FUNCTION__);
#if defined (_USE_ALL_PK_) || defined (_USE_MASS_CUTS_PK_)
    this->read_catalog(this->params._Input_dir_cat()+this->params._file_catalogue(),pow(10,this->params._LOGMASSmin()));
#else
    this->read_catalog(this->params._Input_dir_cat()+this->params._file_catalogue(),pow(10,this->params._LOGMASSmin()),pow(10,this->params._LOGMASSmax()));
#endif
  
  
}
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //

void Catalog::write_catalog_bin(string outputFileName)
{
    So.enter(__PRETTY_FUNCTION__);
    real_prec conversion_factor=1.0;
    int Nprop_file=MIN_N_PROP_CAT;

#ifdef _USE_VMAX_AS_OBSERVABLE_
    Nprop_file++;
#ifdef _ASSIGN_MASS_POST_
    Nprop_file++;
#ifdef _USE_SPIN_AS_DERIVED_OBSERVABLE_    
    Nprop_file++;
#endif
#ifdef _USE_RS_AS_DERIVED_OBSERVABLE_
    Nprop_file++;
#endif
#endif


  


#elif defined _USE_MASS_AS_OBSERVABLE_
    Nprop_file++;
#endif

    // The structure pof the binary file will be:
    //  ULONG Nlines
    //  int Ncolumns = 10
   //   Nlines*Ncolumns floats x,y,z,vx,vy,vz,M,vmax,Rs,s 
    ofstream outStream;
    this->So.message_screen("Writting to binary file", outputFileName);

    outStream.open(outputFileName.c_str(), ios::binary|ios::out);

    this->So.message_screen("Writting Number of tracers = ", this->NOBJS);
    outStream.write(reinterpret_cast<char*>(&this->NOBJS), sizeof(ULONG));
    this->So.DONE();
    this->So.message_screen("Writting number of columns = ", Nprop_file);
    outStream.write(reinterpret_cast<char*>(&Nprop_file), sizeof(ULONG));
    this->So.DONE();

    
#ifdef _OUTPUT_WITH_HEADERS_
    vector<string> data_i(Nprop_file+1);
    data_i.push_back("#x(Mpc/h).");
    data_i.push_back("y(Mpc/h).");
    data_i.push_back("z(Mpc/h).");
    data_i.push_back("vx(km/s).");
    data_i.push_back("vy(km/s).");
    data_i.push_back("vz(km/s).");
#ifdef _USE_VMAX_AS_OBSERVABLE_

#ifdef _ASSIGN_MASS_POST_
    data_i.push_back("Mass(Ms/h).)";
    data_i.push_back("Vmax(km/s).)";
#ifdef _USE_RS_AS_OBSERVABLE_POWER_
    data_i.push_back("Rs(kpc/h).");
#endif

#ifdef _USE_SPIN_AS_DERIVED_OBSERVABLE_
    data_i.push_back("Spin.");
#endif

#endif // end for assign_mass_post

#elif defined _USE_MASS_AS_OBSERVABLE_
    data_i.push_back("Mass(Ms/h).)";
#endif
    data_i.push_back("Ntracers");
    for(int i=0;i<Nprop_file+1;++i)
    {
        int sizes_i=data_i[i].size();
        outStream.write((char *)&sizes_i, sizeof(sizes_i));
        outStream.write(data_i[i].c_str(), sizes_i);
    }
#endif

    for(ULONG i = 0; i< this->NOBJS; ++i)
     {
#ifdef _WRITE_COORDINATES_
       float x=static_cast<float>(Halo[i].coord1);
       float y=static_cast<float>(Halo[i].coord2);
       float z=static_cast<float>(Halo[i].coord3);
       outStream.write(reinterpret_cast<char*>(&x), sizeof(x));
       outStream.write(reinterpret_cast<char*>(&y), sizeof(y)); 
       outStream.write(reinterpret_cast<char*>(&z), sizeof(z));
#endif

#ifdef _WRITE_VELOCITIES_
       float vx=static_cast<float>(Halo[i].vel1*conversion_factor);
       float vy=static_cast<float>(Halo[i].vel2*conversion_factor);
       float vz=static_cast<float>(Halo[i].vel3*conversion_factor);
       outStream.write(reinterpret_cast<char*>(&vx), sizeof(vx));
       outStream.write(reinterpret_cast<char*>(&vy), sizeof(vy));
       outStream.write(reinterpret_cast<char*>(&vz), sizeof(vz));
#endif

#if defined _USE_MASS_AS_OBSERVABLE_ || defined (_ASSIGN_MASS_POST_) 
       float mass=static_cast<float>(Halo[i].mass);
       outStream.write(reinterpret_cast<char*>(&mass), sizeof(mass));
#endif
#ifdef _USE_VMAX_AS_OBSERVABLE_
       float vmax=static_cast<float>(Halo[i].vmax);
       outStream.write(reinterpret_cast<char*>(&vmax), sizeof(vmax));
#endif
#ifdef _USE_RS_AS_DERIVED_OBSERVABLE_
        float rs=static_cast<float>(Halo[i].rs);
        outStream.write(reinterpret_cast<char*>(&rs), sizeof(rs));
#endif
#ifdef _USE_SPIN_AS_DERIVED_OBSERVABLE_
       float spin=static_cast<float>(Halo[i].spin);
       outStream.write(reinterpret_cast<char*>(&spin), sizeof(spin));
#endif
    }

    outStream.close();
    So.DONE();
}

// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //


void Catalog::write_catalog(string outputFileName)
{
  So.enter(__PRETTY_FUNCTION__);
  real_prec conversion_factor=1.0;

    int Nprop_file=MIN_N_PROP_CAT;

#if defined _USE_VMAX_AS_OBSERVABLE_ || defined _ASSIGN_VMAX_POST_
    Nprop_file++;
#ifdef _ASSIGN_MASS_POST_
    Nprop_file++;
#ifdef _USE_SPIN_AS_DERIVED_OBSERVABLE_    
    Nprop_file++;
#endif
#ifdef _USE_RS_AS_DERIVED_OBSERVABLE_
    Nprop_file++;
#endif
#endif
#endif
    
    
#ifdef _WRITE_BINARY_BAM_FORMAT_
    
    
    // The structure pof the binary file will be:
    //  ULONG Nlines
    //  int Ncolumns = 10
    //   Nlines*Ncolumns floats x,y,z,vx,vy,vz,M,vmax,Rs,s 
    ofstream outStream;
    this->So.message_screen("Writting to binary file", outputFileName);
    
    outStream.open(outputFileName.c_str(), ios::binary|ios::out);
    
    this->So.message_screen("Writting Number of tracers = ", this->NOBJS);
    outStream.write(reinterpret_cast<char*>(&this->NOBJS), sizeof(ULONG));
    this->So.DONE();
    this->So.message_screen("Writting number of columns = ", Nprop_file);
    outStream.write(reinterpret_cast<char*>(&Nprop_file), sizeof(ULONG));
    this->So.DONE();
    
    
#ifdef _OUTPUT_WITH_HEADERS_
    vector<string> data_i(Nprop_file+1);
    data_i.push_back("#x(Mpc/h).");
    data_i.push_back("y(Mpc/h).");
    data_i.push_back("z(Mpc/h).");
    data_i.push_back("vx(km/s).");
    data_i.push_back("vy(km/s).");
    data_i.push_back("vz(km/s).");
#ifdef _USE_VMAX_AS_OBSERVABLE_
    
#ifdef _ASSIGN_MASS_POST_
    data_i.push_back("Mass(Ms/h).");
    data_i.push_back("Vmax(km/s).");
#ifdef _USE_RS_AS_OBSERVABLE_POWER_
    data_i.push_back("Rs(kpc/h).");
#endif
    
#ifdef _USE_SPIN_AS_DERIVED_OBSERVABLE_
    data_i.push_back("Spin.");
#endif
    
#endif // end for assign_mass_post
    
#elif defined _USE_MASS_AS_OBSERVABLE_
    data_i.push_back("Mass(Ms/h).");
#endif
    data_i.push_back("Ntracers");
    for(int i=0;i<Nprop_file+1;++i)
      {
	int sizes_i=data_i[i].size();
        outStream.write((char *)&sizes_i, sizeof(sizes_i));
        outStream.write(data_i[i].c_str(), sizes_i);
      }
#endif
    
    for(ULONG i = 0; i< this->NOBJS; ++i)
      {
#ifdef _WRITE_COORDINATES_
	float x=static_cast<float>(Halo[i].coord1);
	float y=static_cast<float>(Halo[i].coord2);
	float z=static_cast<float>(Halo[i].coord3);
	outStream.write(reinterpret_cast<char*>(&x), sizeof(x));
	outStream.write(reinterpret_cast<char*>(&y), sizeof(y)); 
	outStream.write(reinterpret_cast<char*>(&z), sizeof(z));
#endif
	
#ifdef _WRITE_VELOCITIES_
	float vx=static_cast<float>(Halo[i].vel1*conversion_factor);
	float vy=static_cast<float>(Halo[i].vel2*conversion_factor);
	float vz=static_cast<float>(Halo[i].vel3*conversion_factor);
	outStream.write(reinterpret_cast<char*>(&vx), sizeof(vx));
	outStream.write(reinterpret_cast<char*>(&vy), sizeof(vy));
	outStream.write(reinterpret_cast<char*>(&vz), sizeof(vz));
#endif
	
#if defined _USE_MASS_AS_OBSERVABLE_ || defined (_ASSIGN_MASS_POST_) 
	float mass=static_cast<float>(Halo[i].mass);
	outStream.write(reinterpret_cast<char*>(&mass), sizeof(mass));
#endif
#ifdef _USE_VMAX_AS_OBSERVABLE_
	float vmax=static_cast<float>(Halo[i].vmax);
	outStream.write(reinterpret_cast<char*>(&vmax), sizeof(vmax));
#endif
#ifdef _USE_RS_AS_DERIVED_OBSERVABLE_
	float rs=static_cast<float>(Halo[i].rs);
        outStream.write(reinterpret_cast<char*>(&rs), sizeof(rs));
#endif
#ifdef _USE_SPIN_AS_DERIVED_OBSERVABLE_
	float spin=static_cast<float>(Halo[i].spin);
	outStream.write(reinterpret_cast<char*>(&spin), sizeof(spin));
#endif
      }

#else  // else, write in ascii
    
    ofstream outStream;
    outStream.precision(6);    
    outStream.setf(ios::showpoint); 
    outStream.setf(ios::scientific); 
    outStream.open(outputFileName.c_str(), ios::out);
    
    this->So.message_screen("Writting to ascii file", outputFileName);
    this->So.message_screen("with ", this->NOBJS, "objects");
#endif
    

    for(ULONG i = 0; i< this->NOBJS; ++i)
#if defined _USE_VMAX_AS_OBSERVABLE_ || defined _ASSIGN_VMAX_POST_
#if defined _WRITE_COORDINATES_ && defined _WRITE_VELOCITIES_ 
//      outStream<<this->Halo[i].coord1<<"\t"<<this->Halo[i].coord2<<"\t"<<this->Halo[i].coord3<<"\t"<<this->Halo[i].vel1*conversion_factor<<"\t"<<this->Halo[i].vel2*conversion_factor<<"\t"<<this->Halo[i].vel3*conversion_factor<<"\t"<<this->Halo[i].mass<<"\t"<<this->Halo[i].vmax<<"\t"<<this->Halo[i].rs<<"\t"<<this->Halo[i].spin<<endl;
      outStream<<Halo[i].coord1<<"\t"<<Halo[i].coord2<<"\t"<<Halo[i].coord3<<"\t"<<Halo[i].vel1*conversion_factor<<"\t"<<Halo[i].vel2*conversion_factor<<"\t"<<Halo[i].vel3*conversion_factor<<"\t"<<Halo[i].mass<<"\t"<<Halo[i].vmax<<"\t"<<Halo[i].identity<<"\t"<<Halo[i].gal_cwt<<endl;
#elif defined _WRITE_COORDINATES_ && !defined _WRITE_VELOCITIES_ 
    //      outStream<<Halo[i].coord1<<"\t"<<Halo[i].coord2<<"\t"<<Halo[i].coord3<<"\t"<<Halo[i].mass<<"\t"<<Halo[i].vmax<<"\t"<<Halo[i].rs<<" "<<Halo[i].spin<<endl;
    //      outStream<<Halo[i].coord1<<"\t"<<Halo[i].coord2<<"\t"<<Halo[i].coord3<<"\t"<<Halo[i].mass<<"\t"<<Halo[i].vmax<<endl;
#endif
#endif    
    //#ifdef _USE_MASS_AS_OBSERVABLE_
    //      outStream<<this->Halo[i].coord1<<"\t"<<this->Halo[i].coord2<<"\t"<<this->Halo[i].coord3<<"\t"<<this->Halo[i].mass<<endl;
    //#endif

    outStream.close();
    So.DONE();


		     
}


// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //

#if defined (_USE_MASS_CUTS_PK_) || defined (_USE_ALL_PK_)
void Catalog::read_catalog(string input_file, real_prec prop_min)
#elif defined (_USE_MASS_BINS_PK_)
void Catalog::read_catalog(string input_file, real_prec prop_min, real_prec prop_max)
#endif
{
    //************************************************************************
    // In this function a catalog of DM or DM tracers, in ascii format, is read and their proeprtiess read, according to the request of the parameter file.
    //************************************************************************

   this->So.enter(__PRETTY_FUNCTION__);

   //if(this->type_of_object!="TRACER" || this->type_of_object!= "TRACER_REF" || this->type_of_object!="TRACER_MOCK" || this->type_of_object!="TRACER_MOCK_ONLY_COORDS" || this->type_of_object!="DM")
   //     So.message_warning("Function read_catalog in class Catalog:: has not been provided with a right option for parameter type_of_Objec");

  // The input parameter min_mass cann be also VMAX min, according to preproc definitions

  int NTHREADS = _NTHREADS_;
  omp_set_num_threads(NTHREADS);


#if defined (_USE_MASS_CUTS_PK_) || defined (_USE_ALL_PK_)
  real_prec prop_max=1e20;
#endif
  int i_x=-1;
  int i_y=-1;
  int i_z=-1;
  int i_vx=-1;
  int i_vy=-1;
  int i_vz=-1;
  int i_mass=-1; int i_weight=-1; int i_mean_density=-1; int i_sf=-1; int i_vmax=-1; int i_rs=-1; int i_virial=-1; int i_spin=-1;
  int i_redshift=-1;
  if(this->type_of_object=="DM")
    {
      i_x= this->params._i_coord1_dm();
      i_y= this->params._i_coord2_dm();
      i_z= this->params._i_coord3_dm();
      i_vx= this->params._i_v1_dm();
      i_vy= this->params._i_v2_dm();
      i_vz= this->params._i_v3_dm();
      i_mass = this->params._i_mass_dm();

    }
  else if(this->type_of_object=="TRACER" || this->type_of_object=="TRACER_REF" || this->type_of_object=="TRACER_MOCK" || this->type_of_object=="TRACER_MOCK_ONLY_COORDS")
    {
      i_x= this->params._i_coord1_g();
      i_y= this->params._i_coord2_g();
      i_z= this->params._i_coord3_g();
      i_vx= this->params._i_v1_g();
      i_vy= this->params._i_v2_g();
      i_vz= this->params._i_v3_g();
      i_mass = this->params._i_mass_g();
      i_vmax = this->params._i_vmax_g();
      i_weight = this->params._i_weight1_g();
      i_mean_density= this->params._i_mean_density_g();
      i_sf = this->params._i_sf_g();
      i_rs = this->params._i_rs_g();
      i_virial = this->params._i_virial_g();
      i_spin = this->params._i_spin_g();
      if(this->params._sys_of_coord_g()==2)
        i_redshift= this->params._i_coord3_g();// note that this applies only in the case in which coordsa are in pseudo*-equatorial
    }

  else if(this->type_of_object=="RANDOM")
    {
      i_x= this->params._i_coord1_r();
      i_y= this->params._i_coord2_r();
      i_z= this->params._i_coord3_r();
      i_weight = this->params._i_weight1_r();
      i_mean_density= this->params._i_mean_density_r();
      i_mass= this->params._i_mass_r();
      if(this->params._sys_of_coord_r()>=2)
        i_redshift= this->params._i_coord3_r();// note that this applies only in the case in which coords are in pseudo-equatorial
    }


  //We need to differentiate between observabloe and settings:
  //"Observable" will be using in case we want to do bins or cuts on a given property within a sample
  // -------------------------------------------------------------------------
  int i_observable=i_mass;
  int i_setting=i_mass;
  real_prec units_observable=1;
  real_prec units_settings=1;
  real_prec min_cut=0;

#ifdef _POWER_
#ifdef _USE_MASS_AS_OBSERVABLE_POWER_
  i_observable=i_mass;
  i_setting=i_mass;
  units_observable=this->params._MASS_units();
#elif defined _USE_VMAX_AS_OBSERVABLE_POWER_
  i_observable=i_vmax;
  i_setting=i_mass;
  min_cut=pow(10, this->params._LOGMASSmin());
#elif defined _USE_RS_AS_OBSERVABLE_POWER_
  i_observable=i_rs;
  i_setting=i_mass;
#elif defined _USE_SPIN_AS_OBSERVABLE_POWER_
  i_observable=i_spin;
  i_setting=i_mass;
#endif

#else

#ifdef _USE_MASS_AS_OBSERVABLE_
  i_observable=i_mass;
  units_observable=this->params._MASS_units();
#elif defined _USE_VMAX_AS_OBSERVABLE_
  i_observable=i_vmax;
  units_observable=1;
#endif

  i_setting=i_mass;
  units_settings=this->params._MASS_units();
  min_cut=pow(10, this->params._LOGMASSmin());// Value of the settng-property defining the minimum setting property. Set mass by default.
#endif

  // -------------------------------------------------------------------------
#if defined (_USE_VMAX_AS_OBSERVABLE_) || defined (_USE_VMAX_AS_OBSERVABLE_POWER_)
  if(this->type_of_object!="TRACER_MOCK_ONLY_COORDS" ||this->type_of_object!="RANDOM" )
    if(i_vmax<0)
      {
	So.message_warning("No information for Vmax. Check .ini parameter");
#ifndef mode_p
/**
        string resp;
       std::cout<<"Do you want to continue? [yes/no]  "; cin>>resp;
       if("no"==resp)
         {
           So.message_warning("Code ends here. Sorry");
           exit(0);
         }
**/
#endif
      }
#endif
#if defined (_USE_MASS_AS_OBSERVABLE_) || defined (_USE_MASS_AS_OBSERVABLE_POWER_)
  if(this->type_of_object!="TRACER_MOCK_ONLY_COORDS" ||this->type_of_object!="RANDOM" )
    if(i_mass<0)
      {
        So.message_warning("No information for Mass. Check .ini parameter");
#ifndef mode_p
/**
        string resp;
       std::cout<<"Do you want to continue? [yes/no]  "; cin>>resp;
       if("no"==resp)
         {
           So.message_warning("Code ends here. Sorry");
           exit(0);
         }
**/
#endif
      }
#endif
  // -------------------------------------------------------------------------





  vector<real_prec> prop;
  ULONG NLINES =0;
     // This is meant for ascie reading.
#ifdef _READ_BINARY_BAM_FORMAT_
   NLINES= this->File.read_binary_file(input_file, prop);
#else
  NLINES = this->File.read_file(input_file, prop,NTHREADS);
#endif
  this->NCOLS=(static_cast<ULONG>(prop.size()/NLINES));


  /*
    ofstream tea;
    So.message_screen("Writting new catalog to file ",this->Output_directory+"newcat.txt");
    tea.open(this->Output_directory+"newcat.txt");
    for(ULONG i=0;i<NLINES;++i)
    if(prop[i_mass+i*NCOLS]*params._MASS_units()>= prop_min)
    tea<<prop[i_x+i*NCOLS]<<"  "<<prop[i_y+i*NCOLS]<<"  "<<prop[i_z+i*NCOLS]<<"  "<<prop[i_mass+i*NCOLS]<<"  "<<prop[i_vmax+i*NCOLS]<<"  "<<prop[i_sf+i*NCOLS]<<endl;

    tea.close();
    So.DONE();
    exit(0);
  */


  // **************************************************************************************************************
  // **************************************************************************************************************
  // **************************************************************************************************************
  // We now proceed to allocate read and allcoate the different properties
  // taking into account the different limits on properties.
 // This is done individually, since putting Nob ifs inside a M loop costs more than a single "if" outside each M loop

  // **************************************************************************************************************
  // The minimum mass (M or VMAX) defines the number of used tracers!!!!!!!!!!!!!
  // First stage: counting number of objects above limits. The corresponding loop is paralleized and tested
#ifdef _SET_CAT_WITH_CUT_
#ifdef _FULL_VERBOSE_
    if(this->type_of_object!="RANDOM")
        So.message_screen("Catalog will be selected with mass cut at ", pow(10,this->params._LOGMASSmin()));
#endif
#endif

  ULONG count_new_nobj=0;
#ifdef _FULL_VERBOSE_
     So.message_screen("Counting number of", this->type_of_object);
#endif

  if(this->type_of_object!="RANDOM")
    {
      if((this->type_of_object!="TRACER_MOCK_ONLY_COORDS") && (i_mass>0 || i_vmax>0) )  //This applies for mocks with mass
        {
#ifdef _USE_OMP_TEST_CAT_
#pragma omp parallel for reduction(+:count_new_nobj)
#endif
          for(ULONG i=0;i<NLINES;++i)
                {
#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
          if(prop[i_setting+i*this->NCOLS]>min_cut)
	    {
#endif
#endif

#ifdef _POWER_
                    real_prec obser=prop[i_observable+i*this->NCOLS]*units_settings;
#else
                  real_prec obser=prop[i_setting+i*this->NCOLS]*units_settings;
#endif


#if defined (_USE_MASS_CUTS_PK_) || defined (_USE_ALL_PK_)
	      if(obser >= prop_min)
#elif defined (_USE_MASS_BINS_PK_)
		if(obser >= prop_min && obser < prop_max)
#endif
#ifdef _USE_REDSHIFT_BINS_
                if(prop[i_redshift+i*this->NCOLS] < this->params._redshift_max_sample() && prop[i_redshift+i*this->NCOLS]>= this->params._redshift_min_sample())
#endif
                    count_new_nobj++;

#ifdef _POWER_
#ifdef _SET_CAT_WITH_MASS_CUT_
	    }
#endif
#endif
        }


#ifdef _POWER_
      So.message_screen("Minimum value of observable requested =", prop_min);
#ifdef _USE_REDSHIFT_BINS_
      So.message_screen("Minimum value of redshift  =", this->params._redshift_min_sample());
#endif


#ifdef _USE_MASS_BINS_PK_
      So.message_screen("Maximum value of observable requested =", prop_max);
#ifdef _USE_REDSHIFT_BINS_
      So.message_screen("Maximum value of redshift  =", this->params._redshift_max_sample());
#endif
      So.message_screen("Number of tracers in the prop-bin =", count_new_nobj);
#else
#ifdef _SET_CAT_WITH_MASS_CUT_

      So.message_screen("Minimum mass requested =", prop_min, "Ms/h");
#ifdef _USE_MASS_BINS_PK_
      So.message_screen("Maximum mass requested =", prop_max, "Ms/h");
      So.message_screen("Number of in the mass bin =", count_new_nobj);
#else
      So.message_screen("Number of tracers above mass limit =", count_new_nobj);
#endif

#elif defined (_SET_CAT_WITH_VMAX_CUT_)
      So.message_screen("Minimum VMAX requested =", prop_min, "Km/s");
#ifdef _USE_MASS_BINS_PK_
      So.message_screen("Maximum VMAX requested =", prop_max, "Km/s");
      So.message_screen("Number of in the mass bin =", count_new_nobj);
#else
      So.message_screen("Number of tracers above VMAX limit =", count_new_nobj);
#endif

#endif
#endif
#endif // end of def power
    }
  else  // Otherwilse, if type is mock with only coords, the total number of objects is the number of lines in the mock
    {
      count_new_nobj=NLINES;
      prop_min=-1.0;
    }
#ifdef _FULL_VERBOSE_
     So.DONE();
#endif

    }
    else if (this->type_of_object=="RANDOM")// ojo que aca asumimos que los randoms no tinen propiuedades para ser seleccionados
       count_new_nobj=NLINES;

#ifdef _FULL_VERBOSE_
    So.message_screen("Found ",count_new_nobj," objects");
#endif

    So.DONE();


  this->NOBJS=count_new_nobj;
  this->Halo.resize(this->NOBJS);

  if (this->type_of_object=="RANDOM")
    {
#pragma omp parallel for
          for(ULONG i=0;i<NLINES;++i)  // This loop should not be paralelized, it generates problems.
       {
         this->Halo[i].coord1=prop[i_x+i*NCOLS];
         this->Halo[i].coord2=prop[i_y+i*NCOLS];
         this->Halo[i].coord3=prop[i_z+i*NCOLS];
     }
    if(i_mean_density>0)
#pragma omp parallel for
        for(ULONG i=0;i<NLINES;++i)  // This loop should not be paralelized, it generates problems.
            this->Halo[i].mean_density=prop[i_mean_density+i*NCOLS];
    }
  ULONG iN=0;
  // **************************************************************************************************************
    // Now alocate the ID of the grid for each member
  // This loop has problems with being parallelized.

#ifdef _FULL_VERBOSE_
#ifndef _POWER_   // This lines are only useful when analysing the catalog with BAM, not to measure the power spectrum
  if(this->params._sys_of_coord_g()==0)
      So.message_screen("Getting grid-ID from tracer coordinates");
#endif
#endif

 if (this->type_of_object!="RANDOM")
    {
#ifdef _USE_OMP_TEST_CAT_
#pragma omp parallel for reduction(+:iN)
#endif
  for(ULONG i=0;i<NLINES;++i)  // This loop should not be paralelized, it generates problems.
    {
      real_prec obser=0;

#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
      if(prop[i_setting+i*this->NCOLS]>min_cut)
	{
#endif
#endif
          if(this->type_of_object!="TRACER_MOCK_ONLY_COORDS") //This if is inside, for we can lack of mass but still will to read coordinates

#ifdef _POWER_
             obser = (i_mass> 0 || i_vmax>0) ? prop[i_observable+i*this->NCOLS]*units_settings  : 0 ;  // the questio  must be generalized to other props
#else
             obser = prop[i_setting+i*this->NCOLS]*units_settings;
#endif


#if defined (_USE_MASS_CUTS_PK_) || defined (_USE_ALL_PK_)
          if(obser>= prop_min)
#elif defined (_USE_MASS_BINS_PK_)
            if(obser>= prop_min && obser< prop_max)
#endif
	      {
      		real_prec x=prop[i_x+i*NCOLS];
		      real_prec y=prop[i_y+i*NCOLS];
                      real_prec z=prop[i_z+i*NCOLS];
                      this->Halo[iN].coord1=x;
                      this->Halo[iN].coord2=y;
                      this->Halo[iN].coord3=z;

#ifdef _USE_REDSHIFT_BINS_
                if(z< this->params._redshift_max_sample() && z>= this->params._redshift_min_sample())
                    {
                    this->Halo[iN].observed=true;
#endif
#ifndef _POWER_   // This lines are only useful when analysing the catalog with BAM, not to measure the power spectrum
                if(this->params._sys_of_coord_g()==0)
                        this->Halo[iN].GridID = grid_ID(&box, x,y,z);
		this->Halo[iN].observed=true;
#endif
#ifdef _USE_NUMBER_OF_SATELLITES_
                this->Halo[iN].n_satellites=prop[i_sf+i*NCOLS];
#endif
                     iN++;
#ifdef _USE_REDSHIFT_BINS_
                }
#endif

                    }
#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
	}
#endif
#endif
    }
  So.DONE();

  if(count_new_nobj!=iN)
    {
      So.message_warning("Counting not consistent in function", __PRETTY_FUNCTION__);
      So.message_warning("Line", __LINE__);
    }

}

 // *********************************************************************
  if((this->type_of_object!="TRACER_MOCK_ONLY_COORDS" || this->type_of_object!="RANDOM") && i_vmax>0 && i_vmax<NCOLS) // This if is outside the loop, for we here want vmax and it applies only when this "if" is satisfied
    {
#ifdef _FULL_VERBOSE_
      So.message_screen("Allocating Vmax from tracer");
#endif
      real_prec mean_m=0;
      iN=0;
#ifdef _USE_OMP_TEST_CAT_
#pragma omp parallel for reduction(+:iN,mean_m)
#endif
      for(ULONG i=0;i<NLINES;++i)
	{
#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
          if(prop[i_setting+i*this->NCOLS]>min_cut)
	    {
#endif
#endif

#ifdef _POWER_
             real_prec prop_sel =prop[i_observable+i*this->NCOLS]*units_settings;
#else
             real_prec prop_sel =prop[i_setting+i*this->NCOLS]*units_settings;
#endif

#if defined (_USE_MASS_CUTS_PK_) || defined (_USE_ALL_PK_)
	      if(prop_sel>= prop_min)
#elif defined (_USE_MASS_BINS_PK_)
		if(prop_sel>= prop_min && prop_sel < prop_max)
#endif
             #ifdef _USE_REDSHIFT_BINS_
                 if(prop[i_redshift+i*this->NCOLS]< this->params._redshift_max_sample() && prop[i_redshift+i*this->NCOLS]>= this->params._redshift_min_sample())
#endif
                 {
                   real_prec proper=prop[i_vmax+i*NCOLS]*units_observable;
                   this->Halo[iN].vmax=proper;
                   mean_m+=proper;
                   iN++;
		  }
#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
	    }
#endif
#endif
      }

      So.DONE();
      if(count_new_nobj!=iN)
        {
          So.message_warning("Counting not consistent in function", __PRETTY_FUNCTION__);
          So.message_warning("Line", __LINE__);
        }
#ifdef _FULL_VERBOSE_
        mean_m/=static_cast<real_prec>(this->NOBJS);
#ifdef _USE_LOG_MASS_
        this->So.message_screen("Mean mass of tracer catalogue =", pow(10,mean_m)*this->params._MASS_units(), "km/s");
#else
        this->So.message_screen("Mean VMAX of tracer catalogue =", mean_m*this->params._MASS_units(), "km/s");
#endif
#endif
      }
#ifdef _FULL_VERBOSE_
  else
    So.message_warning("Information of vmax not available in catalog or column not properly set");
#endif

  // *********************************************************************



#ifndef _POWER_
#ifdef _MULTISCALE_
#ifdef _USE_MULTISCALE_PROPERTY_ASSIGNMENT_

  if(type_of_object=="TRACER_REF")
    {
      // These numbers areonly to be determined from the abundance of the reference
      this->N_props_0   =0;
      this->N_props_1   =0;
      this->N_props_2   =0;
      this->N_props_3   =0;
      this->N_props_4   =0;
#ifdef _FULL_VERBOSE_
      So.message_screen("Computing numbers for multi-scale mass assgnment");
#endif
      ULONG N0_AUX=0;
      ULONG N1_AUX=0;
      ULONG N2_AUX=0;
      ULONG N3_AUX=0;
      ULONG N4_AUX=0;
#ifdef _USE_OMP_
#pragma omp parallel for reduction(+:N4_AUX,N3_AUX,N2_AUX,N1_AUX)
#endif
      for(ULONG i=0;i<NLINES;++i)
    	{
#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
          if(prop[i_setting+i*this->NCOLS]>min_cut)
            {
#endif
#endif
           real_prec prop_sel =prop[i_setting+i*this->NCOLS]*units_settings;
    	  if(prop_sel>= prop_min)
	       {
              real_prec obser= prop[i_observable+i*this->NCOLS]*units_observable;
#ifdef _USE_MULTISCALE_LEVEL_1_
	      if(obser >= this->params._Prop_threshold_multi_scale_1())
                N1_AUX++;
#endif
#ifdef _USE_MULTISCALE_LEVEL_2_
#ifdef _USE_MULTISCALE_LEVEL_1_
	      if(obser >= this->params._Prop_threshold_multi_scale_2() && obser < this->params._Prop_threshold_multi_scale_1())
#else
		if(obser >= this->params._Prop_threshold_multi_scale_2())
#endif
                N2_AUX++;
#endif
#ifdef _USE_MULTISCALE_LEVEL_3_  // ensures level 1 is always used
#ifdef _USE_MULTISCALE_LEVEL_2_
	      if(obser >= this->params._Prop_threshold_multi_scale_3() && obser < this->params._Prop_threshold_multi_scale_2())
#elif !defined (_USE_MULTISCALE_LEVEL_2_) && defined (_USE_MULTISCALE_LEVEL_1_)
		if(obser >= this->params._Prop_threshold_multi_scale_3() && obser < this->params._Prop_threshold_multi_scale_1())
#elif !defined (_USE_MULTISCALE_LEVEL_2_) && !defined (_USE_MULTISCALE_LEVEL_1_)
		  if(obser >= this->params._Prop_threshold_multi_scale_3())
#endif
                N3_AUX++;
#endif
#ifdef _USE_MULTISCALE_LEVEL_4_
#if defined (_USE_MULTISCALE_LEVEL_3_)
	      if(obser >= this->params._Prop_threshold_multi_scale_4() && obser < this->params._Prop_threshold_multi_scale_3())
#elif !defined (_USE_MULTISCALE_LEVEL_3_) && defined (_USE_MULTISCALE_LEVEL_2_)
		if(obser >= this->params._Prop_threshold_multi_scale_4() && obser < this->params._Prop_threshold_multi_scale_2())
#elif !defined (_USE_MULTISCALE_LEVEL_3_) && !defined (_USE_MULTISCALE_LEVEL_2_) && defined (_USE_MULTISCALE_LEVEL_1_)
		  if(obser >= this->params._Prop_threshold_multi_scale_4() && obser < this->params._Prop_threshold_multi_scale_1())
#elif !defined (_USE_MULTISCALE_LEVEL_3_) && !defined (_USE_MULTISCALE_LEVEL_2_) && !defined (_USE_MULTISCALE_LEVEL_1_)
		    if(obser >= this->params._Prop_threshold_multi_scale_4())
#endif
                 N4_AUX++;
#endif
	    }

	}
    So.DONE();
    this->N_props_1=N1_AUX;
    this->N_props_2=N2_AUX;
    this->N_props_3=N3_AUX;
    this->N_props_4=N4_AUX;


#ifdef _FULL_VERBOSE_
#ifdef _USE_MULTISCALE_LEVEL_1_
      So.message_screen("Number of reference tracers in multi-scale level 1, N_M1= ", N_props_1);
#endif
#ifdef _USE_MULTISCALE_LEVEL_2_
        So.message_screen("Number of reference tracers in multi-scale level 2, N_M2= ", N_props_2);
#endif
#ifdef _USE_MULTISCALE_LEVEL_3_
        So.message_screen("Number of reference tracers in multi-scale level 3, N_M3= ", N_props_3);
#endif
#ifdef _USE_MULTISCALE_LEVEL_4_
        So.message_screen("Number of reference tracers in multi-scale level 4, N_M4= ", N_props_4);
#endif
       cout<<endl;
#endif
  }// closes f(type_of_object=="TRACER_REF")


#elif defined _USE_MULTISCALE_PROPERTY_ASSIGNMENT_NEW_

  if(type_of_object=="TRACER_REF")
    {

#ifdef _FULL_VERBOSE_
      So.message_screen("Computing numbers for multi-scale mass assgnment");

#endif
      vector<ULONG> n_auxtr(this->params._Number_of_MultiLevels(),0);
      for(ULONG i=0;i<NLINES;++i)
        {
         real_prec prop_sel = prop[i_setting+i*this->NCOLS]*units_settings;
         if(prop_sel>= prop_min)
          {
           real_prec obser= prop[i_observable+i*this->NCOLS]*units_observable;

           if(obser>= this->params.get_PropThreshold_MultiLevels(0))
             n_auxtr[0]++;

           for(int il=1; il<this->params._Number_of_MultiLevels();++il )
             if(obser>= this->params.get_PropThreshold_MultiLevels(il) &&  obser<this->params.get_PropThreshold_MultiLevels(il-1) )
               n_auxtr[il]++;
         }
 
      }
      So.DONE();

      for(int il=0; il<this->params._Number_of_MultiLevels();++il )
        {
          ULONG N_AUX=  static_cast<ULONG>(floor(this->params.get_Props_Tolerance_MultiLevels(il)*n_auxtr[il]));
          this->params.set_Ntracers_MultiLevels(il, N_AUX);

#ifdef _FULL_VERBOSE_
          So.message_screen("Number of reference tracers in multi-scale level ", il+1, " = ", N_AUX);
#endif
      }
      n_auxtr.clear();n_auxtr.shrink_to_fit();
#ifdef _FULL_VERBOSE_
      std::cout<<std::endl;
#endif
      }

#endif // end of _USE_MULTISCALE_PROPERTY_ASSIGNMENT_NEW_

#endif // END OF _MULTISCALE_

#endif // END OF ifndef _power_



  // *********************************************************************************************
  // If information of weights is available, then
  if((this->type_of_object!="TRACER_MOCK_ONLY_COORDS" || this->type_of_object!="RANDOM") &&  i_weight>0 && i_weight<NCOLS)
    {
#ifdef _FULL_VERBOSE_
      So.message_screen("Allocating weighs from tracers");
#endif

      iN=0;
#ifdef _USE_OMP_TEST_CAT_
#pragma omp parallel for reduction(+:iN)
#endif
      for(ULONG i=0;i<NLINES;++i)
        {
#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
          if(prop[i_setting+i*this->NCOLS]>min_cut)
            {
#endif
#endif

#ifdef _POWER_
             real_prec obser= (i_mass> 0 || i_vmax>0) ? prop[i_observable+i*this->NCOLS]*units_settings : 0;
#else
             real_prec obser=prop[i_setting+i*this->NCOLS]*units_settings;
#endif


#if defined (_USE_MASS_CUTS_PK_) || defined (_USE_ALL_PK_)
          real_prec propert= (i_mass> 0 || i_vmax>0) ?  prop[i_setting+i*this->NCOLS]*units_settings : 1.0;
           real_prec prop_min_new= (i_mass> 0 || i_vmax>0) ?  prop_min : 0.0;
          if(propert >= prop_min_new )
#elif defined (_USE_MASS_BINS_PK_)
            if( obser >= prop_min && obser < prop_max)
#endif

#ifdef _USE_REDSHIFT_BINS_
    if(prop[i_redshift+i*this->NCOLS]< this->params._redshift_max_sample() && prop[i_redshift+i*this->NCOLS]>= this->params._redshift_min_sample())
#endif
                {
                    this->Halo[iN].weight1=prop[i_weight+i*NCOLS];
                    iN++;
	      }

#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
            }
#endif
#endif
          }
      So.DONE();
      if(count_new_nobj!=iN)
        {
          So.message_warning("Counting not consistent in function", __PRETTY_FUNCTION__);
          So.message_warning("Line", __LINE__);
        }

    }

  // ********************************************************************************************************************************
  if(this->type_of_object!="RANDOM")
   if((this->type_of_object!="TRACER_MOCK_ONLY_COORDS" || this->type_of_object!="RANDOM") &&  i_mean_density>0 && i_mean_density<NCOLS )
     {
#ifdef _FULL_VERBOSE_
      So.message_screen("Allocating number density from ", this->type_of_object);
#endif
      iN=0;
#ifdef _USE_OMP_TEST_CAT_
#pragma omp parallel for reduction(+:iN)
#endif
      for(ULONG i=0;i<NLINES;++i)
        {
#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
          if(prop[i_setting+i*this->NCOLS]>min_cut)
            {
#endif
#endif


#ifdef _POWER_
             real_prec obser= (i_mass> 0 || i_vmax>0) ? prop[i_observable+i*this->NCOLS]*units_settings : 0;
#else
             real_prec obser=prop[i_setting+i*this->NCOLS]*units_settings;
#endif

#if defined (_USE_MASS_CUTS_PK_) || defined (_USE_ALL_PK_)
             real_prec propert= (i_mass> 0 || i_vmax>0) ?  prop[i_setting+i*this->NCOLS]*units_settings : 1.0;
              real_prec prop_min_new= (i_mass> 0 || i_vmax>0) ?  prop_min : 0.0;
             if(propert >= prop_min_new )

#elif defined (_USE_MASS_BINS_PK_)
            if(obser >= prop_min && obser < prop_max)
#endif
#ifdef _USE_REDSHIFT_BINS_
    if(prop[i_redshift+i*this->NCOLS]< this->params._redshift_max_sample() && prop[i_redshift+i*this->NCOLS]>= this->params._redshift_min_sample())
#endif

	      {
		this->Halo[iN].mean_density=prop[i_mean_density+i*NCOLS];
		iN++;
	      }
#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
            }
#endif
#endif

              }
      So.DONE();
      if(count_new_nobj!=iN)
        {
          So.message_warning("Counting not consistent in function", __PRETTY_FUNCTION__);
          So.message_warning("Line", __LINE__);
        }

      }
#ifdef _FULL_VERBOSE_
  else
    So.message_warning("Information of mean_density not available in catalog or column not properly set");
#endif
  // ********************************************************************************************************************************

  if((this->type_of_object!="TRACER_MOCK_ONLY_COORDS" || this->type_of_object!="RANDOM" )&& i_rs>0 && i_rs<NCOLS )
    {
#ifdef _FULL_VERBOSE_
          So.message_screen("Allocating Rs from tracers");
#endif
          real_prec mean_m=0;
          iN=0;
#ifdef _USE_OMP_TEST_CAT_
#pragma omp parallel for reduction(+:iN,mean_m)
#endif
      for(ULONG i=0;i<NLINES;++i)
        {
#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
          if(prop[i_setting+i*this->NCOLS]>min_cut)
            {
#endif
#endif

#ifdef _POWER_
             real_prec obser=prop[i_observable+i*this->NCOLS]*units_settings;
#else
             real_prec obser=prop[i_setting+i*this->NCOLS]*units_settings;
#endif


#if defined (_USE_MASS_CUTS_PK_) || defined (_USE_ALL_PK_)
          if(obser >= prop_min)
#elif defined (_USE_MASS_BINS_PK_)
            if(obser >= prop_min && obser < prop_max)
#endif
#ifdef _USE_REDSHIFT_BINS_
    if(prop[i_redshift+i*this->NCOLS]< this->params._redshift_max_sample() && prop[i_redshift+i*this->NCOLS]>= this->params._redshift_min_sample())
#endif

             {
                real_prec proper=prop[i_rs+i*NCOLS]*units_observable;
                this->Halo[iN].rs=proper;
                 mean_m+=proper;
                 iN++;
              }
#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
            }
#endif
#endif

        }
      So.DONE();
      if(count_new_nobj!=iN)
        {
          So.message_warning("Counting not consistent in function", __PRETTY_FUNCTION__);
          So.message_warning("Line", __LINE__);
        }
#ifdef _FULL_VERBOSE_
      mean_m/=static_cast<real_prec>(this->NOBJS);
#ifdef _USE_LOG_MASS_
        this->So.message_screen("Mean mass of tracer catalogue =", pow(10,mean_m)*this->params._MASS_units(), "km/s");
#else
        this->So.message_screen("Mean RS of tracer catalogue =", mean_m*this->params._MASS_units(), "kpc/h");
#endif
#endif
      }
#ifdef _FULL_VERBOSE_
  else
    So.message_warning("Information of RS not available in catalog or column not properñy set");
#endif
  // ********************************************************************************************************************************

  if((this->type_of_object!="TRACER_MOCK_ONLY_COORDS" || this->type_of_object!="RANDOM") && i_virial>0 && i_virial<NCOLS)
    {
#ifdef _FULL_VERBOSE_
      So.message_screen("Allocating T/|W| Viral from tracers");
#endif
      iN=0;
#ifdef _USE_OMP_TEST_CAT_
#pragma omp parallel for reduction(+:iN)
#endif
      for(ULONG i=0;i<NLINES;++i)
        {
#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
          if(prop[i_setting+i*this->NCOLS]>min_cut)
            {
#endif
#endif

#ifdef _POWER_
             real_prec obser=prop[i_observable+i*this->NCOLS]*units_settings;
#else
             real_prec obser=prop[i_setting+i*this->NCOLS]*units_settings;
#endif


#if defined (_USE_MASS_CUTS_PK_) || defined (_USE_ALL_PK_)
          if(obser >= prop_min)
#elif defined (_USE_MASS_BINS_PK_)
            if(obser>= prop_min && obser < prop_max)
#endif
#ifdef _USE_REDSHIFT_BINS_
    if(prop[i_redshift+i*this->NCOLS]< this->params._redshift_max_sample() && prop[i_redshift+i*this->NCOLS]>= this->params._redshift_min_sample())
#endif

	      {
		this->Halo[iN].virial=prop[i_virial+i*NCOLS];
		iN++;
	      }
#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
            }
#endif
#endif

        }
      So.DONE();
      if(count_new_nobj!=iN)
        {
          So.message_warning("Counting not consistent in function", __PRETTY_FUNCTION__);
          So.message_warning("Line", __LINE__);
        }

    }
#ifdef _FULL_VERBOSE_
  else
    So.message_warning("Information of virial not available in catalog or column not properly set.");
#endif
  // ********************************************************************************************************************************

  if((this->type_of_object!="TRACER_MOCK_ONLY_COORDS" || this->type_of_object!="RANDOM" )&&  i_spin>0 && i_spin<NCOLS)
    {
#ifdef _FULL_VERBOSE_
      So.message_screen("Allocating Spin from tracers");
#endif
      iN=0;
      real_prec mean_m=0;

#ifdef _USE_OMP_TEST_CAT_
#pragma omp parallel for reduction(+:iN,mean_m)
#endif
      for(ULONG i=0;i<NLINES;++i)
        {
#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
          if(prop[i_setting+i*this->NCOLS]>min_cut)
            {
#endif
#endif

#ifdef _POWER_
             real_prec obser=prop[i_observable+i*this->NCOLS]*units_settings;
#else
             real_prec obser=prop[i_setting+i*this->NCOLS]*units_settings;
#endif


#if defined (_USE_MASS_CUTS_PK_) || defined (_USE_ALL_PK_)
          if(obser >= prop_min)
#elif defined (_USE_MASS_BINS_PK_)
            if(obser >= prop_min && obser < prop_max)
#endif
#ifdef _USE_REDSHIFT_BINS_
    if(prop[i_redshift+i*this->NCOLS]< this->params._redshift_max_sample() && prop[i_redshift+i*this->NCOLS]>= this->params._redshift_min_sample())
#endif
	      {
                real_prec proper=prop[i_spin+i*NCOLS];
                this->Halo[iN].spin=proper;
		iN++;
                mean_m+=proper;
	      }
#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
            }
#endif
#endif

       }
      So.DONE();
      if(count_new_nobj!=iN)
       {
          So.message_warning("Counting not consistent in function", __PRETTY_FUNCTION__);
          So.message_warning("Line", __LINE__);
        }
#ifdef _FULL_VERBOSE_
         mean_m/=static_cast<real_prec>(this->NOBJS);
#ifdef _USE_LOG_MASS_
        this->So.message_screen("Mean mass of tracer catalogue =", pow(10,mean_m)*this->params._MASS_units(), "km/s");
#else
        this->So.message_screen("Mean spin of tracer catalogue =", mean_m*this->params._MASS_units());
#endif
#endif



    }
#ifdef _FULL_VERBOSE_
  else
    So.message_warning("Information of spin not available in catalog or column not properly set");
#endif
  // ********************************************************************************************************************************



  // Here we have to implement an if statement in order to select objects within a "property" bin or cut
  // before assigning the cat to the structure this->Halo. The quantity this->NOBS must be then
  // the remaining number of tracers after the cuts.
if (this->type_of_object!="RANDOM")
{
#if defined (_USE_VELOCITIES_TRACERS_) || defined (_REDSHIFT_SPACE_)
#ifdef _FULL_VERBOSE_
  So.message_screen("Allocating velocities from tracers");
#endif


  if(i_vx>0) //Best to evaluate only one if than NOBS if's
    {
#ifdef _FULL_VERBOSE_
      So.message_screen("Vx");
#endif
      iN=0;
#ifdef _USE_OMP_TEST_CAT_
#pragma omp parallel for reduction(+:iN)
#endif
     for(ULONG i=0;i<NLINES;++i)
        {
#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
          if(prop[i_setting+i*this->NCOLS]>min_cut)
            {
#endif
#endif

#ifdef _POWER_
             real_prec obser=prop[i_observable+i*this->NCOLS]*units_settings;
#else
             real_prec obser=prop[i_setting+i*this->NCOLS]*units_settings;
#endif


#if defined (_USE_MASS_CUTS_PK_) || defined (_USE_ALL_PK_)
          if(obser >= prop_min)
#elif defined (_USE_MASS_BINS_PK_)
            if(obser  >= prop_min && obser < prop_max)
#endif
	      {
		this->Halo[iN].vel1=prop[i_vx+i*NCOLS];
		iN++;
	      }
#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
            }
#endif
#endif

          }
    }

  if(i_vy>0)
    {
#ifdef _FULL_VERBOSE_
      So.message_screen("Vy");
#endif
      iN=0;
      for(ULONG i=0;i<NLINES;++i)
	{
#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
          if(prop[i_setting+i*this->NCOLS]>min_cut)
            {
#endif
#endif

#ifdef _POWER_
             real_prec obser=prop[i_observable+i*this->NCOLS]*units_settings;
#else
             real_prec obser=prop[i_setting+i*this->NCOLS]*units_settings;
#endif


#if defined (_USE_MASS_CUTS_PK_) || defined (_USE_ALL_PK_)
          if(obser >= prop_min)
#elif defined (_USE_MASS_BINS_PK_)
            if(obser >= prop_min && obser < prop_max)
#endif
              {
		this->Halo[iN].vel2=prop[i_vy+i*NCOLS];
		iN++;
	      }
#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
            }
#endif
#endif
              }
    }

  if(i_vz>0)
    {
#ifdef _FULL_VERBOSE_
      So.message_screen("Vz");
#endif
      iN=0;
      for(ULONG i=0;i<NLINES;++i)
        {
#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
          if(prop[i_setting+i*this->NCOLS]>min_cut)
            {
#endif
#endif

#ifdef _POWER_
             real_prec obser=prop[i_observable+i*this->NCOLS]*units_settings;
#else
             real_prec obser=prop[i_setting+i*this->NCOLS]*units_settings;
#endif

#if defined (_USE_MASS_CUTS_PK_) || defined (_USE_ALL_PK_)
          if(obser >= prop_min)
#elif defined (_USE_MASS_BINS_PK_)
            if(obser >= prop_min && obser < prop_max)
#endif

              {
		this->Halo[iN].vel3=prop[i_vz+i*NCOLS];
		iN++;
	      }
#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
            }
#endif
#endif
        }
    }
#endif
}

  // ********************************************************************************************************************************
  if((this->type_of_object!="TRACER_MOCK_ONLY_COORDS" || this->type_of_object!="RANDOM" ) && i_mass >0 && i_mass <NCOLS)
    {
#ifdef _USE_MASS_TRACERS_
      real_prec mean_m=0;
      iN=0;

#ifdef _FULL_VERBOSE_
      So.message_screen("Allocating mass from tracers");
#endif
#ifdef _USE_OMP_TEST_CAT_
#pragma omp parallel for reduction(+:iN,mean_m)
#endif
      for(ULONG i=0;i<NLINES;++i)
        {
#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
          if(prop[i_setting+i*this->NCOLS]*units_settings>min_cut)
            {
#endif
#endif

#ifdef _POWER_
             real_prec obser=prop[i_observable+i*this->NCOLS]*units_settings;
#else
             real_prec obser=prop[i_setting+i*this->NCOLS]*units_settings;
#endif

#if defined (_USE_MASS_CUTS_PK_) || defined (_USE_ALL_PK_)
         if(obser >= prop_min)
#elif defined (_USE_MASS_BINS_PK_)
          if(obser >= prop_min && obser < prop_max)
#endif
#ifdef _USE_REDSHIFT_BINS_
    if(prop[i_redshift+i*this->NCOLS]< this->params._redshift_max_sample() && prop[i_redshift+i*this->NCOLS]>= this->params._redshift_min_sample())
#endif

            {
      	      real_prec proper=prop[i_mass+i*this->NCOLS];
#ifdef _USE_LOG_MASS_
#ifdef _FULL_VERBOSE_
              mean_m+=log10(proper);
#endif
              this->Halo[iN].mass=log10(proper);
#else
              this->Halo[iN].mass=proper;
              mean_m+=proper;
#endif
              iN++;
	    }
#ifdef _POWER_
#ifdef _SET_CAT_WITH_CUT_
            }
#endif
#endif

      }

      So.DONE();
      if(count_new_nobj!=iN)
        {
          So.message_warning("Counting not consistent in function", __PRETTY_FUNCTION__);
          So.message_warning("Line", __LINE__);
        }

#ifdef _FULL_VERBOSE_
      mean_m/=static_cast<real_prec>(this->NOBJS);
      if(iN==0)
         So.message_warning("No mass found in the desidered limits");
#endif


#ifdef _FULL_VERBOSE_
#ifdef _USE_LOG_MASS_
      this->So.message_screen("Mean mass of tracer catalogue =", pow(10,mean_m)*this->params._MASS_units(), "Ms/h");
#else
      this->So.message_screen("Mean mass of tracer catalogue =", mean_m*this->params._MASS_units(), "Ms/h");
#endif
#endif
    }
#ifdef _FULL_VERBOSE_
  else
      So.message_screen("No Information on the tracer mass available in", this->type_of_object);
#endif
#endif

  // *************************************************************************************************
#ifdef _USE_SAT_FRACTION_

  if(i_sf>0)
    {
      iN=0;
      int iN_nosat=0;
      for(ULONG i=0;i<NLINES;++i)
	if(prop[i_mass+i*NCOLS]*params._MASS_units()>= prop_min)
#ifdef _USE_REDSHIFT_BINS_
          if(prop[i_redshift+i*this->NCOLS]< this->params._redshift_max_sample() && prop[i_redshift+i*this->NCOLS]>= this->params._redshift_min_sample())
#endif
           {

           this->Halo[iN].number_sub_structures=static_cast<int>(prop[i_sf+i*NCOLS]);
	    iN++;
	    if(prop[i_sf+i*NCOLS] < 1)
              iN_nosat++;
	  }
      double mean_m=0;
#ifdef _USE_OMP_
#pragma omp parallel for reduction(+:mean_m)
#endif
      for(ULONG i=0;i<this->NOBJS;++i)
	mean_m+=static_cast<double>(this->Halo[i].number_sub_structures);

      mean_m/=static_cast<double>(this->NOBJS);
      this->So.message_screen("Mean number of satellites per host =", mean_m);
      this->So.message_screen("Fraction of centrals without sub-structure =", 100.0*static_cast<double>(iN_nosat)/static_cast<double>(this->NOBJS),"%");

    }
#endif

#ifdef _FULL_VERBOSE_
 So.message_screen("Freeing memmory in ", __PRETTY_FUNCTION__);
#endif
 prop.clear(); prop.shrink_to_fit();
 So.DONE();

 this->mean_number_density=static_cast<real_prec>(this->NOBJS)/pow(this->box.Lbox,3);

}

// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //

// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //



// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //

void Catalog::define_property_bins()
{

#ifdef _USE_OMP_
   int NTHREADS = _NTHREADS_;  // omp_get_max_threads();
   omp_set_num_threads(NTHREADS);
#endif

    //this->NMBINS=this->params._NMASSbins_mf();
#ifdef _FULL_VERBOSE_
#ifdef MBINS
    So.message_screen("Defining bins for abundance:");

#elif defined MCUTS
  So.message_screen("Defining cuts for abundnace:");
#endif
#endif


  if(this->params._i_mass_g() >0)
    {

      this->NMBINS = this->params._NMASSbins_mf() == 1 ? 1 : this->params._NMASSbins_mf();
#ifdef _FULL_VERBOSE_
      So.message_screen("Generating",this->NMBINS," bin(s) (zeroth -or  first bin- is the full sample) to tracer-mass");
#endif
      // to account for the zero bin which includes the full sample, except if one asks for only one bin, in which case the full is assumed

      real_prec MMin;
      real_prec MMax;

#ifdef _MASS_LOG_
      MMin = this->params._LOGMASSmin();
      MMax = this->params._LOGMASSmax();
#ifdef _FULL_VERBOSE_
      this->So.message_screen("Minimum Mass", pow(10,MMin), "Ms/h");
      this->So.message_screen("Maximum Mass", pow(10,MMax), "Ms/h");
#endif
#else
      MMin= pow(10,this->params._LOGMASSmin());
      MMin= this->params._LOGMASSmin();
#ifdef _FULL_VERBOSE_
      this->So.message_screen("Minimum Mass", MMin, "Ms/h");
      this->So.message_screen("Maximum Mass", MMax, "Ms/h");
#endif
#endif

      this->logdeltaM=(MMax-MMin)/(static_cast<real_prec>(this->params._NMASSbins_mf()));
      this->MBmin.clear();this->MBmin.shrink_to_fit();
      this->MBmin.resize(this->NMBINS,0);
#ifdef _MASS_LOG_
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
      for(int i=0;i<this->NMBINS;++i)
        this->MBmin[i]=pow(10,MMin+i*logdeltaM);
#else
      for(int i=0;i<this->NMBINS;++i)
        	this->MBmin.push_back(MMin+i*logdeltaM);
#endif


#ifdef _MASS_LOG_
      this->MBmax.clear();this->MBmax.shrink_to_fit();
      this->MBin.clear();this->MBin.shrink_to_fit();
      this->MBin.resize(this->NMBINS,0);
      this->MBmax.resize(this->NMBINS,0);

#ifdef MBINS
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
      for(int i=0;i<this->NMBINS;++i)
        {
          this->MBmax[i]=pow(10,MMin+(i+1)*logdeltaM);
          this->MBin[i]=this->MBmin[i]+(i+0.5)*(this->MBmax[i]-this->MBmin[i])/static_cast<double>(this->params._NMASSbins_mf());
        }
#elif defined MCUTS
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
      for(int i=0;i<this->NMBINS;++i)
        this->MBmax[i]=pow(10, MMax);
#endif

#else

#ifdef MBINS
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
      for(int i=0;i<NMBINS;++i)
        this->MBmax[i]=(MMin+(i)*logdeltaM);
#elif defined MCUTS
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
      for(int i=0;i<NMBINS;++i)
        this->MBmax[i]=(MMax);
#endif

#endif

      So.DONE();
    }
  else
    {
#ifdef _FULL_VERBOSE_
      So.message_screen("No halo mass info available for type ", this->type_of_object);
#endif
      this->NMBINS=1;
      this->logdeltaM=1;
      this->MBmin.resize(NMBINS,-100.0); //  if no mass is available, in the loop over the masses we set mass = 1,
      this->MBmax.resize(NMBINS,100.0);  //
    }




#if defined _USE_VMAX_AS_OBSERVABLE_ || defined _ASSIGN_VMAX_POST_
  if(this->params._i_vmax_g() >0)
    {
      this->NMBINS = this->params._NMASSbins_mf() == 1 ? 1 : this->params._NMASSbins_mf();
#ifdef _FULL_VERBOSE_
      So.message_screen("Generating",this->NMBINS," bin(s) (zeroth -or  first bin- is the full sample) to tracer-vmax");
#endif
      real_prec MMin;
      real_prec MMax;

#ifdef _MASS_LOG_
      MMin= log10(this->params._VMAXmin());
      MMax= log10(this->params._VMAXmax());
#ifdef _FULL_VERBOSE_
      this->So.message_screen("Minimum VMAX", pow(10,MMin), "km/s");
      this->So.message_screen("Maximum VMAX", pow(10,MMax), "km/s");
#endif

#else
      MMax= this->params._VMAXmin();
      MMin= this->params._VMAXmin();
#ifdef _FULL_VERBOSE_
      this->So.message_screen("Minimum VMAX", MMin, "km/s");
      this->So.message_screen("Maximum VMAX", MMax, "km/s");
#endif
#endif




      this->logdeltaVMAX=(MMax-MMin)/(static_cast<real_prec>(this->params._NMASSbins_mf()));

      this->VMAXBmin.clear();this->VMAXBmin.shrink_to_fit();this->VMAXBmin.resize(this->NMBINS,0);
#ifdef _MASS_LOG_
      for(int i=0;i<this->NMBINS;++i)
        this->VMAXBmin[i]=pow(10,MMin+i*logdeltaVMAX);
#else
      for(int i=0;i<this->NMBINS;++i)
        this->VMAXBmin.push_back(MMin+i*logdeltaVMAX);
#endif


#ifdef _MASS_LOG_
      this->VMAXBmax.clear();this->VMAXBmax.shrink_to_fit();this->VMAXBmax.resize(this->NMBINS,0);
      this->VMAXBin.clear();this->VMAXBin.shrink_to_fit();this->VMAXBin.resize(this->NMBINS,0);

#ifdef MBINS
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
      for(int i=0;i<this->NMBINS;++i)
        {
          this->VMAXBmax[i]=pow(10,MMin+(i+1)*logdeltaVMAX);
          this->VMAXBin[i]=(this->VMAXBmin[i]+(i+0.5)*(this->VMAXBmax[i]-this->VMAXBmin[i])/static_cast<double>(this->params._NMASSbins_mf()));

      }

/*
      for(int i=0;i<this->NMBINS;++i)
        cout<<this->VMAXBmax[i]<<endl;
      exit(1);
*/

#elif defined MCUTS
      for(int i=0;i<this->NMBINS;++i)
        this->VMAXBmax.push_back(pow(10, MMax));
#endif

#else

#ifdef MBINS
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
      for(int i=0;i<NMBINS;++i)
        this->VMAXBmax[i]=(MMin+(i)*logdeltaVMAX);
#elif defined MCUTS
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
      for(int i=0;i<NMBINS;++i)
        this->VMAXBmax[i]=(MMax);
#endif

#endif

      So.DONE();
    }
  else
    {
#ifdef _FULL_VERBOSE_
      So.message_screen("No VMAX info available for type ", this->type_of_object);
#endif
      this->NMBINS=1;
      this->logdeltaVMAX=1;
      this->VMAXBmin.resize(NMBINS,-100.0); //  if no mass is available, in the loop over the masses we set mass = 1,
      this->VMAXBmax.resize(NMBINS,100.0);  //
    }

#endif



#ifdef _USE_RS_AS_DERIVED_OBSERVABLE_

  if(this->params.i_rs_g >0)
    {
      this->NMBINS = this->params._NMASSbins_mf() == 1 ? 1 : this->params._NMASSbins_mf();
#ifdef _FULL_VERBOSE_
      So.message_screen("Generating",this->NMBINS," bin(s) (zeroth -or  first bin- is the full sample) to tracer-vmax");
#endif
      real_prec RSMin;
      real_prec RSMax;

#ifdef _RS_LOG_
      RSMin= log10(this->params._RSmin());
      RSMax= log10(this->params._RSmax());
#ifdef _FULL_VERBOSE_
      this->So.message_screen("Minimum RS", pow(10,RSMin), "kpc/h");
      this->So.message_screen("Maximum RS", pow(10,RSMax), "kpc/h");
#endif
#else
      RSMin= pow(10,this->params._RSmin());
      RSMin= this->params._RSMASSmin();
#ifdef _FULL_VERBOSE_
      this->So.message_screen("Minimum RS", RSMin, "Ms/h");
      this->So.message_screen("Maximum RS", RSMax, "Ms/h");
#endif
#endif

      this->logdeltaRS=(RSMax-RSMin)/(static_cast<real_prec>(this->params._NMASSbins_mf()));

      this->RSBmin.clear();this->RSBmin.shrink_to_fit();
#ifdef _RS_LOG_
      for(int i=0;i<this->NMBINS;++i)
        this->RSBmin.push_back(pow(10,RSMin+i*this->logdeltaRS));
#else
      for(int i=0;i<this->NMBINS;++i)
        this->RSBmin.push_back(MMin+i*logdeltaVMAX);
#endif


#ifdef _RS_LOG_
      this->RSBmax.clear();this->RSBmax.shrink_to_fit();
      this->RSBin.clear();this->RSBin.shrink_to_fit();

#ifdef RSBINS
      for(int i=0;i<this->NMBINS;++i)
        this->RSBmax.push_back(pow(10,RSMin+(i+1)*logdeltaRS));

      for(int i=0;i<this->NMBINS;++i)
        this->RSBin.push_back(this->RSBmin[i]+(i+0.5)*(this->RSBmax[i]-this->RSBmin[i])/static_cast<double>(this->params._NMASSbins_mf()));

#elif defined MCUTS
      for(int i=0;i<this->NMBINS;++i)
        this->RSBmax.push_back(pow(10, RSMax));
#endif

#else

#ifdef RSBINS
      for(int i=0;i<NMBINS;++i)
        this->RSBmax.push_back(RSMin+(i)*logdeltaRS);
#elif defined MCUTS
      for(int i=0;i<NMBINS;++i)
        this->RSmax.push_back(RSMax);
#endif

#endif

      So.DONE();
    }
  else
    {
#ifdef _FULL_VERBOSE_
      So.message_screen("No RS info available for type ", this->type_of_object);
#endif
      this->NMBINS=1;
      this->logdeltaRS=1;
      this->RSBmin.resize(NMBINS,-100.0); //  if no mass is available, in the loop over the masses we set mass = 1,
      this->RSBmax.resize(NMBINS,100.0);  //
    }

#endif




#ifdef _USE_SPIN_AS_DERIVED_OBSERVABLE_


  if(this->params._i_spin_g() >0)
    {
      this->NMBINS = this->params._NMASSbins_mf() == 1 ? 1 : this->params._NMASSbins_mf();
#ifdef _FULL_VERBOSE_
      So.message_screen("Generating",this->NMBINS," bin(s) (zeroth -or  first bin- is the full sample) to tracer-vmax");
#endif

      real_prec SMin;
      real_prec SMax;

#ifdef _SPIN_LOG_
      SMin= log10(this->params._SPINmin());
      SMax= log10(this->params._SPINmax());
#ifdef _FULL_VERBOSE_
      this->So.message_screen("Minimum Spin", pow(10,SMin));
      this->So.message_screen("Maximum Spin", pow(10,SMax));
#endif
#else
      RSMin= pow(10,this->params._RSmin());
      RSMin= this->params._RSMASSmin();
#ifdef _FULL_VERBOSE_
      this->So.message_screen("Minimum RS", RSMin, "Ms/h");
      this->So.message_screen("Maximum RS", RSMax, "Ms/h");
#endif
#endif

      this->logdeltaSPIN=(SMax-SMin)/(static_cast<real_prec>(this->params._NMASSbins_mf()));

      this->SPINBmin.clear();this->SPINBmin.shrink_to_fit();
#ifdef _SPIN_LOG_
      for(int i=0;i<this->NMBINS;++i)
        this->SPINBmin.push_back(pow(10,SMin+i*this->logdeltaSPIN));
#else
      for(int i=0;i<this->NMBINS;++i)
        this->SPINBmin.push_back(SMin+i*logdeltaSPIN);
#endif


#ifdef _SPIN_LOG_
      this->SPINBmax.clear();this->SPINBmax.shrink_to_fit();
      this->SPINBin.clear();this->SPINBin.shrink_to_fit();

#ifdef SPINBINS
      for(int i=0;i<this->NMBINS;++i)
        this->SPINBmax.push_back(pow(10,SMin+(i+1)*logdeltaSPIN));

      for(int i=0;i<this->NMBINS;++i)
        this->SPINBin.push_back(this->SPINBmin[i]+(i+0.5)*(this->SPINBmax[i]-this->SPINBmin[i])/static_cast<double>(this->params._NMASSbins_mf()));

#elif defined SPINCUTS
      for(int i=0;i<this->NMBINS;++i)
        this->SPINBmax.push_back(pow(10, SMax));
#endif

#else

#ifdef SPINBINS
      for(int i=0;i<NMBINS;++i)
        this->SPINBmax.push_back(SMin+(i)*logdeltaSPIN);
#elif defined MCUTS
      for(int i=0;i<NMBINS;++i)
        this->SPINmax.push_back(SMax);
#endif

#endif

      So.DONE();
    }
  else
    {
#ifdef _FULL_VERBOSE_
      So.message_screen("No SPIN info available for type ", this->type_of_object);
#endif
      this->NMBINS=1;
      this->logdeltaSPIN=1;
      this->SPINBmin.resize(NMBINS,-100.0); //  if no mass is available, in the loop over the masses we set mass = 1,
      this->SPINBmax.resize(NMBINS,100.0);  //
    }




#endif

}


// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //
// ************************************************************************************************************************************************************************** //


