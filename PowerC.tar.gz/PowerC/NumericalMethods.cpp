// ******************************************************************************************
// ******************************************************************************************
// ******************************************************************************************
// This file contains some functions, based on GSL subroutines, used  in the measurements  **
// of the power spectrum                                                                   **
// Developer:                                                                              **
// Andres Balaguera Antolinez                                                              **
// abalant@gmail.com                                                                       **
// ******************************************************************************************
// ******************************************************************************************
// ******************************************************************************************
# include "NumericalMethods.h"
# include "FileOutput.h"
using namespace std;


// ********************************************************************
// ********************************************************************
// ********************************************************************
// ********************************************************************
// ********************************************************************
// ********************************************************************

// This function generates an integer in the range (0,Nmax-1)
int my_gsl_rng_uniform_(gsl_rng *r, int Nmax){
    real_prec xr=gsl_rng_uniform(r);
    real_prec delta= (1.0)/static_cast<real_prec>(Nmax);
    int val = get_bin(xr, 0., Nmax,delta, true);
    return val;

}

ULONG factorial(int n){
  if(n<=0 || n==1 ) return 1;
  else return tgammal(n+1);
}

// ********************************************************************
// ********************************************************************
// This function does the same as
//gsl_ran_shuffle(rn,&cells_id_still_to_assign[0],cells_id_still_to_assign.size(),sizeof(ULONG));

void randomize_vector(vector<ULONG>&data)
{
    const gsl_rng_type *Tn = gsl_rng_default;
    gsl_rng *rn = gsl_rng_alloc (Tn);
    gsl_rng_default_seed=155;

    int n_aux=data.size();
    vector<ULONG>cells_id_still_to_assign_aux(n_aux,0);  //container to allocate the ID of the cells with particles still to get masses
    vector<bool>cells_id_still_to_assign_chosen(n_aux,false);  //container to allocate the ID of the cells with particles still to get masses

    for(int ide=0; ide < n_aux ;++ide)
      {
        bool flag=false;
        while(false==flag)
          {
            int jk= gsl_rng_uniform_int(rn,n_aux);
            ULONG new_id=data[jk];
            if(cells_id_still_to_assign_chosen[jk]==false)
              {
                cells_id_still_to_assign_aux[ide]=new_id;  //container to allocate the ID of the cells with particles still to get masses
                cells_id_still_to_assign_chosen[jk]=true;  //container to allocate the ID of the cells with particles still to get masses
                flag=true;
              }
          }
      }

    for(ULONG ide=0; ide < n_aux ;++ide)
      data[ide]=cells_id_still_to_assign_aux[ide];  //container to allocate the ID of the cells with particles still to get masses

    cells_id_still_to_assign_aux.clear();
    cells_id_still_to_assign_aux.shrink_to_fit();

    cells_id_still_to_assign_chosen.clear();
    cells_id_still_to_assign_chosen.shrink_to_fit();


}
// ********************************************************************
// ********************************************************************
// ********************************************************************
void  get_high_res_id_from_low_res_id(int Nft_high, int Nft_low,vector<ULONG>&id_info)
{

    double delta_low=static_cast<double>(Nft_high)/static_cast<double>(Nft_low);
    for(int i=0;i<Nft_high ;++i)
      for(int j=0;j<Nft_high ;++j)
        for(int k=0;k<Nft_high ;++k)
         {
            // now get the coords of the i, j , k in the lwo res:
           ULONG il = static_cast<ULONG>(floor((i+0.5)/delta_low)); // indices of the cell of the particle
           ULONG jl = static_cast<ULONG>(floor((j+0.5)/delta_low));
           ULONG kl = static_cast<ULONG>(floor((k+0.5)/delta_low));
           ULONG id_h   = index_3d(i, j, k, Nft_high, Nft_high);
           id_info[id_h]= index_3d(il,jl,kl,Nft_low,Nft_low);
         }
}


// ********************************************************************
// ********************************************************************
// ********************************************************************


//void  get_low_res_id_from_high_res_id(int Nft, int Nft_low, vector<ULONG>&ID_low, vector<s_cell_info>&cell_info_low)
void  get_low_res_id_from_high_res_id(int Nft, int Nft_low, vector<s_cell_info>&cell_info_low)
{

    double delta_low=static_cast<double>(Nft)/static_cast<double>(Nft_low);
    for(int i=0;i<Nft ;++i)
      for(int j=0;j<Nft ;++j)
        for(int k=0;k<Nft ;++k)
         {
            // now get the coords of the i, j , k in the lwo res:
           ULONG il = static_cast<ULONG>(floor((i+0.5)/delta_low)); // indices of the cell of the particle
           ULONG jl = static_cast<ULONG>(floor((j+0.5)/delta_low));
           ULONG kl = static_cast<ULONG>(floor((k+0.5)/delta_low));
           ULONG id_l = index_3d(il,jl,kl,Nft_low,Nft_low);
           ULONG id   = index_3d(i, j, k, Nft, Nft);
           cell_info_low[id_l].gal_index.push_back(id);  // allocate for each lowres ID all those high_res id living inside
            }
}


// ********************************************************************
// ********************************************************************
// ********************************************************************
// This function returns a structure of size Nft*Nft*Nft with the info of the ID's of the neighbouring cells of eachy cell
// in a mesh of size Nft³. The parameter N_cells_back_forth controls how far we want to go from each cell in order to define "neighbours"
void get_neighbour_cells(int Nft, int N_cells_back_forth,vector<s_nearest_cells>&nearest_cells_to_cell){

    // IS IT RIGHT TO INCLUDE THE CELL ITSELF???
#if defined _USE_NEIGHBOURS_ || defined _GET_DIST_MIN_SEP_REF_ || defined _GET_DIST_MIN_SEP_MOCK_
  int max_neigh_per_dim = 1+2*N_cells_back_forth; // Number of neighbouring cells pr dimension, including the same itself;
#else
  int max_neigh_per_dim =2*N_cells_back_forth; // Number of neighbouring cells pr dimension, excluding the cell itself;
#endif

  int N_Neigh_cells=pow(max_neigh_per_dim,3); // total number of cells to explore around a cell

   vector<int> index_cells_dime(max_neigh_per_dim,0);

   for(int i=0;i< max_neigh_per_dim ;++i)
     {
       int index=N_cells_back_forth-i;
#if !defined _USE_NEIGHBOURS_ || defined _GET_DIST_MIN_SEP_REF_ || defined _GET_DIST_MIN_SEP_MOCK_
       if(index!=0)  // This excludes the cell in the center, which is the cell we are looking for the neighbours to.
#endif
           index_cells_dime[i]= index;  // e.g., 1, -1 if N_cells_back_forth=1
     }

 #pragma omp parallel for collapse(3)
   for(int i=0;i<Nft ;++i)
     for(int j=0;j<Nft ;++j)
        for(int k=0;k<Nft ;++k)
          {
            ULONG ID=index_3d(i,j,k,Nft,Nft);//get ID of cell
            nearest_cells_to_cell[ID].close_cell.resize(N_Neigh_cells,0);
#if defined _USE_NEIGHBOURS_|| defined (_GET_DIST_MIN_SEP_REF_) || defined (_GET_DIST_MIN_SEP_MOCK_)
            nearest_cells_to_cell[ID].bc_x.resize(N_Neigh_cells,0);
            nearest_cells_to_cell[ID].bc_y.resize(N_Neigh_cells,0);
            nearest_cells_to_cell[ID].bc_z.resize(N_Neigh_cells,0);
#endif
            int count=0;
               // Given this ID,
            for(int idx =0; idx < max_neigh_per_dim; ++idx)
              {
                int new_ni = i - index_cells_dime[idx];
#if defined _USE_NEIGHBOURS_|| defined (_GET_DIST_MIN_SEP_REF_) || defined (_GET_DIST_MIN_SEP_MOCK_)
                int aux_bc_x=0;
#endif
                if(new_ni<0)
                 {
                    new_ni+= Nft;
#if defined _USE_NEIGHBOURS_|| defined (_GET_DIST_MIN_SEP_REF_) || defined (_GET_DIST_MIN_SEP_MOCK_)
                    aux_bc_x=-1;
#endif
                 }
                if(new_ni>= Nft)
                  {
                    new_ni-=Nft;
#if defined _USE_NEIGHBOURS_|| defined (_GET_DIST_MIN_SEP_REF_) || defined (_GET_DIST_MIN_SEP_MOCK_)
                    aux_bc_x=1;
#endif
                 }
                for(int idy =0; idy < max_neigh_per_dim; ++idy)
                  {
                    int new_nj = j - index_cells_dime[idy];
#if defined _USE_NEIGHBOURS_|| defined (_GET_DIST_MIN_SEP_REF_) || defined (_GET_DIST_MIN_SEP_MOCK_)
                    int aux_bc_y=0;
#endif
                    if(new_nj<0)
                    {
                        new_nj+=Nft;
#if defined _USE_NEIGHBOURS_|| defined (_GET_DIST_MIN_SEP_REF_) || defined (_GET_DIST_MIN_SEP_MOCK_)
                        aux_bc_y=-1;
#endif
                    }//si la celda esta por detrñas, ponga -1
                    if(new_nj>= Nft)
                    {
                        new_nj-=Nft;
#if defined _USE_NEIGHBOURS_|| defined (_GET_DIST_MIN_SEP_REF_) || defined (_GET_DIST_MIN_SEP_MOCK_)
                        aux_bc_y=1;
#endif
                    }
                    for(int idz =0; idz < max_neigh_per_dim; ++idz)
                       {
                         int new_nk = k - index_cells_dime[idz];
#if defined _USE_NEIGHBOURS_|| defined (_GET_DIST_MIN_SEP_REF_) || defined (_GET_DIST_MIN_SEP_MOCK_)
                         int aux_bc_z=0;
#endif
                         if(new_nk<0)
                         {
                             new_nk+=Nft;
#if defined _USE_NEIGHBOURS_|| defined (_GET_DIST_MIN_SEP_REF_) || defined (_GET_DIST_MIN_SEP_MOCK_)
                             aux_bc_z=-1;
#endif
                         }
                         if(new_nk>=Nft)
                         {
                             new_nk-=Nft;
#if defined _USE_NEIGHBOURS_|| defined (_GET_DIST_MIN_SEP_REF_) || defined (_GET_DIST_MIN_SEP_MOCK_)
                             aux_bc_z=1;
#endif
                         }
                         // Get the ID of the neighbouring cells
                         nearest_cells_to_cell[ID].close_cell[count]=index_3d(new_ni,new_nj,new_nk,Nft,Nft);
#if defined _USE_NEIGHBOURS_|| defined (_GET_DIST_MIN_SEP_REF_) || defined (_GET_DIST_MIN_SEP_MOCK_)
                         nearest_cells_to_cell[ID].bc_x[count]=aux_bc_x;
                         nearest_cells_to_cell[ID].bc_y[count]=aux_bc_y;
                         nearest_cells_to_cell[ID].bc_z[count]=aux_bc_z;
#endif
                         count++;
                       }
                   }
               }
          }
}

// ********************************************************************
// ********************************************************************
// ********************************************************************
// ********************************************************************

// ********************************************************************
// ********************************************************************
void get_scalar(string FNAME,vector<real_prec>&OUT,ULONG N1,ULONG N2,ULONG N3)
{
  ULONG N=static_cast<ULONG>(N1)*static_cast<ULONG>(N2)*static_cast<ULONG>(N3);
  fftw_array<real_prec> dummy(N);
  string fname=FNAME+string(".dat");
  cout<<YELLOW<<"Reading binary file "<<CYAN<<fname<<RESET<<endl;
  bifstream inStream(fname.data(),file_is_natural);
  assert(inStream.is_open());
  inStream.get(dummy.data,N);
  inStream.close();
  
#pragma omp parallel for
  for(ULONG i=0;i<N;i++)
    OUT[i]=dummy[i];
    cout<<BOLDGREEN<<"                                               ["<<BOLDBLUE<<"DONE"<<BOLDGREEN<<"]"<<RESET<<endl;

}
// ********************************************************************
// ********************************************************************
// This is the same function write_array. Defined here to be used in the functions inherited from FSK codes
void dump_scalar(const vector<real_prec>&A_rm,ULONG N1,ULONG N2,ULONG N3,int sample_number,string fname)
{
  ULONG N=static_cast<ULONG>(N1)*static_cast<ULONG>(N2)*static_cast<ULONG>(N3);
   fftw_array<real_prec> dummy(N);

#pragma omp parallel for
  for(ULONG i=0;i<N;i++)
    dummy[i]=A_rm[i];
  
  string FNAME=fname+string(".dat");
  cout<<YELLOW<<"Writting binary file "<<CYAN<<FNAME<<RESET<<endl;
  bofstream outStream(FNAME.data(),file_is_natural);
  assert(outStream.is_open());
  outStream.put(dummy.data,N);
  outStream.close();
  cout<<BOLDGREEN<<"                                               ["<<BOLDBLUE<<"DONE"<<BOLDGREEN<<"]"<<RESET<<endl;

}


// ********************************************************************
string dto_string (double Number)
{
  stringstream ss;
  ss << Number;
  return ss.str();
}

// ********************************************************************
/*
string to_string (real_prec Number)
{
  stringstream ss;
  ss << Number;
  return ss.str();
}
*/
// ********************************************************************
real_prec gsl_integration(gsl_real (*function)(gsl_real, void *) ,void *p,gsl_real LowLimit,gsl_real UpLimit)
{
  gsl_integration_glfixed_table *wf =  gsl_integration_glfixed_table_alloc (500);
  gsl_function F;
  F.params   = p;  
  F.function = function;
  real_prec result=static_cast<real_prec>(gsl_integration_glfixed(&F,LowLimit,UpLimit,wf));
  gsl_integration_glfixed_table_free(wf);
  return  static_cast<real_prec>(result);
}    

// ********************************************************************

real_prec gsl_integration3(int N, gsl_real(*function)(gsl_real, void *) ,void *p, gsl_real LowLimit, gsl_real UpLimit)
{
  gsl_integration_glfixed_table *wf =  gsl_integration_glfixed_table_alloc (N);
  gsl_function F;
  F.params   = p;  
  F.function = function;
  real_prec result=static_cast<real_prec>(gsl_integration_glfixed(&F,LowLimit,UpLimit,wf));
  gsl_integration_glfixed_table_free(wf);
  return static_cast<real_prec>(result);
}    

// ********************************************************************

real_prec gsl_integration2(gsl_real (*function)(gsl_real, void *) ,void *p,vector<gsl_real>XX, vector<gsl_real>WW)
{
  real_prec result=0;
  int nn=WW.size();
  for(int i=0;i<nn;++i)
      result+=WW[i]*function(XX[i],p);
  return static_cast<real_prec>(result);
}    
// ********************************************************************

void gsl_get_GL_weights(gsl_real LowLimit,gsl_real UpLimit, gsl_integration_glfixed_table *wf, vector<gsl_real> &XX, vector<gsl_real>&WW)
{
  gsl_real xi, wi;
  int nn=XX.size();
#ifdef _USE_OMP_
  omp_set_num_threads(omp_get_max_threads());
#endif

  for(int i=0;i<nn;++i){
    gsl_integration_glfixed_point(LowLimit,UpLimit, i, &xi, &wi, wf);
    XX[i]=xi;
    WW[i]=wi;
  }
}    

// ********************************************************************

real_prec gsl_integration_sin_kernel(gsl_real (*function)(gsl_real, void *), void *p, gsl_real omega, gsl_real LowLimit, gsl_real UpLimit){
  int NIT=1e3;
  gsl_real result, error;
  gsl_real L=UpLimit-LowLimit;
  gsl_real relerr=0.1;
  gsl_real abserr=0.01;

  gsl_integration_workspace  *w  =  gsl_integration_workspace_alloc  (NIT); 
  gsl_integration_workspace  *wc =  gsl_integration_workspace_alloc  (NIT); 
  gsl_integration_qawo_table *wf =  gsl_integration_qawo_table_alloc (omega,L,GSL_INTEG_SINE,1000);   

  // La subrutina qawo integra una funcion f peseada con un sin(omega x), 
  // en un intervalo definido
  // con esto no necesito pasarle parametros al integrando pues en este caso f=kP(k)

  gsl_function F;
  F.params   = p;  
  F.function = function; 
  result=0;
  for(;;){
    if(gsl_integration_qawo(&F,LowLimit,abserr,relerr,NIT,w,wf,&result,&error)){
      abserr*=10;
    }
    else{
      break;
    }
  }
  gsl_integration_workspace_free (w);
  gsl_integration_workspace_free (wc);
  gsl_integration_qawo_table_free(wf);
  return static_cast<real_prec>(result);
}    

// ********************************************************************
real_prec gsl_integration_sin_kernel_lowlimit_inf2(gsl_real (*function)(gsl_real, void *), void *p, gsl_real omega, gsl_real LowLimit, gsl_integration_workspace *w,gsl_integration_workspace *wc ){
  gsl_real result, error;
  int NIT=1e3;
  gsl_real L=1;
  gsl_real relerr=0.1;
  gsl_real abserr=0.01;
  gsl_integration_qawo_table *wf =  gsl_integration_qawo_table_alloc (omega,L,GSL_INTEG_SINE,1000);
  // La subrutina qawo integra una funcion f peseada con un sin(omega x),
  // en un intervalo definido
  // con esto no necesito pasarle parametros al integrando pues en este caso f=kP(k)

  gsl_function F;
  F.params   = p;
  F.function = function;
  result=0;
  for(;;){
    if(gsl_integration_qawf(&F,LowLimit,relerr,NIT,w,wc,wf,&result,&error)){
      abserr*=10;
    }
    else{
      break;
    }
  }
  return static_cast<real_prec>(result);
}


// ********************************************************************
// ********************************************************************

real_prec gsl_integration_sin_kernel_lowlimit_inf(gsl_real (*function)(gsl_real, void *), void *p, gsl_real omega, gsl_real LowLimit){
  int NIT=1e3;
  gsl_real result, error;
  gsl_real L=1;
  gsl_real relerr=1.;
  gsl_integration_workspace  *w  =  gsl_integration_workspace_alloc  (NIT);
  gsl_integration_workspace  *wc =  gsl_integration_workspace_alloc  (NIT);
  gsl_integration_qawo_table *wf =  gsl_integration_qawo_table_alloc (omega,L,GSL_INTEG_SINE,NIT);

  // La subrutina qawo integra una funcion f peseada con un sin( omega x), 
  // el cual es en nuestro caso el que viene de j0(x)
  // con esto no necesito pasarle parametros al integrando pues en este caso f=kP(k)
  // Integramos en k para poder usar esta subrutina 
  // utiliza w = 1 con eta=kr, eta lo llamamos k arriba en las funcciones
  
  gsl_function F;
  F.params   = p;  
  F.function = function; 
  result=0;

   for(;;){
    if(gsl_integration_qawf(&F,LowLimit,relerr,NIT,w,wc,wf,&result,&error)){
      relerr*=10;
    }
    else{
      break;
    }
  }

  gsl_integration_workspace_free (w);
  gsl_integration_workspace_free (wc);
  gsl_integration_qawo_table_free(wf);
  return static_cast<real_prec>(result);
}    




// ********************************************************************
// ********************************************************************
real_prec gsl_inter_pointers(real_prec *x, real_prec *y, int n, real_prec xx){
  real_prec ans;
  gsl_real xa[n];
  gsl_real ya[n];
  for(int i=0;i<n;i++)xa[i]=*(x+i);
  for(int i=0;i<n;i++)ya[i]=*(y+i);
  gsl_interp_accel *acc = gsl_interp_accel_alloc ();
  gsl_spline *spline    = gsl_spline_alloc (gsl_interp_linear, n);
  gsl_spline_init (spline, xa, ya, n);
  ans=(xx<*x? *x : gsl_spline_eval (spline, xx, acc));
  gsl_spline_free (spline);
  gsl_interp_accel_free (acc);
  return ans;
}


// ********************************************************************
// ********************************************************************

void gsl_bspline(vector<gsl_real>&xx, vector<gsl_real>&yy, vector<gsl_real>&new_xx, vector<gsl_real> &new_yy)
{
  int n=xx.size();
  int new_n=new_yy.size();
  gsl_real x_ini=static_cast<gsl_real>(xx[0]);
  gsl_real x_fin=static_cast<gsl_real>(xx[n-1]);
  gsl_matrix *X, *cov;
  gsl_vector *c, *w;
  gsl_vector *x, *y;
  int k = 4;   /*cubic spline stands for k=4*/
  int nbreak=new_n+2-k;
  gsl_bspline_workspace *bw;
  gsl_multifit_linear_workspace *mw;
  gsl_real chisq;
  gsl_vector *B;
  X= gsl_matrix_alloc(n,new_n);
  cov= gsl_matrix_alloc(new_n,new_n);
  x = gsl_vector_alloc(n);
  y = gsl_vector_alloc(n);
  X = gsl_matrix_alloc(n, new_n);
  c = gsl_vector_alloc(new_n);
  w = gsl_vector_alloc(n);

  mw = gsl_multifit_linear_alloc(n, new_n);
  bw=gsl_bspline_alloc(k,nbreak);
  B=gsl_vector_alloc(new_n);

  gsl_bspline_knots_uniform(x_ini, x_fin,bw);

  for(int i=0;i<n;i++)gsl_vector_set(x,i,xx[i]);
  for(int i=0;i<n;i++)gsl_vector_set(y,i,yy[i]);

  
  for(int i=0;i<n;i++){
    gsl_vector_set(w,i,1e7); /**/
    gsl_real xi=gsl_vector_get(x,i);
    gsl_bspline_eval(xi,B,bw);
    for(int j=0;j<new_n;j++){
      gsl_real Bj=gsl_vector_get(B,j);
      gsl_matrix_set(X,i,j,Bj);
    }
  }
  gsl_multifit_wlinear(X,w,y,c,cov,&chisq,mw);
  {
    gsl_real xi, yi, yerr;
    for(int i=0;i<new_n; i++){
      xi=x_ini+i*(x_fin-x_ini)/(new_n-1);
      gsl_bspline_eval(xi, B, bw);
      gsl_multifit_linear_est(B, c, cov, &yi, &yerr);
      new_xx[i]=xi;
      new_yy[i]=yi;
    }
  }
//  int dof = n - new_n;
//  gsl_real tss = gsl_stats_wtss(w->data, 1, y->data, 1, y->size);
//  gsl_real Rsq = 1.0 - chisq / tss;
//  cout<<"Rsq = "<<Rsq<<endl;
//  cout<<"chisq/dof = "<<chisq/dof<<endl;

  gsl_bspline_free(bw);
  gsl_vector_free(B);
  gsl_vector_free(x);
  gsl_vector_free(y);
  gsl_matrix_free(X);
  gsl_vector_free(c);
  gsl_vector_free(w);
  gsl_matrix_free(cov);
  gsl_multifit_linear_free(mw);
  return; 
}

// ********************************************************************
// ********************************************************************
real_prec gsl_inter(gsl_real *x, gsl_real *y, int n, gsl_real xn){
  real_prec ans;
  gsl_interp_accel *acc = gsl_interp_accel_alloc ();

  gsl_spline *spline    = gsl_spline_alloc (gsl_interp_linear, n);
  gsl_spline_init (spline, x, y, n);
  ans = gsl_spline_eval (spline, xn, acc);
  gsl_spline_free (spline);
  gsl_interp_accel_free (acc);
  return  ans; 
}
// ********************************************************************
// ********************************************************************

real_prec gsl_inter_new(const vector<gsl_real> &xx, const vector<gsl_real> &yy, gsl_real xn){
  real_prec ans;
  int n=xx.size();
  gsl_interp_accel *acc = gsl_interp_accel_alloc ();
  gsl_spline *spline = gsl_spline_alloc (gsl_interp_linear, n);
  gsl_spline_init (spline, &xx[0], &yy[0], n);
  ans = gsl_spline_eval (spline, xn, acc);
  gsl_spline_free (spline);
  gsl_interp_accel_free (acc);
  return  ans; 
}




// ********************************************************************
// ********************************************************************

real_prec gsl_inter_new2(vector<real_prec> &xx, vector<vector<real_prec> > &yy, int li, real_prec xn){
  real_prec ans;
  int n=xx.size();
  gsl_real x[n],y[n];
  for(int i=0;i<n;++i)
  {
    x[i]=static_cast<gsl_real>(xx[i]);
    y[i]=static_cast<gsl_real>(yy[li][i]);
  }
  gsl_interp_accel *acc = gsl_interp_accel_alloc ();
  gsl_spline *spline    = gsl_spline_alloc (gsl_interp_linear, n);
  gsl_spline_init (spline, x, y, n);
  ans = gsl_spline_eval (spline, xn, acc);
  gsl_spline_free (spline);
  gsl_interp_accel_free (acc);
  return  ans; 
}


#ifdef SINGLE_PREC
real_prec gsl_inter_new2(vector<gsl_real> &xx, vector<vector<gsl_real> > &yy, int li, real_prec xn){
  gsl_real ans;
  int n=xx.size();
  gsl_real x[n],y[n];
  for(int i=0;i<n;++i){x[i]=static_cast<gsl_real>(xx[i]);y[i]=static_cast<gsl_real>(yy[li][i]);}
  gsl_interp_accel *acc = gsl_interp_accel_alloc ();
  gsl_spline *spline    = gsl_spline_alloc (gsl_interp_linear, n);
  gsl_spline_init (spline, x, y, n);
  ans = gsl_spline_eval (spline, xn, acc);
  gsl_spline_free (spline);
  gsl_interp_accel_free (acc);
  return  static_cast<real_prec>(ans); 
}
#endif

// ****************************************************************************************************************************
// ****************************************************************************************************************************
void sort_index(int i, int j, int k, int *ii, int *jj, int *kk){
  vector<real_prec> maa;
  maa.push_back(i);
  maa.push_back(j);
  maa.push_back(k);
  sort(maa.begin(), maa.end());
  *ii=maa.at(0);
  *jj=maa.at(1);
  *kk=maa.at(2);
  return ;
}

// ****************************************************************************************************************************
// ****************************************************************************************************************************

void matrix_inversion(vector< vector<real_prec> > &G, vector< vector<real_prec> > &y){

  int n=G[0].size();
  gsl_matrix *A  = gsl_matrix_alloc(n,n);
  gsl_matrix *Ai = gsl_matrix_alloc(n,n);
  for (int i=0;i<n;++i)
      for(int j=0;j<n;++j)
	gsl_matrix_set(A, i,j,static_cast<gsl_real>(G[i][j]));
  gsl_permutation * p = gsl_permutation_alloc(n);
  int signum;
  
  gsl_linalg_LU_decomp(A, p, &signum);
  gsl_linalg_LU_invert(A, p, Ai);
  gsl_permutation_free(p);
  for (int i=0;i<n;++i)for(int j=0;j<n;++j)y[i][j]=gsl_matrix_get(Ai, i,j);
  gsl_matrix_free (A);
  gsl_matrix_free (Ai);    
  return ;
}

// ****************************************************************************************************************************
// ****************************************************************************************************************************

void matrix_det(vector< vector<real_prec> > &G, real_prec &det){
  int n=G[0].size();
  gsl_matrix *A  = gsl_matrix_alloc(n,n);
  for (int i=0;i<n;++i)
      for(int j=0;j<n;++j)
          gsl_matrix_set(A, i,j,G[i][j]);
  gsl_permutation * p = gsl_permutation_alloc(n);
  int signum;
  gsl_linalg_LU_decomp(A, p, &signum);
  det=gsl_linalg_LU_det(A, signum);
  gsl_permutation_free(p);
  gsl_matrix_free (A);
}


// ************************************************************************************
void get_eigen(vector<vector<real_prec>>&icov_masses, vector<real_prec>&masses){
  gsl_matrix *icova;
  gsl_vector *eig;
  gsl_eigen_symm_workspace *workspace;
  int n_par=masses.size();
  icova = gsl_matrix_alloc(n_par,n_par);
  eig = gsl_vector_alloc(n_par);
  for(int i=0;i<n_par;i++)
      for(int j=0;j<n_par;j++)
          gsl_matrix_set(icova, i,j, icov_masses[i][j]);
  workspace = gsl_eigen_symm_alloc(n_par);
  gsl_eigen_symm(icova, eig, workspace);
  gsl_sort_vector(eig);
  gsl_eigen_symm_free(workspace);
  for(int ip=0;ip<n_par;ip++)masses[ip]=sqrt(gsl_vector_get(eig,ip));
}


// ************************************************************************************
void get_det_matrix(vector<vector<real_prec>>&matriz, real_prec &determinant){
  vector<real_prec>det(matriz.size(),0);
  get_eigen(matriz, det);
  determinant=1;         ;//Para escalar
  for(int i=0;i<matriz.size();i++)
     determinant*=det[i];
}




//##################################################################################

real_prec real_sh(int l, int m, real_prec theta, real_prec phi){
  return  gsl_sf_legendre_sphPlm(l,m,cos(theta))*cos(m*phi);
}

//##################################################################################

real_prec imag_sh(int l, int m, real_prec theta, real_prec phi){
  return gsl_sf_legendre_sphPlm(l,m,cos(theta))*sin(m*phi);
}

//##################################################################################

real_prec bessel(real_prec x, int n){
  return gsl_sf_bessel_jl(n,x);
}


//##################################################################################

real_prec dbessel(real_prec x, int n){
  return  (n*bessel(x,n-1)-(n+1)*bessel(x,n+1))/(2.*n+1);
}

//##################################################################################


real_prec ddbessel(real_prec x, int n){
  return  -(2/x)*dbessel(x,n)-bessel(x,n)*(1.0-n*(n+1)/pow(x,2));
}



// sort (Quicksort) by reindexing adopted from Numerical Recipes in C++
//##################################################################################

inline void SWAP_L(long &a, long &b) {
  int dum=a;
  a=b;
  b=dum;
}


//##################################################################################

void indexx(vector<int>&arr, vector<long>&indx)
{
  const int M=7,NSTACK=50;

  int n = indx.size();
  int i,indxt,ir,j,k,jstack=-1,l=0;
  int a;
  int istack[NSTACK];
  
  ir=n-1;
  for (j=0;j<n;j++) indx[j]=j;
  for (;;) {
    if (ir-l < M) {
      for (j=l+1;j<=ir;j++) {
	indxt=indx[j];
	a=arr[indxt];
	for (i=j-1;i>=l;i--) {
	  if (arr[indx[i]] <= a) break;
	  indx[i+1]=indx[i];
	}
	indx[i+1]=indxt;
      }
      if (jstack < 0) break;
      ir=istack[jstack--];
      l=istack[jstack--];
    } else {
      k=(l+ir) >> 1;
      SWAP_L(indx[k],indx[l+1]);
      if (arr[indx[l]] > arr[indx[ir]]) {
	SWAP_L(indx[l],indx[ir]);
      }
      if (arr[indx[l+1]] > arr[indx[ir]]) {
	SWAP_L(indx[l+1],indx[ir]);
      }
      if (arr[indx[l]] > arr[indx[l+1]]) {
	SWAP_L(indx[l],indx[l+1]);
      }
      i=l+1;
      j=ir;
      indxt=indx[l+1];
      a=arr[indxt];
      for (;;) {
	do i++; while (arr[indx[i]] < a);
	do j--; while (arr[indx[j]] > a);
	if (j < i) break;
	SWAP_L(indx[i],indx[j]);
      }
      indx[l+1]=indx[j];
      indx[j]=indxt;
      jstack += 2;
      if (jstack >= NSTACK) {
	cerr << "NSTACK too small in indexx." << endl;
	exit(1);
      }
      if (ir-i+1 >= j-l) {
	istack[jstack]=ir;
	istack[jstack-1]=i;
	ir=j-1;
      } else {
	istack[jstack]=j-1;
	istack[jstack-1]=l;
	l=i;
      }
    }
  }
}



//##################################################################################
void sort_vectors(vector<int>& v1,vector<int>&v2, vector<int>&v3, vector<int>& v4, vector<int>&v5, vector<int>& v6, vector<int>& v7, vector<real_prec>& v8 ){
  // v1 is to be sorted. The elements of the other vectors
  // are shuffled accordingly.

  
  unsigned long j;
  long n=v1.size();
  vector<long>iwksp(n,0);
  vector<float>wksp(n,0);
  
  indexx(v1,iwksp);
  for (j=0;j<n;++j) wksp[j]=v1[j];
  for (j=0;j<n;++j) v1[j]=wksp[iwksp[j]];

  for (j=0;j<n;++j) wksp[j]=v2[j];
  for (j=0;j<n;++j) v2[j]=wksp[iwksp[j]];

  for (j=0;j<n;++j) wksp[j]=v3[j];
  for (j=0;j<n;++j) v3[j]=wksp[iwksp[j]];

  for (j=0;j<n;++j) wksp[j]=v4[j];
  for (j=0;j<n;++j) v4[j]=wksp[iwksp[j]];

  for (j=0;j<n;++j) wksp[j]=v5[j];
  for (j=0;j<n;++j) v5[j]=wksp[iwksp[j]];

  for (j=0;j<n;++j) wksp[j]=v6[j];
  for (j=0;j<n;++j) v6[j]=wksp[iwksp[j]];

  for (j=0;j<n;++j) wksp[j]=v7[j];
  for (j=0;j<n;++j) v7[j]=wksp[iwksp[j]];


}


//##################################################################################

size_t m_getBuffer(istream& inStream) {
  
    // reset buffer
    inStream.clear();
    inStream.seekg(0, inStream.beg);

    string line = "";

    // get line from stream until is not a comment or empty
    while (false == inStream.eof() && ((true == line.empty()) || ('#' == line[0]))) {
      getline(inStream, line);
    }

    // even number of lines to read as 3MB buffer
    size_t numLines = 3*1024*1024/line.size();
    numLines += numLines&0x1;

    //    cout << "  - 3MB buffer: " << numLines << " lines";

    // reset buffer
    inStream.clear();
    inStream.seekg(0, inStream.beg);

    return numLines;
  }

//##################################################################################

size_t m_countLines(istream& inStream) {
  
  // reset stream to beginning and clear status
  inStream.clear();
  inStream.seekg(0, inStream.beg);
  
  // counter of lines
  size_t counter = -1;
  
  // line to read
  string line = "";
  
  while (false == inStream.eof()) {
    getline(inStream, line);
    counter++;
  }
  
  // reset buffer
  inStream.clear();
  inStream.seekg(0, inStream.beg);
  
  return counter;
}


//##################################################################################
//##################################################################################

real_prec get_mean(const vector<real_prec> & ini)
{
  double mean=0.;
#pragma opmp parallel for reduction(+:mean)
  for(ULONG i=0;i<ini.size();++i)
    mean+=static_cast<double>(ini[i]);
  mean/=static_cast<double>(ini.size());

  return static_cast<real_prec>(mean);
}



//##################################################################################
//##################################################################################
//##################################################################################

real_prec get_var(const vector<real_prec> & ini)
{
  real_prec mean=get_mean(ini);
  real_prec vari=0.;
#pragma opmp parallel for reduction(+:vari)
  for(ULONG i=0;i<ini.size();++i)
    vari+=pow(ini[i]-mean,2);
  vari=vari/(static_cast<double>(ini.size())-1.0);
  return vari;
}



//##################################################################################

real_prec get_var(real_prec mean, const vector<real_prec> & ini)
{
  real_prec vari=0.;
#pragma opmp parallel for reduction(+:vari)
  for(ULONG i=0;i<ini.size();++i)
    vari+=pow(ini[i]-mean,2);
  vari=vari/(static_cast<double>(ini.size())-1.0);
  return vari;
}

//##################################################################################
//##################################################################################
//##################################################################################

void log_smooth(vector<real_prec>&xin, vector<real_prec>&vin)
{

  // **************************************************************************************
  // steps:
  // i ) interpolate the raw ratio in log bins in k
  // ii) smooth the result
  // iii) interpolate the smoothed version and update power_ratio
  
  // Original modes, converted to log
  vector<gsl_real>lkvec(vin.size(),0);
  vector<gsl_real>vin_new(vin.size(),0);

#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(ULONG i = 0;i < vin.size(); ++i)
    lkvec[i]=static_cast<gsl_real>(log10(xin[i]));
  for(ULONG i = 0;i < vin.size(); ++i)
    vin_new[i]=static_cast<gsl_real>(vin[i]);

  int n_smooth=vin.size()*2;

  // Begin smooth ker_aux in log k
  // Log bins, in the same range as the original modes
  
  real_prec deltalk= static_cast<real_prec>(log10(xin[xin.size()-1.0]/xin[0])/static_cast<real_prec>(n_smooth-1.0));
  vector<gsl_real>aux_logk(n_smooth,0);
  
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(ULONG i = 0; i < n_smooth-1; ++i)
    aux_logk[i]=log10(xin[0])+i*deltalk;
  aux_logk[n_smooth-1]=lkvec[xin.size()-1];
  
  // Interpolate original ratio in log k
  vector<gsl_real>aux_oratio(n_smooth,0);
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(ULONG i = 0;i < n_smooth; ++i)
    aux_oratio[i]=gsl_inter_new(lkvec,vin_new, aux_logk[i]);
  
  // Bspline smooth ratio, already interpolated in log
  int n_smooth_new=  static_cast<int>(floor(vin.size()/2));    //60;
  vector<gsl_real>aux_kvec(n_smooth_new, 0);
  vector<gsl_real>aux_ratio(n_smooth_new, 0);

  gsl_bspline(aux_logk, aux_oratio,  aux_kvec, aux_ratio);

  // Reassign the smoothed version to Kernel_bins via interpolation
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(ULONG i = 0;i < vin.size(); ++i)
    vin[i]=gsl_inter_new(aux_kvec, aux_ratio, lkvec[i]);

}

//##################################################################################
//##################################################################################
//##################################################################################

void lin_smooth(vector<real_prec>&xin, vector<real_prec>&vin)
{

  // **************************************************************************************
  // steps:
  // i ) interpolate the raw ratio in log bins in k
  // ii) smooth the result
  // iii) interpolate the smoothed version and update power_ratio

  // Original modes, converted to log
  vector<gsl_real>lkvec(vin.size(),0);
  vector<gsl_real>vin_new(vin.size(),0);

#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(ULONG i = 0;i < xin.size(); ++i)
    lkvec[i]=static_cast<gsl_real>(xin[i]);

  for(ULONG i = 0;i < vin.size(); ++i)
    vin_new[i]=static_cast<gsl_real>(vin[i]);

  /*
  int n_smooth=static_cast<int>(floor(vin.size()/3));
  // Begin smooth ker_aux in log k
  // Log bins, in the same range as the original modes

  real_prec deltalk= (xin[xin.size()-1]-xin[0])/static_cast<real_prec>(n_smooth-1);
  vector<gsl_real>aux_logk(n_smooth,xin[0]);
  aux_logk[n_smooth-1]=lkvec[xin.size()-1];

#pragma omp parallel for
  for(ULONG i = 1; i < n_smooth; ++i)
      aux_logk[i]=xin[0]+static_cast<real_prec>(i)*deltalk;

  // Interpolate original ratio in log k
  vector<gsl_real>aux_oratio(n_smooth,0);
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(ULONG i = 0;i < n_smooth; ++i)
    aux_oratio[i]=gsl_inter_new(lkvec,vin_new, aux_logk[i]);

  // Bspline smooth ratio, already interpolated in log
*/

int n_smooth_new= static_cast<int>(floor(vin.size())/2);
  vector<gsl_real>aux_kvec(n_smooth_new, 0);
  vector<gsl_real>aux_ratio(n_smooth_new, 0);

//  gsl_bspline(aux_logk, aux_oratio,  aux_kvec, aux_ratio);



 gsl_bspline(lkvec, vin_new,  aux_kvec, aux_ratio);

  // Reassign the smoothed version to Kernel_bins via interpolation
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(ULONG i = 0;i < vin.size(); ++i)
    vin[i]=gsl_inter_new(aux_kvec, aux_ratio, lkvec[i]);

}
//##################################################################################
//##################################################################################
//##################################################################################

void gradfindif(ULONG N1,ULONG N2,ULONG N3,real_prec L1,real_prec L2,real_prec L3,vector<real_prec>in,vector<real_prec>&out,int dim)
{
    // Gradient using finite differences
#ifdef _USE_OMP_
    int NTHREADS = _NTHREADS_;
    omp_set_num_threads(NTHREADS);
#endif
    real_prec factor=static_cast<real_prec>(N1)/static_cast<real_prec>(num_2*L1);

  int N1i=static_cast<int>(N1);
  int N2i=static_cast<int>(N2);
  int N3i=static_cast<int>(N3);

#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(int x = 0; x < N1i; x++)
    for(int y = 0; y < N2i; y++)
      for(int z = 0; z < N3i; z++)
        {
          int xr, xrr, xl, xll;
          int yr, yrr, yl, yll;
          int zr, zrr, zl, zll;

          xrr = xll = xr = xl = x;
          yrr = yll = yr = yl = y;
          zrr = zll = zr = zl = z;

          switch (dim)
            {
            case 1:
              {
                xr = x + 1;
                xl = x - 1;
                xrr = x + 2;
                xll = x - 2;
                if(xr >= N1)
                  xr -= N1;
                if(xrr >= N1)
                  xrr -= N1;
                if(xl < 0)
                  xl += N1;
                if(xll < 0)
                  xll += N1;
                break;
              }
            case 2:
              {
                yr = y + 1;
                yl = y - 1;
                yrr = y + 2;
                yll = y - 2;
                if(yr >= N2)
                  yr -= N2;
                if(yrr >= N2)
                  yrr -= N2;
                if(yl < 0)
                  yl += N2;
                if(yll < 0)
                  yll += N2;
                break;
              }
            case 3:
              {
                zr = z + 1;
                zl = z - 1;
                zrr = z + 2;
                zll = z - 2;
                if(zr >= N3)
                  zr -= N3;
                if(zrr >= N3)
                  zrr -= N3;
                if(zl < 0)
                  zl += N3;
                if(zll < 0)
                  zll += N3;
                break;
              }
            }


          ULONG iinl = index_3d(xl,yl,zl,N2,N3);
          ULONG iinr = index_3d(xr,yr,zr,N2,N3);
          ULONG iinll= index_3d(xll,yll,zll,N2,N3);
          ULONG iinrr= index_3d(xrr,yrr,zrr,N2,N3);

          ULONG iout = index_3d(x,y,z,N2,N3);
          out[iout] = -static_cast<real_prec>((factor*((4.0/3.0)*(in[iinl]-in[iinr])-(1.0/6.0)*(in[iinll]-in[iinrr]))));
        }
}


//##################################################################################
//##################################################################################
void exchange_xy(int Nft,const vector<real_prec>&in, vector<real_prec>&out)
{
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(ULONG i=0;i<Nft;++i)
      for(ULONG j=0;j<Nft;++j)
         for(ULONG k=0;k<Nft;++k)
             out[index_3d(i,j,k,Nft,Nft)]=in[index_3d(j,i,k,Nft,Nft)];
}


//##################################################################################
//##################################################################################
void exchange_xz(int Nft,const vector<real_prec>&in, vector<real_prec>&out)
{
 // this is alsme meant to be column (F) to major (c) order
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(ULONG i=0;i<Nft;++i)
      for(ULONG j=0;j<Nft;++j)
         for(ULONG k=0;k<Nft;++k)
             out[index_3d(i,j,k,Nft,Nft)]=in[index_3d(k,j,i,Nft,Nft)];
}



//##################################################################################
//##################################################################################

ULONG index_10d(int i, int j, int k, int l, int m, int n, int o, int p, int q, int r, int Nj, int Nk, int Nl, int Nm, int Nn, int No, int Np, int Nq, int Nr)
{
  return  static_cast<ULONG>(r) + static_cast<ULONG>(Nr*q) +  static_cast<ULONG>(Nr*Nq*p)+ static_cast<ULONG>(Nr*Nq*Np*o) + static_cast<ULONG>(Nr*Nq*Np*No*n)+static_cast<ULONG>(Nr*Nq*Np*No)*static_cast<ULONG>(Nn*m)+static_cast<ULONG>(Nr*Nq*Np*No)*static_cast<ULONG>(Nn*Nm*l)+static_cast<ULONG>(Nr*Nq*Np*No)*static_cast<ULONG>(Nn*Nm*Nl*k)+static_cast<ULONG>(Nr*Nq*Np*No)*static_cast<ULONG>(Nn*Nm*Nl*Nk*j)+static_cast<ULONG>(Nr*Nq*Np*No)*static_cast<ULONG>(Nn*Nm*Nl*Nk*Nj*i);
}


ULONG index_11d(int i, int j, int k, int l, int m, int n, int o, int p, int q, int r, int s, int Nj, int Nk, int Nl, int Nm, int Nn, int No, int Np, int Nq, int Nr, int Ns)
{
 return  static_cast<ULONG>(s) + static_cast<ULONG>(Ns*r)+static_cast<ULONG>(Ns*Nq*q)+ static_cast<ULONG>(Ns*Nr*Nq*p)+ static_cast<ULONG>(Ns*Nr*Nq*Np*o) +static_cast<ULONG>(Ns*Nr*Nq*Np*No*n)
            +static_cast<ULONG>(Ns*Nr*Nq)*static_cast<ULONG>(Np*No*Nn*m)+static_cast<ULONG>(Ns*Nr*Nq)*static_cast<ULONG>(Np*No*Nn*Nm*l)+static_cast<ULONG>(Ns*Nr*Nq*Np*No)*static_cast<ULONG>(Nn*Nm*Nl*k)+static_cast<ULONG>(Ns*Nr*Nq*Np)*static_cast<ULONG>(No*Nn*Nm*Nl*Nk*j)+static_cast<ULONG>(Ns*Nr*Nq*Np)*static_cast<ULONG>(No*Nn*Nm*Nl*Nk*Nj*i);
}



ULONG index_12d(int i, int j, int k, int l, int m, int n, int o, int p, int q, int r, int s, int v, int Nj, int Nk, int Nl, int Nm, int Nn, int No, int Np, int Nq, int Nr, int Ns, int Nv)
{

 return static_cast<ULONG>(v) + static_cast<ULONG>(Nv*s) + static_cast<ULONG>(Nv*Ns*r)+static_cast<ULONG>(Nv*Ns*Nr*q)+static_cast<ULONG>(Nv*Ns*Nr*Nq*p)+ static_cast<ULONG>(Nv*Ns*Nr*Nq*Np*o)+ static_cast<ULONG>(Nv*Ns*Nr*Nq*Np*No*n) +static_cast<ULONG>(Nv*Ns*Nr*Nq*Np*No*Nn*m)
            +static_cast<ULONG>(Nv*Ns*Nr*Nq)*static_cast<ULONG>(Np*No*Nn*Nm*l)+static_cast<ULONG>(Nv*Ns*Nr*Nq)*static_cast<ULONG>(Np*No*Nn*Nm*Nl*k)+static_cast<ULONG>(Nv*Ns*Nr*Nq*Np*No)*static_cast<ULONG>(Nn*Nm*Nl*Nk*j)+static_cast<ULONG>(Nv*Ns*Nr*Nq*Np)*static_cast<ULONG>(No*Nn*Nm*Nl*Nk*Nj*i);
}


//##################################################################################
//##################################################################################

ULONG index_9d(int i, int j, int k, int l, int m, int n, int o, int p, int q, int Nj, int Nk, int Nl, int Nm, int Nn, int No, int Np, int Nq)
{
  return  static_cast<ULONG>(q) + static_cast<ULONG>(Nq*p) +  static_cast<ULONG>(Nq*Np*o)+ static_cast<ULONG>(Nq*Np*No*n) + static_cast<ULONG>(Nq*Np*No*Nn*m)+static_cast<ULONG>(Nq*Np*No*Nn)*static_cast<ULONG>(Nm*l)+static_cast<ULONG>(Nq*Np*No*Nn)*static_cast<ULONG>(Nm*Nl*k)+static_cast<ULONG>(Nq*Np*No*Nn)*static_cast<ULONG>(Nm*Nl*Nk*j)+static_cast<ULONG>(Nq*Np*No*Nn)*static_cast<ULONG>(Nm*Nl*Nk*Nj*i);
}


//##################################################################################
//##################################################################################
ULONG index_8d(int i, int j, int k, int l, int m, int n, int o, int p, int Nj, int Nk, int Nl, int Nm, int Nn, int No, int Np)
{
  return  static_cast<ULONG>(p) + static_cast<ULONG>(Np*o) +  static_cast<ULONG>(Np*No*n)+ static_cast<ULONG>(Np*No*Nn*m) + static_cast<ULONG>(Np*No*Nn*Nm*l)+static_cast<ULONG>(Np*No*Nn*Nm)*static_cast<ULONG>(Nl*k)+static_cast<ULONG>(Np*No*Nn*Nm)*static_cast<ULONG>(Nl*Nk*j)+static_cast<ULONG>(Np*No*Nn*Nm)*static_cast<ULONG>(Nl*Nk*Nj*i);
}

//##################################################################################
//##################################################################################
ULONG index_7d(int i, int j, int k, int l, int m, int n, int o, int Nj, int Nk, int Nl, int Nm, int Nn, int No)
{
  return  static_cast<ULONG>(o) + static_cast<ULONG>(No*n) +  static_cast<ULONG>(No*Nn*m)+ static_cast<ULONG>(No*Nn*Nm*l) + static_cast<ULONG>(No*Nn*Nm*Nl*k)+static_cast<ULONG>(No*Nn*Nm*Nl)*static_cast<ULONG>(Nk*j)+static_cast<ULONG>(No*Nn*Nm*Nl)*static_cast<ULONG>(Nk*Nj*i);
}


//##################################################################################
//##################################################################################

ULONG index_6d(int i, int j, int k, int l, int m, int n, int Nj, int Nk, int Nl, int Nm, int Nn)
{
  return  static_cast<ULONG>(n) + static_cast<ULONG>(Nn*m) +  static_cast<ULONG>(Nn*Nm*l)+ static_cast<ULONG>(Nn*Nm*Nl*k) + static_cast<ULONG>(Nn*Nm*Nl*Nk*j)+static_cast<ULONG>(Nn*Nm*Nl)*static_cast<ULONG>(Nk*Nj*i);
}
//##################################################################################
//##################################################################################
ULONG index_5d(int i, int j, int k, int l, int m, int Nj, int Nk, int Nl, int Nm)
{
  return static_cast<ULONG>(m) + static_cast<ULONG>(Nm*l)+ static_cast<ULONG>(Nm*Nl*k)+static_cast<ULONG>(Nm*Nl*Nk*j) +  static_cast<ULONG>(Nm*Nl*Nk*Nj*i);
}
//##################################################################################
//##################################################################################
ULONG index_4d(int i, int j, int k, int l, int Nj, int Nk, int Nl)
{
  return static_cast<ULONG>(l)+ static_cast<ULONG>(Nl*k)+static_cast<ULONG>(Nl*Nk*j)+ static_cast<ULONG>(Nl*Nk*Nj*i);
}
//##################################################################################
//##################################################################################
ULONG index_3d(int i, int j, int k, int Nj, int Nk)
{
  return static_cast<ULONG>(k)+static_cast<ULONG>(Nk*j)+static_cast<ULONG>(Nk*Nj*i);
}
//##################################################################################
//##################################################################################
ULONG index_2d(ULONG i, ULONG j, ULONG Nj)
{
  return j+Nj*i;
}

//##################################################################################
//#################################################################################
ULONG grid_ID(s_params_box_mas *params, const real_prec &x, const real_prec &y, const real_prec &z)
{
  ULONG i = static_cast<ULONG>(floor((x-params->min1)/params->d1)); // indices of the cell of the particle
  ULONG j = static_cast<ULONG>(floor((y-params->min2)/params->d2));
  ULONG k = static_cast<ULONG>(floor((z-params->min3)/params->d3));

  if(i==params->Nft)
    i--;
  if(j==params->Nft)
    j--;
  if(k==params->Nft)
    k--;
  
  i = static_cast<ULONG>(fmod(real_prec(i),real_prec(params->Nft)));
  j = static_cast<ULONG>(fmod(real_prec(j),real_prec(params->Nft)));
  k = static_cast<ULONG>(fmod(real_prec(k),real_prec(params->Nft)));
  
  return index_3d(i,j,k,params->Nft,params->Nft);
}
//##################################################################################
//##################################################################################
//##################################################################################
void do_fftw_r2c(int Nft, vector<real_prec>in, complex_prec *out)
{


#ifdef _USE_OMP_
  int NTHREADS = _NTHREADS_;
  omp_set_num_threads(NTHREADS);
#endif

#ifdef DOUBLE_PREC
    int *n=(int *)fftw_malloc(ic_rank*sizeof(float));
#else
  int *n=(int *)fftwf_malloc(ic_rank*sizeof(float));
#endif


  for(int i=0;i<ic_rank;++i)n[i]=Nft;
#ifdef SINGLE_PREC
#ifdef _USE_OMP_
  fftwf_init_threads();
  fftwf_plan_with_nthreads(NTHREADS);
#endif
  fftwf_plan plan_r2c=fftwf_plan_dft_r2c(ic_rank,n,&in[0],out,FFTW_ESTIMATE);
  fftwf_execute(plan_r2c);
  fftwf_destroy_plan(plan_r2c);
  fftwf_free(n);
#endif
#ifdef DOUBLE_PREC
#ifdef _USE_OMP_
  fftw_init_threads();
  fftw_plan_with_nthreads(NTHREADS);
#endif
  fftw_plan plan_r2c=fftw_plan_dft_r2c(ic_rank,n,&in[0],out,FFTW_ESTIMATE);
  fftw_execute(plan_r2c);
  fftw_destroy_plan(plan_r2c);
  fftw_free(n);
#endif
}

//##################################################################################
//##################################################################################
void do_fftw_c2r(int Nft, complex_prec *in, vector<real_prec>&out)
{

#ifdef _USE_OMP_
  int NTHREADS = _NTHREADS_;
  omp_set_num_threads(NTHREADS);
#endif
  ULONG NGRID = static_cast<ULONG>(Nft*Nft*Nft);


#ifdef DOUBLE_PREC
    int *n=(int *)fftw_malloc(ic_rank*sizeof(float));
#else
  int *n=(int *)fftwf_malloc(ic_rank*sizeof(float));
#endif


  for(int i=0;i<ic_rank;++i)n[i]=Nft;
#ifdef SINGLE_PREC
#ifdef _USE_OMP_
  fftwf_init_threads();
  fftwf_plan_with_nthreads(omp_get_max_threads());
#endif
  fftwf_plan plan_c2r=fftwf_plan_dft_c2r(ic_rank,n,in,&out[0], FFTW_ESTIMATE);
  fftwf_execute(plan_c2r);
  fftwf_destroy_plan(plan_c2r);
  fftwf_free(n);
#endif
#ifdef DOUBLE_PREC
#ifdef _USE_OMP_
  fftw_init_threads();
  fftw_plan_with_nthreads(omp_get_max_threads());
#endif
  fftw_plan plan_c2r=fftw_plan_dft_c2r(ic_rank,n,in,&out[0], FFTW_ESTIMATE);
  fftw_execute(plan_c2r);
  fftw_destroy_plan(plan_c2r);
  fftw_free(n);
#endif


#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(ULONG i=0;i<NGRID;i++)  // normalize the c2r transform
#ifdef _USE_OMP_
#pragma omp atomic update
#endif
      out[i]/=static_cast<double>(NGRID);

}


//##################################################################################
void do_fftw_3d(ULONG Nft, bool direction, complex_prec *in, complex_prec *out)
{

#ifdef _USE_OMP_
  int NTHREADS = _NTHREADS_;
  omp_set_num_threads(NTHREADS);
#endif

  ULONG factor=Nft*Nft*Nft;
  
  int Ni1=static_cast<int>(Nft);
  int Ni2=static_cast<int>(Nft);
  int Ni3=static_cast<int>(Nft);
  

  if (direction == true)//from conf space to fourier
    {
#ifdef SINGLE_PREC
      fftwf_plan fftp;
      fftp = fftwf_plan_dft_3d(Ni1,Ni2,Ni3,in,out,FORWARD,FFTW_OPTION);	
      fftwf_execute(fftp);
#endif
#ifdef DOUBLE_PREC
      fftw_plan fftp;
      fftp = fftw_plan_dft_3d(Ni1,Ni2,Ni3,in,out,FORWARD,FFTW_OPTION);	
      fftw_execute(fftp);
#endif
      
    }
  else // from fourier to conf space
    {
#ifdef SINGLE_PREC
      fftwf_plan fftp;
      fftp = fftwf_plan_dft_3d(Ni1,Ni2,Ni3,in,out,BACKWARD,FFTW_OPTION);
      fftwf_execute(fftp);
#endif
#ifdef DOUBLE_PREC
      fftw_plan fftp;
      fftp = fftw_plan_dft_3d(Ni1,Ni2,Ni3,in,out,BACKWARD,FFTW_OPTION);	
      fftw_execute(fftp);
#endif
      for(ULONG i=0;i<factor;i++)
	{// normalize the c2r transform
          out[i][REAL]/=static_cast<real_prec>(factor);
          out[i][IMAG]/=static_cast<real_prec>(factor);
	}

#ifdef SINGLE_PREC
      fftwf_destroy_plan(fftp);
#endif
#ifdef DOUBLE_PREC
      fftw_destroy_plan(fftp);
#endif


    }

  
}


//##################################################################################
//##################################################################################

void get_cumulative(const vector<real_prec> &dist, vector<real_prec> &cumu, unsigned long &NTOT_h)
{

#ifdef _USE_OMP_
  int NTHREADS = _NTHREADS_;
  omp_set_num_threads(NTHREADS);
#endif

  NTOT_h=0;
#ifdef _USE_OMP_
#pragma omp parallel for reduction(+:NTOT_h)
#endif
  for(int i=0;i<dist.size();++i)
    NTOT_h+=dist[i];
  
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
   for(int i=0;i<dist.size();++i)
    for(int j=0;j<=i;++j)
#ifdef _USE_OMP_
#pragma omp atomic update
#endif
        cumu[i]+=dist[j];

#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(int i=0;i<dist.size();++i)
#ifdef _USE_OMP_
#pragma omp atomic update
#endif
      cumu[i]/=static_cast<double>(NTOT_h);
}

//##################################################################################
//##################################################################################
real_prec get_nobjects(const vector<real_prec> &density_field)
{

#ifdef _USE_OMP_
  int NTHREADS = _NTHREADS_;
  omp_set_num_threads(NTHREADS);
#endif

  double ans=0;
#ifdef _USE_OMP_
#pragma omp parallel for reduction(+:ans)
#endif
  for(ULONG i=0;i< density_field.size();++i)
    ans+=static_cast<double>(density_field[i]);

  return static_cast<real_prec>(ans);
}

//##################################################################################
ULONG get_nobjects(const vector<ULONG> &density_field)
{

#ifdef _USE_OMP_
  int NTHREADS = _NTHREADS_;
  omp_set_num_threads(NTHREADS);
#endif

  ULONG ans=0;
#ifdef _USE_OMP_
#pragma omp parallel for reduction(+:ans)
#endif
  for(ULONG i=0;i< density_field.size();++i)
    ans+=static_cast<ULONG>(density_field[i]);

  return ans;
}

//##################################################################################
//##################################################################################
void get_overdens(const vector<real_prec>&in, vector<real_prec>&out)
{
#ifdef _USE_OMP_
  int NTHREADS = _NTHREADS_;
  omp_set_num_threads(NTHREADS);
#endif

#ifdef _FULL_VERBOSE_
    cout<<YELLOW<<"Converting to Overdensity"<<RESET<<endl;
#endif
  double mean=get_nobjects(in);
  mean/=static_cast<double>(in.size());
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(ULONG i=0;i< in.size();++i)
    out[i]=in[i]/mean-num_1;
#ifdef _FULL_VERBOSE_
  cout<<BOLDGREEN<<"                                               ["<<BOLDBLUE<<"DONE"<<BOLDGREEN<<"]"<<RESET<<endl;
#endif
}


//##################################################################################
//##################################################################################
void convert_ngp_to_cic(vector<real_prec>&in, vector<real_prec>&out)
{
#ifdef _USE_OMP_
  int NTHREADS = _NTHREADS_;
  omp_set_num_threads(NTHREADS);
#endif

  cout<<YELLOW<<"Transforming NGP to CIC "<<RESET<<endl;
  ULONG N=in.size();
  ULONG N1=static_cast<ULONG>(pow(N,1./3.))+1;
  ULONG Nhalf=static_cast<ULONG>(N1)*static_cast<ULONG>(N1)*static_cast<ULONG>(N1/2+1);  	

#ifdef DOUBLE_PREC
  complex_prec *AUX= (complex_prec *)fftw_malloc(2*Nhalf*sizeof(real_prec));
#else
  complex_prec *AUX= (complex_prec *)fftwf_malloc(2*Nhalf*sizeof(real_prec));
#endif

#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(ULONG i=0;i<Nhalf;++i)
    {
      AUX[i][REAL]=0;
      AUX[i][IMAG]=0;
    }


  
  // Convert input field to Fouroer space
  do_fftw_r2c(N1,in,AUX);
  
  vector<real_prec> coords(N1,0);
  vector<real_prec> correction(N1,0);
  
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(int i = 0 ; i < N1; ++i )
    {
      coords[i]=static_cast<real_prec>( i<=N1/2? i: i-(N1));
      real_prec xx=coords[i]*M_PI/static_cast<real_prec>(N1);
      correction[i]= i==0 ? 1.0 : sin(xx)/static_cast<real_prec>(xx) ;
    }
  
  real_prec we=0;
#ifdef _USE_OMP_
#pragma omp parallel for reduction(+:we)
#endif
  for(ULONG i=0;i< N1; i++)
    for(ULONG j=0;j< N1; j++)
      for(ULONG k=0;k< N1/2+1; k++)
	{
          real_prec cor=correction[i]*correction[j]*correction[k];
	  ULONG ind=index_3d(i,j,k, N1, N1/2+1);
	  AUX[ind][REAL]*=cor;
	  AUX[ind][IMAG]*=cor;
	  we+=cor;
	}

  do_fftw_c2r(N1,AUX,out);
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(ULONG i=0;i<N;i++)
    out[i]=(out[i]<0 ? 0: out[i]);//*(static_cast<real_prec>(N)/static_cast<real_prec>(2.0*we));
  
#ifdef DOUBLE_PREC
  fftw_free(AUX);
#else
  fftwf_free(AUX);
#endif


#ifdef _FULL_VERBOSE_
  cout<<BOLDGREEN<<"                                               ["<<BOLDBLUE<<"DONE"<<BOLDGREEN<<"]"<<RESET<<endl;  
#endif
}






//##################################################################################
//##################################################################################
void convert_cic_to_ngp(vector<real_prec>&in, vector<real_prec>&out)
{
  cout<<YELLOW<<"Transforming CIC to NGP "<<RESET<<endl;
  ULONG N=in.size();
  ULONG N1=static_cast<ULONG>(pow(N,1./3.))+1;
  ULONG Nhalf=static_cast<ULONG>(N1)*static_cast<ULONG>(N1)*static_cast<ULONG>(N1/2+1);

#ifdef DOUBLE_PREC
  complex_prec *AUX= (complex_prec *)fftw_malloc(2*Nhalf*sizeof(real_prec));
#else
  complex_prec *AUX= (complex_prec *)fftwf_malloc(2*Nhalf*sizeof(real_prec));
#endif


#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(ULONG i=0;i<Nhalf;++i)
    {
      AUX[i][REAL]=0;
      AUX[i][IMAG]=0;
    }
  // Convert input field to Fouroer space
  do_fftw_r2c(N1,in,AUX);

  vector<real_prec> coords(N1,0);
  vector<real_prec> correction(N1,0);

#pragma omp parallel for
  for(int i = 0 ; i < N1; ++i )
    {
      coords[i]=static_cast<real_prec>( i<=N1/2? i: i-(N1));
      real_prec xx=coords[i]*M_PI/static_cast<real_prec>(N1);
      real_prec corr =  i==0 ? 1.0 : static_cast<real_prec>(xx)/sin(xx) ;  //this is the inverse of sinc
      correction[i] = corr == 0. ? 1. : corr;
  }

#pragma omp parallel for
  for(ULONG i=0;i< N1; i++)
    for(ULONG j=0;j< N1; j++)
      for(ULONG k=0;k< N1/2+1; k++)
        {
          real_prec cor=correction[i]*correction[j]*correction[k];
          ULONG ind=index_3d(i,j,k, N1, N1/2+1);
          AUX[ind][REAL]*=cor;
          AUX[ind][IMAG]*=cor;
        }

  do_fftw_c2r(N1,AUX,out);

#pragma omp parallel for
  for(ULONG i=0;i<N;i++)
    out[i]=(out[i]<0 ? 0: out[i]);//*(static_cast<real_prec>(N)/static_cast<real_prec>(2.0*we));

#ifdef DOUBLE_PREC
  fftw_free(AUX);
#else
  fftwf_free(AUX);
#endif


#ifdef _FULL_VERBOSE_
  cout<<BOLDGREEN<<"                                               ["<<BOLDBLUE<<"DONE"<<BOLDGREEN<<"]"<<RESET<<endl;
#endif
}

//##################################################################################
//##################################################################################
void get_overdens(const vector<real_prec>&in, real_prec mean, vector<real_prec>&out)
{

#ifdef _FULL_VERBOSE_
  cout<<YELLOW<<"Converting to Overdensity"<<RESET<<endl;
#endif

#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(ULONG i=0;i< in.size();++i)
    out[i]=in[i]/static_cast<double>(mean)-1.0;

#ifdef _FULL_VERBOSE_
  cout<<BOLDGREEN<<"                                               ["<<BOLDBLUE<<"DONE"<<BOLDGREEN<<"]"<<RESET<<endl;
#endif
}

//##################################################################################
//##################################################################################

void get_overdens(const vector<real_prec>&in,const vector<real_prec>&weight,vector<real_prec>&out, bool wind_binary)
{

  cout<<YELLOW<<"Converting to Overdensity with weights"<<RESET<<endl;

  double mean=0;
  double veff=0;

#ifdef _USE_OMP_
#pragma omp parallel for reduction(+:mean, veff)
#endif
  for(ULONG i=0;i< in.size();++i)
   {
      mean+=static_cast<real_prec>(in[i]);
     if(false==wind_binary)
        veff+=static_cast<real_prec>(weight[i]);
     else
      if (weight[i]>0.)
        veff++;

  }
  mean/=static_cast<double>(veff);

#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(ULONG i=0;i< in.size();++i)
    out[i]=in[i]/mean-weight[i];
#ifdef _FULL_VERBOSE_
  cout<<BOLDGREEN<<"                                               ["<<BOLDBLUE<<"DONE"<<BOLDGREEN<<"]"<<RESET<<endl;
#endif
}


//##################################################################################
//##################################################################################

real_prec MAS_CIC_public(real_prec x)
{
  //////////////////////////////////////////////////////////
  // CIC Mass assignment scheme.
  //////////////////////////////////////////////////////////
  x=fabs(x);
  if(x<1)
    return 1.-x;
  else
    return 0.0;
}



// *************************************************************************************************
// *************************************************************************************************
void grid_assignment_cic(real_prec deltax, ULONG Nft, real_prec Lside, real_prec x,real_prec y,real_prec z,real_prec weight, vector<real_prec>& field)
{
  // ******************************************************
  // Boundary conditions:
  // ******************************************************
  real_prec rdelta=1./deltax;
  while(x< 0){x+=Lside;}
  while(y< 0){y+=Lside;}
  while(z< 0){z+=Lside;}
  while(x>=Lside){x-=Lside;}
  while(y>=Lside){y-=Lside;}
  while(z>=Lside){z-=Lside;}

  // *****************************************************
  // *****************************************************
  // Determining the number of cell in each direction:   *
  // Output in the range [0,N-1]                         *
  // *****************************************************
  int xc = get_bin(x,0,Nft,deltax,true);
  int yc = get_bin(y,0,Nft,deltax,true);
  int zc = get_bin(z,0,Nft,deltax,true);

  // ******************************************************
  // ******************************************************
  // Identify the cell to which this particle belongs     *
  // with its centre.                                     *
  // ******************************************************
  real_prec xx  = deltax*(static_cast<real_prec>(xc)+0.5);
  real_prec yy  = deltax*(static_cast<real_prec>(yc)+0.5);
  real_prec zz  = deltax*(static_cast<real_prec>(zc)+0.5);

  // ******************************************************
  // ******************************************************
  // Center of each cell forwards                         *
  // ******************************************************
  real_prec xxf = deltax*(static_cast<real_prec>(xc)+1.5);
  real_prec yyf = deltax*(static_cast<real_prec>(yc)+1.5);
  real_prec zzf = deltax*(static_cast<real_prec>(zc)+1.5);

  // ******************************************************
  // ******************************************************
  // Center of each cell backwards                        *
  // ******************************************************
  real_prec xxb = deltax*(static_cast<real_prec>(xc)-0.5);
  real_prec yyb = deltax*(static_cast<real_prec>(yc)-0.5);
  real_prec zzb = deltax*(static_cast<real_prec>(zc)-0.5);

  // ******************************************************
  // ******************************************************
  // Particular positions (borders)
  int Xb=(xc==0 ? Nft: xc);
  int Yb=(yc==0 ? Nft: yc);
  int Zb=(zc==0 ? Nft: zc);

  int Xf=(xc==Nft-1 ? -1: xc);
  int Yf=(yc==Nft-1 ? -1: yc);
  int Zf=(zc==Nft-1 ? -1: zc);

  // ******************************************************

  vector<int>i_idx(MAX_MAS_DEG,0);
  i_idx[0]=Xb-1;
  i_idx[1]=xc;
  i_idx[2]=Xf+1;

  vector<int>j_idx(MAX_MAS_DEG,0);
  j_idx[0]=Yb-1;
  j_idx[1]=yc;
  j_idx[2]=Yf+1;

  vector<int>k_idx(MAX_MAS_DEG,0);
  k_idx[0]=Zb-1;
  k_idx[1]=zc;
  k_idx[2]=Zf+1;

  vector<real_prec>MAS_xx(MAX_MAS_DEG,0);
  MAS_xx[0]=MAS_CIC_public((xxb- x)*rdelta);
  MAS_xx[1]=MAS_CIC_public((xx - x)*rdelta);
  MAS_xx[2]=MAS_CIC_public((xxf- x)*rdelta);

  vector<real_prec>MAS_yy(MAX_MAS_DEG,0);
  MAS_yy[0]=MAS_CIC_public((yyb- y)*rdelta);
  MAS_yy[1]=MAS_CIC_public((yy - y)*rdelta);
  MAS_yy[2]=MAS_CIC_public((yyf- y)*rdelta);

  vector<real_prec>MAS_zz(MAX_MAS_DEG,0);
  MAS_zz[0]=MAS_CIC_public((zzb- z)*rdelta);
  MAS_zz[1]=MAS_CIC_public((zz - z)*rdelta);
  MAS_zz[2]=MAS_CIC_public((zzf- z)*rdelta);

  for(int ih=0;ih<MAX_MAS_DEG;++ih)
    for(int jh=0;jh<MAX_MAS_DEG;++jh)
      for(int kh=0;kh<MAX_MAS_DEG;++kh)
          field[index_3d(i_idx[ih], j_idx[jh], k_idx[kh],Nft,Nft)]+=weight*MAS_xx[ih]*MAS_yy[jh]*MAS_zz[kh];

}



//##################################################################################
//##################################################################################

void index2coords(ULONG N, ULONG index, real_prec  *XG, real_prec *YG, real_prec *ZG )
{
  real_prec zz=index % N;
  index = static_cast<real_prec>(index)/static_cast<real_prec>(N);
  real_prec yy=index % N;
  index = static_cast<real_prec>(index)/static_cast<real_prec>(N);
  real_prec xx = index;
  *XG=xx;
  *YG=yy;
  *ZG=zz;
}


//##################################################################################
//##################################################################################
//##################################################################################
//##################################################################################

#ifdef OMPPARRANGAR
real_prec GR_NUM(gsl_rng ** SEED, real_prec sigma ,int GR_METHOD, int jthread)
{
#else
real_prec GR_NUM(gsl_rng * SEED, real_prec sigma ,int GR_METHOD)
{
#endif

  real_prec val=0.;
  switch (GR_METHOD)
    {
    case 0:
      {
#ifdef OMPPARRANGAR
        val=static_cast<real_prec>(gsl_ran_gaussian(SEED[jthread], sigma));
#else
        val=static_cast<real_prec>(gsl_ran_gaussian(SEED, sigma));
#endif
      }
      break;

    case 1:
      {
#ifdef OMPPARRANGAR
        val=static_cast<real_prec>(gsl_ran_gaussian_ziggurat(SEED[jthread], sigma));
#else
        val=static_cast<real_prec>(gsl_ran_gaussian_ziggurat(SEED, sigma));
#endif
      }
      break;

    case 2:
      {
#ifdef OMPPARRANGAR
        val=static_cast<real_prec>(gsl_ran_gaussian_ratio_method(SEED[jthread], sigma));
#else
        val=static_cast<real_prec>(gsl_ran_gaussian_ratio_method(SEED, sigma));
#endif
      }
      break;

    }
  return(val);
}

//##################################################################################
//##################################################################################
//##################################################################################
//##################################################################################

#ifdef OMPPARRANGAR
 void create_GARFIELDR(ULONG N1,ULONG N2,ULONG N3,  vector<real_prec> &delta, const vector<real_prec> &Power, gsl_rng ** seed)
{
#else
  void create_GARFIELDR(ULONG N1,ULONG N2,ULONG N3,  vector<real_prec> &delta, const vector<real_prec> &Power, gsl_rng * seed)
{
#endif
  
  
  //  FileOutput File;
  ULONG N=static_cast<ULONG>(N1)*static_cast<ULONG>(N2)*static_cast<ULONG>(N3);
  //  ULONG Nhalf=static_cast<ULONG>(N1)*static_cast<ULONG>(N2)*static_cast<ULONG>(N3/2+1);
  ULONG Nhalf = static_cast<ULONG>(N1*N2*(N3/2+1));
  cout<<YELLOW<<"Computing white noise "<<RESET<<endl;
  
#ifdef DOUBLE_PREC
  complex_prec *AUX= (complex_prec *)fftw_malloc(2*Nhalf*sizeof(real_prec));
#else
  complex_prec *AUX= (complex_prec *)fftwf_malloc(2*Nhalf*sizeof(real_prec));
#endif
  

  for (ULONG i=0;i<N;i++)
    delta[i] = static_cast<real_prec>(GR_NUM(seed,num_1,0));
  
//   string fname=string("white_noise");
  //File.write_array(fname,delta,N);  // no puedo llamar a la clase FO
  
  do_fftw_r2c(N1,delta,AUX);
  //#endif

    
    cout<<YELLOW<<"Going to the Fourier grid "<<RESET<<endl;
    
#ifdef _USE_OMP_
#pragma omp parallel for// take care!!!
#endif
    for (ULONG i=0 ; i<N1;i++)
      for (ULONG j=0 ; j<N2;j++)
	for (ULONG k=0 ; k<=N3/2;k++)
	  {
	    ULONG ihalf= index_3d(i,j,k,N2,N3/2+1);
	    ULONG iind = index_3d(i,j,k,N2,N3);
	    real_prec mass=0.0;
#ifdef FOURIER_DEF_1
	    mass=Power[iind];//testing
#endif
#ifdef FOURIER_DEF_2
            mass=Power[iind]/static_cast<real_prec>(N);
#endif


            real_prec sigma = sqrt(mass);
            AUX[ihalf][REAL]*=sigma;
            AUX[ihalf][IMAG]*=sigma;

/*
            // usa esta si queremos hacer gausr af en F space,m en ves de crear el delta y tranformarlo
            real_prec phase =2.*M_PI*gsl_rng_uniform(seed);
            real_prec sigma=gsl_ran_rayleigh(seed, sqrt(0.5*Power[iind]));
            AUX[ihalf][REAL]=sigma*cos(phase);
            AUX[ihalf][IMAG]=-sigma*sin(phase);
*/

            }
    
    do_fftw_c2r(N1,AUX,delta); 
#ifdef DOUBLE_PREC
    fftw_free(AUX);
#else
    fftwf_free(AUX);
#endif

  }
  

//##################################################################################
//##################################################################################
//##################################################################################
//##################################################################################
void create_GARFIELD_FIXED_AMP(ULONG N1,ULONG N2,ULONG N3,  vector<real_prec> &delta, const vector<real_prec> &Power, gsl_rng * seed)
 {

   ULONG N=static_cast<ULONG>(N1)*static_cast<ULONG>(N2)*static_cast<ULONG>(N3);
   ULONG Nhalf = static_cast<ULONG>(N1*N2*(N3/2+1));
   cout<<YELLOW<<"Computing white noise "<<N2<<RESET<<endl;

#ifdef DOUBLE_PREC
   complex_prec *AUX= (complex_prec *)fftw_malloc(2*Nhalf*sizeof(real_prec));
#else
   complex_prec *AUX= (complex_prec *)fftwf_malloc(2*Nhalf*sizeof(real_prec));

#endif
   cout<<YELLOW<<"Going to the Fourier grid "<<RESET<<endl;

 #ifdef _USE_OMP_
 #pragma omp parallel for// take care!!!
 #endif
     for (ULONG i=0 ; i<N1;i++)
       for (ULONG j=0 ; j<N2;j++)
         for (ULONG k=0 ; k<=N3/2;k++)
           {
             ULONG iind = index_3d(i,j,k,N2,N3);
             real_prec sigma = sqrt(Power[iind]); // In order to generate WN set sigma=1
             real_prec phase =2.*M_PI*gsl_rng_uniform(seed);

             ULONG ihalf= index_3d(i,j,k,N2,N3/2+1);
             AUX[ihalf][REAL]=sigma*cos(phase);
             AUX[ihalf][IMAG]=sigma*sin(phase);
           }


     do_fftw_c2r(N1,AUX,delta);
     real_prec meanWN=get_mean(delta);
     cout<<YELLOW<<"Mean WN = "<<CYAN<<meanWN<<RESET<<endl;
     real_prec sigma2D=get_var(meanWN, delta);
     cout<<YELLOW<<"Sigma_corr WN = "<<CYAN<<sqrt(sigma2D)<<RESET<<endl;


#ifdef DOUBLE_PREC
      fftw_free(AUX);
#else
     fftwf_free(AUX);
#endif

   }


//##################################################################################
//##################################################################################
//##################################################################################
//##################################################################################
  
void create_GARFIELDR_from_WHITENOISE(string power_file,ULONG N1,ULONG N2,ULONG N3, vector<real_prec> &in)
{

  FileOutput File;

  ULONG N=static_cast<ULONG>(N1)*static_cast<ULONG>(N2)*static_cast<ULONG>(N3);	
  ULONG Nhalf=static_cast<ULONG>(N1)*static_cast<ULONG>(N2)*static_cast<ULONG>(N3/2+1);	

  vector<real_prec>Power(N,0);
  File.read_array(power_file,Power);
#ifdef DOUBLE_PREC
  complex_prec *AUX= (complex_prec *)fftw_malloc(2*Nhalf*sizeof(real_prec));
#else
  complex_prec *AUX= (complex_prec *)fftwf_malloc(2*Nhalf*sizeof(real_prec));
#endif

  do_fftw_r2c(N1,in,AUX);
  

  real_prec factor=1;
#ifdef FOURIER_DEF_2
          factor=1./static_cast<real_prec>(N);
#endif
  
  cout<<YELLOW<<"Going into Fourier Loop to apply sqrt(P(k)) FT(WN)"<<RESET<<endl;
  
#pragma omp parallel for
  for (ULONG i=0 ; i<N1;i++)
    for (ULONG j=0 ; j<N2;j++)
      for (ULONG k=0 ; k<N3/2+1;k++)
	{
          ULONG ihalf= index_3d(i,j,k,N2,N3/2+1);
	  ULONG iind = index_3d(i,j,k,N2,N3);
          real_prec mass=factor*Power[iind];
          real_prec sigma = sqrt(mass);
	  AUX[ihalf][REAL]*=sigma;
	  AUX[ihalf][IMAG]*=sigma;
         }
  
  do_fftw_c2r(N1,AUX,in);      


#ifdef DOUBLE_PREC
  fftw_free(AUX);
#else
  fftwf_free(AUX);
#endif
}
  

//##################################################################################
//##################################################################################
//##################################################################################
//##################################################################################
real_prec k_squared(ULONG i,ULONG j,ULONG k,real_prec L1,real_prec L2,real_prec L3,ULONG N1,ULONG N2,ULONG N3)
  {
    real_prec k2=0.;
    real_prec  kfac=static_cast<real_prec>(2.*M_PI);

    real_prec deltak_x=static_cast<real_prec>(2.*M_PI)/L1;
    real_prec deltak_y=static_cast<real_prec>(2.*M_PI)/L2;
    real_prec deltak_z=static_cast<real_prec>(2.*M_PI)/L3;
    
    real_prec kx= i<=N1/2 ? deltak_x*static_cast<real_prec>(i) : -deltak_x*static_cast<real_prec>(N1-i);
    real_prec ky= j<=N2/2 ? deltak_y*static_cast<real_prec>(j) : -deltak_y*static_cast<real_prec>(N2-j);
    real_prec kz= k<=N3/2 ? deltak_z*static_cast<real_prec>(k) : -deltak_z*static_cast<real_prec>(N3-k);

    return kx*kx+ky*ky+kz*kz;

  }

//##################################################################################
//##################################################################################
//##################################################################################
//##################################################################################
 void kernelcomp(real_prec L1, real_prec L2, real_prec L3, real_prec d1, real_prec d2, real_prec d3,ULONG N1, ULONG N2, ULONG N3, real_prec smol, int filtertype, string output_dir)
 {

#ifdef _USE_OMP_
   int NTHREADS=_NTHREADS_;
   omp_set_num_threads(NTHREADS);
#endif
     cout<<YELLOW<<"Computing kernel"<<RESET<<endl;

   string fnameR=output_dir+"kernel"+to_string(N1)+"V"+to_string(L1)+"r"+to_string(smol);
   
   
   ifstream inStream;
   string ffnn=fnameR+".dat";
   inStream.open(ffnn.data());

   if (inStream.is_open() == false )
     {
       bool gauss=false;
       bool errfunc=false;
       bool tophat=false;
       
       switch (filtertype)
	 {
	 case 1:
	   gauss=true;
	   break;
	 case 2:
	   tophat=true;
	   break;
	 case 3:
	   errfunc=true;
	   break;
	 }
       
       ULONG N=static_cast<ULONG>(N1)*static_cast<ULONG>(N2)*static_cast<ULONG>(N3);
       ULONG Nhalf=static_cast<ULONG>(N1)*static_cast<ULONG>(N2)*static_cast<ULONG>(N3/2+1);
       
       vector<real_prec> out(Nhalf,0);

#ifdef DOUBLE_PREC
       complex_prec *AUX= (complex_prec *)fftw_malloc(2*Nhalf*sizeof(real_prec));
#else
       complex_prec *AUX= (complex_prec *)fftwf_malloc(2*Nhalf*sizeof(real_prec));
#endif



       real_prec asmth=num_1;
       real_prec u;
       
       real_prec rS=smol;
       real_prec rS2=rS*rS;
       real_prec kcut=smol;//2.*M_PI/rS;
       real_prec sigma=static_cast<real_prec>(.3);
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
       for (ULONG i=0;i<N1;i++)
	 for (ULONG j=0;j<N2;j++)
	   for (ULONG k=0;k<N3/2+1;k++)
	     {

	       ULONG ii=index_3d(i,j,k,N2,N3/2+1);
	       real_prec k2=k_squared(i,j,k,L1,L2,L3,N1,N2,N3/2+1);
	       
	       if (tophat==true)
		 {
		   u = sqrt(k2);
		   
		   if (u>kcut)
		     AUX[ii][REAL]=0.0;
		   else
		     AUX[ii][REAL]=num_1;
		 }
	       
	       if (errfunc==true)
		 {
		   u = static_cast<real_prec>((sqrt(k2)-kcut)/(sqrt(2.)*sigma));
		   real_prec fac = static_cast<real_prec>(erfc(u));
		   AUX[ii][REAL]=fac;
		 }
	       
	       if (gauss==true)
		 AUX[ii][REAL]=static_cast<real_prec>(exp(-k2*rS2/2.));
	       
	       
	       AUX[ii][IMAG]=0.0;

	     }
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
       for(ULONG i=0;i<Nhalf;i++)
   	   out[i]=AUX[i][REAL];

       vector<real_prec> aux(N,0);
       do_fftw_c2r(N1, AUX, aux);
	
        real_prec wtotD=0.;
#ifdef _USE_OMP_
#pragma omp parallel for reduction(+:wtotD)
#endif
        for(ULONG i=0;i<N;i++)
          wtotD+=static_cast<real_prec>(aux[i]);

	aux.clear();
	aux.shrink_to_fit();

	// Normalize kernel in Fourier space
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
        for(ULONG i=0;i<Nhalf;i++)
#ifdef _USE_OMP_
#pragma omp atomic update
#endif
          out[i]/=static_cast<real_prec>(wtotD);
	
	
	// este out debe ser en Fourier espace
       dump_scalar(out,N1,N2,N3/2+1,0,fnameR);

#ifdef DOUBLE_PREC
       fftw_free(AUX);
#else
       fftwf_free(AUX);
#endif

       }

#ifdef _FULL_VERBOSE_
   cout<<BOLDGREEN<<"                                               ["<<BOLDBLUE<<"DONE"<<BOLDGREEN<<"]"<<RESET<<endl;
#endif

 }
 

 //##################################################################################
 //##################################################################################
 //##################################################################################
 //##################################################################################
 void kernelcomp_for_boost(real_prec L, real_prec d,ULONG N, vector<real_prec>&kernel,string output_dir)
 {
#ifdef _USE_OMP_
   int NTHREADS=_NTHREADS_;
   omp_set_num_threads(NTHREADS);
#endif
   cout<<YELLOW<<"Computing kernel from ratio of HF/Linear power spectrum"<<RESET<<endl;
   string fnameR=output_dir+"kernel_boost"+to_string(N);

   ifstream inStream;
   string ffnn=fnameR+".dat";
   inStream.open(ffnn.data());

   FileOutput File;
   vector<real_prec> prop;
   string file_lin="../Output/linear_matter_power_spectrum_EH_redshift_0.000000.txt";
   int nlines=File.read_file(file_lin,prop,1);

   vector<real_prec> l_power(nlines,0);
#pragma omp parallel for
   for(int i=0;i<l_power.size();++i)
       l_power[i]=prop[1+i*2];
   prop.clear(); prop.shrink_to_fit();

   string file_nlin="../Output/non_linear_matter_power_spectrum_EH_halo_fit_redshift_0.000000.txt";
   nlines=File.read_file(file_nlin,prop,1);
   vector<gsl_real> nl_power(nlines,0);
   vector<gsl_real> kvp(nlines,0);
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
   for(int i=0;i<nlines;++i)
      kvp[i]=prop[i*2];
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
   for(int i=0;i<nlines;++i)
      nl_power[i]=prop[1+i*2];
   prop.clear(); prop.shrink_to_fit();

    for(int i=0;i<nl_power.size();++i)
      nl_power[i]=(nl_power[i]/l_power[i]);

    l_power.clear(); l_power.shrink_to_fit();

    vector<real_prec> coords(N,0);
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
    for(ULONG i=0;i<coords.size() ;++i)
      coords[i]= (i<=N/2? static_cast<real_prec>(i): -static_cast<real_prec>(N-i));

    gsl_interp_accel *acc = gsl_interp_accel_alloc ();
    gsl_spline *spline    = gsl_spline_alloc (gsl_interp_linear, nl_power.size());
    gsl_spline_init (spline, &kvp[0], &nl_power[0], nl_power.size());
    cout<<YELLOW<<"Computing kernel"<<RESET<<endl;

    real_prec delta=2.0*M_PI/static_cast<real_prec>(L);
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
    for (ULONG i=0;i<N;i++)
         for (ULONG j=0;j<N;j++)
           for (ULONG k=0;k<N/2+1;k++)
             {
              real_prec kv=  sqrt(pow(coords[i],2)+pow(coords[j],2)+pow(coords[k],2));
              int kmod=static_cast<int>(floor(kv));
              if(kmod<N/2 && kmod >0)
                kernel[index_3d(i,j,k,N,N/2+1)]=static_cast<real_prec>(gsl_spline_eval (spline,kv*delta, acc));

          }

#ifdef _FULL_VERBOSE_
   cout<<BOLDGREEN<<"                                               ["<<BOLDBLUE<<"DONE"<<BOLDGREEN<<"]"<<RESET<<endl;
#endif

 }



 //##################################################################################
 //##################################################################################
 //##################################################################################
 //##################################################################################

real_prec calc_kx(ULONG i,real_prec L1,ULONG N1)
{
  real_prec kfac=static_cast<real_prec>(2.*M_PI/L1);
  real_prec k1=0.;
  
  if (i<=N1/2)
    k1 = kfac*static_cast<real_prec>(i);
  else
    k1 = -kfac*static_cast<real_prec>(N1-i);		
  
  return(k1);
}

//##################################################################################
//##################################################################################
//##################################################################################
//##################################################################################

 
 real_prec calc_ky(ULONG j,real_prec L2,ULONG N2)
 {
   real_prec  kfac=static_cast<real_prec>(2.*M_PI/L2);
   real_prec k2=0.;
   
   if (j<=N2/2)
    k2 = kfac*static_cast<real_prec>(j);
  else
    k2 = -kfac*static_cast<real_prec>(N2-j);		
  
  return(k2);
}

//##################################################################################
//##################################################################################
//##################################################################################
//##################################################################################

real_prec calc_kz(ULONG k,real_prec L3,ULONG N3)
{
  real_prec  kfac=static_cast<real_prec>(2.*M_PI/L3);
  real_prec k3=0.;
  
  if (k<=N3/2)
    k3 = kfac*static_cast<real_prec>(k);
  else
    k3 = -kfac*static_cast<real_prec>(N3-k);		
  
  return(k3);
}

 //##################################################################################
//##################################################################################
//##################################################################################
//##################################################################################



//##################################################################################
//##################################################################################

 void convcomp(real_prec L1, real_prec L2, real_prec L3, real_prec d1, real_prec d2, real_prec d3,ULONG N1, ULONG N2, ULONG N3, const vector<real_prec>&in, vector<real_prec> &out, int filtertype,real_prec smol, string file_kernel)
{


  cout<<YELLOW<<"Convolution"<<RESET<<endl;
  ULONG N=static_cast<ULONG>(N1)*static_cast<ULONG>(N2)*static_cast<ULONG>(N3);
  ULONG Nhalf=static_cast<ULONG>(N1)*static_cast<ULONG>(N2)*static_cast<ULONG>(N3/2+1);  	
#ifdef DOUBLE_PRC
  complex_prec *AUX= (complex_prec *)fftw_malloc(2*Nhalf*sizeof(real_prec));
#else
  complex_prec *AUX= (complex_prec *)fftwf_malloc(2*Nhalf*sizeof(real_prec));
#endif
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(ULONG i=0;i<Nhalf;++i)
    {
      AUX[i][REAL]=0;
      AUX[i][IMAG]=0;
    }


  // Convert input field to Fourier space

  //read the kernel in 3D
  string fname=file_kernel+"kernel"+to_string(N1)+"V"+to_string(L1)+"r"+to_string(smol);

  // read kernel in Fourier space
  vector<real_prec> kern(Nhalf,0);
  get_scalar(fname,kern,N1,N2,N3/2+1);
   

#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for (ULONG i=0;i<Nhalf;i++)
    {
      real_prec cor=kern[i];
      AUX[i][REAL]*=cor;
      AUX[i][IMAG]*=cor;
    }

  do_fftw_r2c(N1,in,AUX);

  kern.clear();
  kern.shrink_to_fit();

  do_fftw_c2r(N1,AUX,out);

#ifdef DOUBLE_PRC
  fftw_free(AUX);
#else
  fftwf_free(AUX);

#endif


 }

 //##################################################################################
 //#################################################################################
 void convolvek(ULONG N1, vector<real_prec>&in, vector<real_prec> &kernel, vector<real_prec> &out)
{


  cout<<YELLOW<<"Convolution"<<RESET<<endl;
  ULONG N=in.size();
  ULONG Nhalf=kernel.size();
#ifdef DOUBLE
  complex_prec *AUX= (complex_prec *)fftw_malloc(2*Nhalf*sizeof(real_prec));
#else
  complex_prec *AUX= (complex_prec *)fftwf_malloc(2*Nhalf*sizeof(real_prec));
#endif

#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(ULONG i=0;i<Nhalf;++i)
    {
      AUX[i][REAL]=0;
      AUX[i][IMAG]=0;
    }

  // Convert input field to Fouroer space
  do_fftw_r2c(N1,in,AUX);
   
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for (ULONG i=0;i<Nhalf;i++)
    {
      real_prec cor=kernel[i];
      AUX[i][REAL]*=cor;
      AUX[i][IMAG]*=cor;
      }

  do_fftw_c2r(N1,AUX,out);
 
#ifdef DOUBLE
  fftw_free(AUX);
#else
  fftwf_free(AUX);
#endif

#ifdef _FULL_VERBOSE_
   cout<<BOLDGREEN<<"                                               ["<<BOLDBLUE<<"DONE"<<BOLDGREEN<<"]"<<RESET<<endl;
#endif

}




 //##################################################################################
 //#################################################################################
 void give_power(real_prec Lbox, ULONG N1, vector<real_prec>&in, vector<real_prec> &out)
{

  ULONG N=in.size();
  ULONG Nhalf=static_cast<ULONG>(N1)*static_cast<ULONG>(N1)*static_cast<ULONG>(N1/2+1);
#ifdef DOUBLE_PREC
  complex_prec *AUX= (complex_prec *)fftw_malloc(2*Nhalf*sizeof(real_prec));
#else
  complex_prec *AUX= (complex_prec *)fftwf_malloc(2*Nhalf*sizeof(real_prec));
#endif

#pragma omp parallel for
  for(ULONG i=0;i<Nhalf;++i)
      AUX[i][REAL]=0;
#pragma omp parallel for
  for(ULONG i=0;i<Nhalf;++i)
      AUX[i][IMAG]=0;

  // Convert input field to Fouroer space
  do_fftw_r2c(N1,in,AUX);

  real_prec deltak=2.*M_PI/Lbox;

  vector<real_prec> coords(N1,0);
#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(ULONG i=0;i<N1 ;++i)
    coords[i]=deltak*(i<=N1/2? static_cast<real_prec>(i): -static_cast<real_prec>(N1-i));


#ifdef _USE_OMP_
#pragma omp parallel for
#endif
  for(ULONG i=0;i< N1 ; i++)
    for(ULONG j=0;j< N1 ; j++)
      for(ULONG k=0;k< N1/2+1; k++)
        {
          ULONG ind=index_3d(i,j,k, N1, N1/2+1);
          real_prec kmod2=pow(coords[i],2)+pow(coords[j],2)+pow(coords[k],2);  // Get k**2
          real_prec f_k =0.;
          if(kmod2>0.)
//            f_k=exp(0.5*pow(kmod2, 0.2));
             f_k=2.*(1.0+tanh(2.*kmod2));

          AUX[ind][REAL]*=f_k;
          AUX[ind][IMAG]*=f_k;
        }
  coords.clear();
  coords.shrink_to_fit();

  do_fftw_c2r(N1,AUX,out);
#ifdef DOUBLE_PREC
  fftw_free(AUX);
#else
  fftwf_free(AUX);
#endif

 }


//##################################################################################
//########################################################################### 
 real_prec linearvel3d(int index, real_prec kx, real_prec ky, real_prec kz, real_prec phi)
{
  real_prec out, kl;

  switch(index)
    {
    case 1:
      {
	kl=kx;
	break;
      }
    case 2:
      {
	kl=ky;
	break;
      }
    case 3:
      {
	kl=kz;
	break;
      }
    }
  real_prec kmod2=kx*kx+ky*ky+kz*kz;

  real_prec fackern=0.0;
  if (kmod2>eps)
    fackern = kl/kmod2;
  out=fackern*phi;

  return out;
}



 //##################################################################################
 //#################################################################################
 int get_bin(real_prec x, real_prec xmin, int nbins, real_prec delta, bool accumulate)
 {
   int ibin  =  static_cast<int>(floor((static_cast<double>(x) - static_cast<double>(xmin))/static_cast<double>(delta)));
   if(ibin==nbins)ibin--;
   if(true==accumulate)
     {
       if (ibin>nbins)ibin=nbins-1; // All values above the maximum are placed in the last bin
       if (ibin<0)ibin=0; // All values below the minimum are placed in the first bin
     }
   return ibin;
 }


 //##################################################################################
//##################################################################################

real_prec tidal_anisotropy(real_prec lambda1, real_prec lambda2, real_prec lambda3)
{
//  real_prec tidal= (sqrt(0.5*(pow(lambda3-lambda1,2)+pow(lambda3-lambda2,2)+pow(lambda2-lambda1,2)))/(1.+lambda1+lambda2+lambda3));
  real_prec tidal= (sqrt(0.5*(pow(lambda3-lambda1,2)+pow(lambda3-lambda2,2)+pow(lambda2-lambda1,2)))/(1.));
  return tidal;

}

//##################################################################################
//##################################################################################
real_prec invariant_field_II(real_prec lambda1, real_prec lambda2, real_prec lambda3)
{
#ifdef _USE_EIGENVALUES_
    real_prec inv= lambda1;
#else
    real_prec inv= lambda1*lambda2 +lambda2*lambda3 + lambda1*lambda3;
#endif
    return inv;
 }

//##################################################################################
//##################################################################################

real_prec invariant_field_III(real_prec lambda1, real_prec lambda2, real_prec lambda3)
{
#ifdef _USE_EIGENVALUES_
    real_prec inv= lambda2;
#else
  real_prec inv= (lambda1*lambda2)*lambda3;
#endif
  return inv;

}

//##################################################################################
//##################################################################################

real_prec invariant_field_I(real_prec lambda1, real_prec lambda2, real_prec lambda3)
{
  real_prec inv= lambda1+lambda2+lambda3;
  return inv;
}


//##################################################################################
//##################################################################################

real_prec invariant_field_IV(real_prec lambda1, real_prec lambda2, real_prec lambda3)
{
#ifdef _USE_EIGENVALUES_
    real_prec inv= lambda3;
#else
//  real_prec inv=  pow(lambda1,3) + pow(lambda2,3) + pow(lambda3,3);
  real_prec inv=  pow(lambda1,2) + pow(lambda2,2) + pow(lambda3,2);
//  real_prec inv=  (lambda1+lambda2+lambda3)*(lambda1*lambda2 +lambda2*lambda3 + lambda1*lambda3)  ;// pow(lambda1,2) + pow(lambda2,2) + pow(lambda3,2);
#endif
  return inv;
}


//##################################################################################
//##################################################################################
//##################################################################################
//##################################################################################

real_prec ellipticity(real_prec lambda1, real_prec lambda2, real_prec lambda3)
{
  real_prec inv= (lambda1-lambda3)/(2.*(lambda1+lambda2+lambda3));
  return inv;

}

//##################################################################################
//##################################################################################

real_prec prolat(real_prec lambda1, real_prec lambda2, real_prec lambda3)
{
  real_prec inv= (lambda1+lambda3-2.*lambda2)/(2.*(lambda1+lambda2+lambda3));
  return inv;

}

//##################################################################################
//##################################################################################

 void sort_2vectors(vector<vector<int> >& v1,vector< vector<int> >&v2){
   // v1 is to be sorted. The elements of the other vectors
   // are shuffled accordingly.
   
   ULONG i, j;
   ULONG NN=v1.size();
   ULONG n=v1[0].size();

   for (i=0;i<NN;++i)
     {
       vector<long>iwksp(n,0);
       vector<float>wksp(n,0);
       vector<int>av1(n,0);
       for (j=0;j<n;++j) av1[j]=v1[i][j];
       indexx(av1,iwksp); //av1 must be int
       
       for (j=0;j<n;++j) wksp[j]=av1[j];
       for (j=0;j<n;++j) av1[j]=wksp[iwksp[j]];
       for (j=0;j<n;++j) v1[i][j]=av1[j];
       
       for (j=0;j<n;++j) wksp[j]=v2[i][j];
       for (j=0;j<n;++j) v2[i][j]=wksp[iwksp[j]];
     }
 }
 //##################################################################################
 //##################################################################################

 void sort_1dvectors(vector<int> & v1, vector<int> &v2){
   // v1 is to be sorted. The elements of the other vectors
   // are shuffled accordingly.
   
   ULONG i, j;
   ULONG n=v1.size();

   vector<long>iwksp(n,0);
   vector<float>wksp(n,0);
   vector<int>av1(n,0);
   for (j=0;j<n;++j) av1[j]=v1[j];
   indexx(v1,iwksp); //av1 must be int
   
   for (j=0;j<n;++j) wksp[j]=av1[j];
   for (j=0;j<n;++j) av1[j]=wksp[iwksp[j]];
   for (j=0;j<n;++j) v1[j]=av1[j];
   for (j=0;j<n;++j) wksp[j]=v2[j];
   for (j=0;j<n;++j) v2[j]=wksp[iwksp[j]];
   
 }


