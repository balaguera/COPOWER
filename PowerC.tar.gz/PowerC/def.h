// ****************************************************************************************
// ****************************************************************************************
/**
 * @file def.h
 * @brief Pre-processor directives for cosmicatlas
 * @author Andres Balaguera-Antolínez, Francisco-Shu Kitaura
 * @author Francisco-Shu Kitaura
 * @version   1.0 2018
 * @date      2021
 * */
// ****************************************************************************************
// ****************************************************************************************
// This order disables the use of the assert() function
// #define NDEBUG

#define _FULL_VERBOSE_
// ****************************************************************************************
#define _VERBOSE_POWER_
#define _VERBOSE_CATALOG_
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// Preproc for fast efficient runniing for andres. These only act in this file.
#define mode_p  // does the contrary
// ****************************************************************************************

#ifdef mode_p
#define _VERBOSE_POWER_
#define _VERBOSE_CATALOG_
#endif

// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ======================================================================================================================================
// ======================================================================================================================================
// ======================================================================================================================================
// ======================================================================================================================================
// ======================================================================================================================================
// ======================================================================================================================================
// ****************************************************************************************
// The following preproc directives are meant to specify the bias properties
// ****************************************************************************************
/**
 * @brief  CWEB uses the cosmic web classification CWEB only
*/
//#define _USE_CWEB_
// ****************************************************************************************
/**
 * @brief  MKNOTS uses ONLY the mass of collapsing regions (knots)
*/
//#define _USE_MKNOTS_

// ****************************************************************************************
/**
 * @brief  ikweb uses the Iweb with the mass of collapsing regions (knots)
*/
//#define _USE_IKWEB_
// ****************************************************************************************
/**
 * @brief  TWEB uses the cosmic web classification CWEB plus the mass of collapsing regions (knots)
*/
//#define _USE_TWEB_

// ****************************************************************************************
/**
 * @brief  ikweb uses the Iweb (Low res) with the mass of collapsing regions (low res knots) and cosmic web types
*/
//#define _USE_TIWEB_


// ****************************************************************************************
/**
 * @brief  IWEB uses the invariants of the tidal field I2 and I3. This can be used together with TEB,CWEB and PWEB
*/

#define _USE_IWEB_
// ****************************************************************************************
#if defined (_USE_IWEB_) || defined (_USE_IKWEB_) 
//#define _USE_INVARIANT_TIDAL_FIELD_I_  //  This takes the memory space from _USE_INVARANT_SHEAR_VFIELD_II or s²delta
#define _USE_INVARIANT_TIDAL_FIELD_II_  //  This takes the memory space from _USE_INVARANT_SHEAR_VFIELD_II or s²delta
#define _USE_INVARIANT_TIDAL_FIELD_III_  //  This takes the memory space from _USE_INVARANT_SHEAR_VFIELD_II or s²delta
#endif
// ****************************************************************************************
#if defined (_USE_TIWEB_)
//#define _USE_INVARIANT_TIDAL_FIELD_I_  //  This takes the memory space from _USE_INVARANT_SHEAR_VFIELD_II or s²delta
#define _USE_INVARIANT_TIDAL_FIELD_II_  //  This takes the memory space from _USE_INVARANT_SHEAR_VFIELD_II or s²delta
//#define _USE_INVARIANT_TIDAL_FIELD_III_  //  This takes the memory space from _USE_INVARANT_SHEAR_VFIELD_II or s²delta
#endif


/**
 * @brief  PWEB Uses the invariats of the field ð_i ð_j delta
*/
//#define _USE_PWEB_
#ifdef _USE_PWEB_
#define _USE_INVARIANT_PWEB_I_  //  This takes the memory space from _USE_INVARANT_SHEAR_VFIELD_II or s²delta
#define _USE_INVARIANT_PWEB_II_  //  This takes the memory space from _USE_INVARANT_SHEAR_VFIELD_II or s²delta
//#define _USE_INVARIANT_PWEB_III_  //  This takes the memory space from _USE_INVARANT_SHEAR_VFIELD_II or s²delta
#endif
// ****************************************************************************************
// ****************************************************************************************
/**
 * @brief  CWEB_V Uses the invariats of the velocity shear and the mass of v-collapsing regions
*/
//#define _USE_CWEB_V
// ****************************************************************************************
/**
 * @brief  TWEB_V Uses the Cosmic web classification based on the eigenvañues of the velocity shear and the mass of collapsing regions defined by the shear
*/
//#define _USE_TWEB_V_
// ****************************************************************************************
/**
 * @brief  IWEB_V Uses the invariats of the velocity shear
*/
//#define _USE_IWEB_V
#ifdef _USE_IWEB_V
#define _USE_INVARIANT_SHEAR_VFIELD_I_  // def or undef here
#define _USE_INVARIANT_SHEAR_VFIELD_II_  // def or undef here
#define _USE_INVARIANT_SHEAR_VFIELD_III_  // def or undef here
//#define _USE_INVARIANT_SHEAR_VFIELD_IV_  // def or undef here
#endif


// ****************************************************************************************
// ****************************************************************************************
/**
 * @brief  AWEB Uses the ANISOTROPY PARAMETERS (ellipticity, anisotropy, prolatnes) of the tidal field
*/
//#define _USE_AWEB_
#ifdef _USE_AWEB_
#define _USE_TIDAL_ANISOTROPY_
//#define _USE_ELLIPTICITY_
//#define _USE_PROLATNESS_
#endif


// ======================================================================================================================================
// ======================================================================================================================================
// ======================================================================================================================================
// ======================================================================================================================================
// ======================================================================================================================================
// ======================================================================================================================================
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ************************COSMOLOGICAL PARAMETERS*****************************************
/**
 * @brief If _USE_COSMO_PARS_ is defined, the code uses the cosmological parametrs from  namespaces.
 * @details If undef, BAM uses cosmo params from input parameter file.
 * @details See the file cosmological_parameters.h for the namespaces with sets of cosmological parameters
*/
#define _USE_COSMO_PARS_
// ****************************************************************************************
/**
 * @brief Namespaces for cosmological parameters
*/

#ifdef _UNITSIM_
#define _USE_UNITSIM_COSMOLOGY_
#endif

//#define _USE_PLANCK_COSMOLOGY_
#ifdef _SLICS_
#define _USE_SLICS_COSMOLOGY_
#endif


//#define _USE_MINERVA_COSMOLOGY_
// ****************************************************************************************


#define COSMOPARS Cosmo_parameters_PLANCK

// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
#define _NTHREADS_ 8



// ****************************************************************************************
// ****************************************************************************************
// DEFINE SOME COLORS
#define _USE_COLORS_

// ****************************************************************************************
/**
 * @brief Reset Color
*/
#define RESET   "\033[0m"
#ifdef _USE_COLORS_
// ********************************************
/**
 * @brief Color Black
*/
#define BLACK   "\033[30m"      /* Black */
#else
#define BLACK   RESET     /* Black */
#endif
// ********************************************



#ifdef _USE_COLORS_
/**
 * @brief Color Red
*/
#define RED     "\033[31m"      /* Red */
#else
#define RED   RESET     /* Black */
#endif
// ********************************************

#ifdef _USE_COLORS_
/**
 * @brief Color Green
*/
#define GREEN   "\033[32m"      /* Green */
#else
#define GREEN   RESET     /* Black */
#endif
// ********************************************
/**
 * @brief Color Yellow
*/
#ifdef _USE_COLORS_
#define YELLOW  "\033[33m"      /* Yellow */
#else
#define YELLOW   RESET     /* Black */
#endif
// ********************************************
/**
 * @brief Color Blue
*/
#ifdef _USE_COLORS_
#define BLUE    "\033[34m"      /* Blue */
#else
#define BLUE   RESET     /* Black */
#endif
// ********************************************
/**
 * @brief Color Magenta
*/
#ifdef _USE_COLORS_
#define MAGENTA "\033[35m"      /* Magenta */
#else
#define MAGENTA   RESET     /* Black */
#endif

// ********************************************
/**
 * @brief Color Cyan
*/
#ifdef _USE_COLORS_
#define CYAN    "\033[36m"      /* Cyan */
#else
#define CYAN   RESET     /* Black */
#endif
// ********************************************
/**
 * @brief Color White
*/
#ifdef _USE_COLORS_
#define WHITE   "\033[37m"      /* White */
#else
#define WHITE   RESET     /* Black */
#endif
// ********************************************
/**
 * @brief Color Boldblack
*/
#ifdef _USE_COLORS_
#define BOLDBLACK   "\033[1m\033[30m"      /* Bold Black */
#else
#define BOLDBLACK   RESET     /* Black */
#endif
// ********************************************
/**
 * @brief Color BoldRed
*/
#ifdef _USE_COLORS_
#define BOLDRED     "\033[1m\033[31m"      /* Bold Red */
#else
#define BOLDRED   RESET     /* Black */
#endif
// ********************************************
/**
 * @brief Color BoldGreen
*/
#ifdef _USE_COLORS_
#define BOLDGREEN   "\033[1m\033[32m"      /* Bold Green */
#else
#define BOLDGREEN   RESET     /* Black */
#endif
// ********************************************
/**
 * @brief Color BoldYellow
*/
#ifdef _USE_COLORS_
#define BOLDYELLOW  "\033[1m\033[33m"      /* Bold Yellow */
#else
#define BOLDYELLOW   RESET     /* Black */
#endif
// ********************************************
/**
 * @brief Color BoldBlue
*/
#ifdef _USE_COLORS_
#define BOLDBLUE    "\033[1m\033[34m"      /* Bold Blue */
#else
#define BOLDBLUE   RESET     /* Black */
#endif
// ********************************************
/**
 * @brief Color BoldMagenta
*/
#ifdef _USE_COLORS_
#define BOLDMAGENTA "\033[1m\033[35m"      /* Bold Magenta */
#else
#define BOLDMAGENTA   RESET     /* Black */
#endif
// ********************************************
/**
 * @brief Color BoldCyan
*/
#ifdef _USE_COLORS_
#define BOLDCYAN    "\033[1m\033[36m"      /* Bold Cyan */
#else
#define BOLDCYAN   RESET     /* Black */
#endif
// ********************************************
/**
 * @brief Color BoldWhite
*/
#ifdef _USE_COLORS_
#define BOLDWHITE   "\033[1m\033[37m"      /* Bold White */
#else
#define BOLDWHITE   RESET     /* Black */
#endif



#define COLOR_DEFINED BOLDGREEN
#define COLOR_UNDEFINED RED
// ************************************************************************************************************************************
// ************************************************************************************************************************************
// ***************************************************PRECISION************************************************************************
// ************************************************************************************************************************************
// ************************************************************************************************************************************
//
// /**
// * @brief Define double precision for cosmicatlas
// * @details Applies all over the code except for gsl-type defined variables/containers
// */
//
// ********************************************************************************************************************************************
/**
*@brief Dynamical way of populating bins of density, MK, etc with the reference number of cells
*/
#define _DYNAMICAL_SAMPLING_  //optimal, faster

// ************************************************************************************************************************************
/**
 * @brief Define double precision for cosmicatlas
 * @details Applies all over the code except for gsl-type defined variables/containers
*/
//#define DOUBLE_PREC
//******************************************************
#ifndef DOUBLE_PREC
/**
 * @brief Define single precision for cosmicatlas
 * @details Applies all over the code except for gsl-type defined variables/containers
 * @details Defined when DOUBLE_PREC is undefined
*/
#define SINGLE_PREC
#endif
// ************************************************************************************************************************************
// Define Output type for binary arrays. If we work in double, we can ask to print bin files in double or float.
// If working with float, outputs will be by default in float
//#define OUTPUT_PREC_DOUBLE
#ifndef OUTPUT_PREC_DOUBLE
#define OUTPUT_PREC_FLOAT
#endif
// ************************************************************************************************************************************
// ************************************************************************************************************************************
// ************************************************************************************************************************************
/**
 * @brief This directive (if !defined) encloses any function that we wish to deprecate. Applied in the .cpp files
*/
#define _DEPRECATED_

// ************************************************************************************************************************************
// ************************************************************************************************************************************
// ************************************************************************************************************************************
#define _USE_HEALPIX_

//#define _USE_HEALPIX_DNDZ_

/**
 * @brief Precision fopr Healpix
*/
#define healpix_real double
// ************************************************************************************************************************************
/**
 * @brief Precision for GSL
*/
#define gsl_real double  // Even with single precision, gsl will use double precision for all its calculations

// ********************************************************************************************************************************************
#ifdef SINGLE_PREC
/**
 * @brief Precision at output
*/
#define _PREC_OUTPUT_ 4
// ********************************************
/**
 * @brief Define if the BAM_CATS are to be written
*/
//#define _WRITE_BAM_CATALOGS_
// ********************************************
/**
 * @brief Define if the BAM  cats are to be written in binary files. If undef, ascii files are written.
*/
//#define _WRITE_BINARY_BAM_FORMAT_

// ********************************************
/**
 * @brief 
*/
#define _WRITE_COORDINATES_
#define _APPLY_PERIODIC_BC_
// ********************************************
/**
 * @brief Define if the BAM  cats are to be written in binary files. If undef, ascii files are written.
*/
#define _WRITE_VELOCITIES_
// ********************************************
/**
 * @brief Define if the BAM  cats are to be read in binary files. If undef, ascii files are read.
*/
#ifdef mode_p
//#define _READ_BINARY_BAM_FORMAT_
#endif
//#define _READ_BINARY_BAM_FORMAT_

// ********************************************
/**
 * @brief // When defined, this allows for a raw metadata content, showing the name of the variables, its units.
*  @details Not yet working. Leave undefined.
*/
//#define _OUTPUT_WITH_HEADERS_

// ********************************************
/**
 * @brief Precision for FFT operations
*/
#define fftwf_real float
// ********************************************

#ifndef real_prec
/**
 * @brief Effective Precision for cosmicatlas
*/
#define real_prec fftwf_real
#endif


/**
 * @brief Effective Precision for complex containers used in FFTW
*/
#define complex_prec fftwf_complex
#endif
// ********************************************
// **************************************************************************************
#ifdef DOUBLE_PREC
#define _PREC_OUTPUT_ 6
#define fftw_real double
#define real_prec fftw_real
#define complex_prec fftw_complex
#endif
// ********************************************


// ********************************************
// Number of properties of a default halo catalog from BAM.
/**
 * @brief Number of properties to be allocated in a BAM_MOCK CAT
*/
#define N_PROP_CAT 10
#define MIN_N_PROP_CAT 6
// ********************************************
#define BIG_NUMBER 1e7
// ********************************************

#define ULONG unsigned long
// ********************************************
#define LONG long
// ********************************************
#define UULONG unsigned long long
// ********************************************
#define ASCII "ascii"
// *************************************************************
/**
 * @brief Precision type of the input par file of the DM field
*/
#define PrecType_X float
// ************************************************************************************************************************************
/**
 * @brief Precision type of the input par file of the Tracer field
*/
#define PrecType_Y float

// ************************************************************************************************************************************
// ************************************************************************************************************************************
// ************************************************************CONSTANTS***************************************************************
// ************************************************************************************************************************************
// Define some constant factors
#define REAL 0
#define IMAG 1
#define ONE static_cast<int>(1)
#define KNOT_MAX_SIZE static_cast<ULONG>(100000000)
#define V_MAX_SIZE 100000000
#define LARGE_NUMBER 1e20
#define MINUS_LARGE_NUMBER -100000000
#define NOCELL -2
#define NOVEL -999

#define I_KNOT 1
#define I_FILAMENT 2
#define I_SHEET 3
#define I_VOID 4

#define NMIN_X_ONECELL 0
#define NMIN_Y_ONECELL 0

#define num_1   static_cast<double>(1.)
#define num_2   static_cast<double>(2.)
#define num_0_1 static_cast<double>(0.1)
#define num_0_5 static_cast<double>(0.5)
// ********************************************
// Number of mdoes used to get an estimate of the average bias on large
#define N_MODES 20
// Initial mode
#define N_MODE_INI 0
// Initial index (0..Nft) used to measure the residuals from INITIAL_MODE_RESIDUALS up to Nft/2
#define INITIAL_MODE_RESIDUALS 1
// ********************************************
// NUmbers used in the class measuring power spectrum
//#define CHUNK 27
#define ic_rank 3 // For FFTW in 3 dimensions
#define NUMBER_WEIGHTS 4
#define ZERO 0

// ********************************************
#define TOLERANCE_FACTOR 10


// ************************************************************************************************************************************
// ************************************************************************************************************************************
// ************************************************************FUNCTIONS***************************************************************
// ************************************************************************************************************************************
// *************************************
/**
*@brief Absolute value
*@return  Absolute value of variable x
*/
#define myfabs(x) (*((int*)&x + 1) &= 0x7FFFFFFF)
// *************************************
/**
*@brief Bias model
*@return Bias model to pupulate DM density fields with overdensity x
*/
#define bias_test(x,alpha, rhoep, ep) (pow(1+x, alpha)*exp(-pow( (1+x)/rhoep, ep)))
// *************************************
/**
*@brief |r|
*@return  modulus of vector with coordinates x, y, z
*/
#define _get_modulo(x,y,z) sqrt(x*x+y*y+z*z)
// *************************************
/**
*@brief 100000|r|
*@return  modulus squared of vector with coordinates x, y, z multiplied by a large number
*/
#define _get_modulo_squared(x,y,z)  static_cast<ULONG>(100000.0*(x*x+y*y+z*z))
// *************************************
/**
*@brief 100000|r|
*@return  modulus squared of vector with coordinates x, y, z
*/
#define _get_modulo_squared_n(x,y,z) static_cast<real_prec>(x*x+y*y+z*z)
// ************************************************************************************************************************************
/**
*@brief Mmax (sigma_v) for dark matter halos of the slics. 
*@return  For a given x=sigma_v, halos cannot have masses above this limit
*/
#define limit_mass_halos(x) (1.5e11*pow(x,1.1)+1.5e11*pow(x,2.8))
// ************************************************************************************************************************************
/**
*@brief x sigma_v(Mv) for dark matter halos of the slics.
*@return  For a given x=M, halos cannot have sigma_v below this limit
*/
#define limit_vmax_halos(x) ((7.02e-6)*pow(x,0.405)+(1.1e-5)*pow(x,0.415))
// ************************************************************************************************************************************
// ********************************************************GENERAL STUFF AND OMP*******************************************************
// ************************************************************************************************************************************

// *************************************
/**
*@brief This allows the binning function to place in the extremes values outside the ranges
*/
#define _BIN_ACCUMULATE_
// ************************************************************************************************************************************
//#define _SHOW_ISSUES_
// ************************************************************************************************************************************
/**
*@brief Use OMP parallelization
*/
#define _USE_OMP_
// *************************************************************
/**
* @brief Parallelism with OMP.
* @details Define to test parallel regions. Once these are properñly paralelized, change the def there to _USE_OMP_
* @details  Used now in %%new_new not working in the first loop of that function when thereshold_randoms is used
*/
#ifdef _USE_OMP_
#undef _USE_OMP_TEST_ 
#endif
// *************************************************************
/**
* @brief Parallelism with OMP.
* @details Define to test parallel regions. Once these are properñly paralelized, change the def there to _USE_OMP_
* @details  // Used now in %%new_new in assignmetn of 2nd-type prop, e.g. mvir, spin, rs. Working
*/
#ifdef _USE_OMP_
#define _USE_OMP_TEST2_
#endif
// *************************************************************
/**
* @brief Parallelism with OMP.
* @details Define to test parallel regions in the Catalog class. Once these are properñly paralelized, change the def there to _USE_OMP_
* @details So far the regions under this definition are giving problems, for these contains arrays with indices being updated from different threads. Leave undefineds
* @default Leave uncomment. Some loops cannot not be easily parallelized. This situation is also found in Bam:makecat()
*/
#ifdef _USE_OMP_
#undef _USE_OMP_TEST_CAT_
#endif
// *************************************************************
/**
 * @brief Parallelism with OMP.
 * @details Define to test parallel regions in the BAM, specially at the multi-level assignment
*/
//#define _USE_OMP_BARR_L4_
//#define _USE_OMP_BARR_L3_
//#define _USE_OMP_BARR_L2_
//#define _USE_OMP_BARR_L1_
//#define _USE_OMP_BARR_L0_
// used to parallelize assignments in do{} loops in Bam.cpp.
// The current implementation is not what I what, for it allows the assignment to a bit more number of objects than what I have defined through the tolerance and the thresholds
// Nevertheless, given that in the case in which the DM are not that used in the calibration,the tolerance are <1, and that excess induced by the parallelization just brings
// the figures towarsd the original values, so it compensates.
// *************************************************************
#ifdef _USE_OMP_
#define OMPPARRAN
#define OMPPARRANRSD
#define OMPPARGAR
#endif
// ************************************************************************************************************************************
//#define _ADD_NOISE_
#ifdef _ADD_NOISE_
#define MEAN_NEW static_cast<real_prec>(1000.0)
#endif
// ************************************************************************************************************************************
// ************************************************************************************************************************************
// ************************************************************************************************************************************
// *************************************************PATCHY ****************************************************************************

/**
*@brief This is defiend in the case when, in Catalog::read_input_bin, several .dat (binary) files are read as input in positions and velocities,
and the interpolation of density fields on a grid are perfoemd at while reading these files. This also affects the function, get_density_CIC and NGC in massFunctions
since we should not initialize the delta arrays there, as they are being filled in parallel with the reading.
*/
#undef _GET_INTERPOLATED_FIELDS_FROM_BIN_FILES_
//#ifdef _GET_INTERPOLATED_FIELDS_FROM_BIN_FILES_
/**
*@brief Compute the NGP interpolated density field from an input catalog
*/

#undef _GET_NGP_DENS_FIELD_

/**
*@brief Compute the CIC interpolated density field from an input catalog
*/
#define _GET_CIC_DENS_FIELD_
/**
*@brief Compute the TSC interpolated density field from an input catalog
*/
#undef _GET_TSC_DENS_FIELD_
#undef _GET_VEL_FIELD_


//#endif
// ************************************************************************************************************************************
// ************************************************************************************************************************************
// *******************************************************REFERENCE TRACER CATALOG ****************************************************
// ************************************************************************************************************************************


// *********************************************************************
/**
*@brief If defined: The code selects objects from the input ref catalog using a minimum MASS, even if the observable is other quantity such as the vmax
*/
#define _SET_CAT_WITH_MASS_CUT_
// *********************************************************************


#ifndef _SET_CAT_WITH_MASS_CUT_
// Define this when power spectrum (-m opiton) is to me measured in cuts of VMAX
// In this case undef  _USE_MASS_TRACERS_
// Recall to undef _SET_GLOBAL_MASS_CUT_ below to use the -m option
// For -c option, undefine, and let mass define the cut
#undef _SET_CAT_WITH_VMAX_CUT_
#undef _SET_CAT_WITH_RS_CUT_
#undef _SET_CAT_WITH_SPIN_CUT_
#endif






#if defined (_SET_CAT_WITH_MASS_CUT_) || defined (_SET_CAT_WITH_VMAX_CUT_) || defined (_SET_CAT_WITH_RS_CUT_) || defined (_SET_CAT_WITH_SPIN_CUT_)
#define _SET_CAT_WITH_CUT_
#endif

#define MASS_SCALE static_cast<double>(1e12)

// This allows to read (if already created from the ref cat) the mass density field of the tracers
// Define ALSO when _READ_REF_CATALOG_ is defined in order to allow the reading of the masses of the tracer catalog
#define _USE_MASS_TRACERS_

// ***********************************************

// Define if the information on the satellite fraction is encoded in the ref catalog and is to be used
//#define _USE_SAT_FRACTION_
// ***********************************************

// Define if the information of the tracer velocities iºs present and is to be used
//#define _USE_VELOCITIES_TRACERS_

// ***********************************************
// ***********************************************

// Defining something as OBSERVABLE, asks the code
// to compute all possible diagnosis as a function of cuts or bins
// in that particular quantity.
// The user must indicate the position of the VMAX in the -ini file in the slot for i_mass
// and specify mins and max in logMMIN and logMMX
// ***********************************************
/**
 * @brief Use the tracer mass as first observable 
*/
#ifdef mode_p
#define _USE_MASS_AS_OBSERVABLE_
#endif
// ***********************************************
/**
 * @brief Use the tracer Vmax as first observable
*/
#define _USE_VMAX_AS_OBSERVABLE_

#ifndef _USE_VMAX_AS_OBSERVABLE_
#define _USE_MASS_AS_OBSERVABLE_
#endif


// ***********************************************
#ifdef _USE_VMAX_AS_OBSERVABLE_
#define _USE_VMAX_TRACERS_
#endif

// ***********************************************
// ***********************************************
/**
*@brief  When defined, BAM gets the vmax-mass scaling relation P(Mass|Vmax) or P(Vmax|Mass) and uses it to assign masses/vmax
 *once vmax/mass has been assigned.
*@details  In the end we obtain the right vmax-mass relation, the correct vmax function and
 3% residuals (over all mass range) in the mass function. Doing this allows us to increase the number of vmax bins
 as is explicitely shown below in the definition of N_VMAX_BINS
 Inside this definition we can add delta and use P(MKvir|Vmax, delta) or I/T web dependencies to use
 P(Mass|Vmax, {\theta})
*/
#define test_vmax_mass
// ***********************************************

#ifdef test_vmax_mass
/** 
*@brief When defined, add the DM information to obtain the mass from the conditional probability distribution P(Mass|Vmax, delta)
*/
#define _add_dm_density_
// ***********************************************
/** 
*@brief When getting P(M|V,delta) this factor increases NX (rad from parameter file) to EXTRA_BINS*NX the number of dm bins used.
*@details Use it >1 when using e.g IWeb with NX=100 for vmax assignment. INstnaces of TWEB use to have NX=500, in that case set this to 1 
*/
#define EXTRA_DM_BINS  static_cast<int>(1)
// ***********************************************

#ifdef _add_dm_density_
// When defined, addf to dm the information from the Iweb or Tweb and use P(Mass|Vmax, {\theta})
//#define _add_Xweb_  // not recommended
#endif

#endif

// ***********************************************
// ***********************************************
// ***********************************************
// ***********************************************
// ***********************************************

// ********************************************************************************************************************************************

#ifdef _USE_VMAX_AS_OBSERVABLE_
// ***********************************************
/**
*@brief This asks the code to assign halo masses after having assingned vmax
*/
#define _ASSIGN_MASS_POST_
// ***********************************************

#ifdef test_vmax_mass
#define N_VMAX_BINS static_cast<ULONG>(400)
#else
#define N_VMAX_BINS static_cast<int>(50)
#endif
#endif
// ***********************************************

#ifdef _USE_MASS_AS_OBSERVABLE_
#define _ASSIGN_VMAX_POST_
#define N_VMAX_BINS static_cast<ULONG>(400)
#endif


#if defined _USE_MASS_TRACERS_ || defined _USE_VMAX_TRACERS_
#define _ASSIGN_PROPERTY_
//#undef _ASSIGN_PROPERTY_

#endif


#ifdef _USE_MASS_TRACERS_
//#define _USE_MASS_FIELD_
//#define _test_mass_assign_    // UNDEF WHEN MASS ARE DONE!! THIS IS MEANT TO SPEED THE CODE UNDER TESTINT THE COLLAPSE OF RANDOMS
#endif


//#define _GET_DIST_MIN_SEP_REF_

//#define _GET_DIST_MIN_SEP_MOCK_

// ***********************************************
// Use the Log10 of the trcer property under study
//#define _USE_LOG_MASS_
// ***********************************************

// Maximum of the property (log, or sqrt, or whatever is selected above)
#define MAX_PROPERTY 16
#define _COUNTS_ "COUNTS"
#define _DENSITY_ "DENSITY"
#define _MASS_ "mass"
#define _VMAX_ "vmax"
#define _RS_ "Rs"
#define _VIRIAL_ "virial"
#define _SAT_FRACTION_ "sat_fraction"
#define _SPIN_ "SPIN"
#define _TRACER_ "TRACER"

// Please fix this
#define _MASS_LOG_   //ueful to measaure mass (or vmax) function
#define MBINS  /// 

#define N_MASS_BINS static_cast<ULONG>(200) // for assignment

//#define _USE_RS_AS_DERIVED_OBSERVABLE_
#define _RS_LOG_
#define RSBINS
#define _USE_RS_TRACERS_

//#define _USE_SPIN_AS_DERIVED_OBSERVABLE_
#define _SPIN_LOG_
#define SPINBINS
#define _USE_SPIN_TRACERS_

// If we waant to reconstruct another property, we have to set in params files min and max of that propert. Define mins and max in Params.h,cpp
// and add ifs in Bam. in function get_X_function_complement.
// In



#define _VEL_UNITS_MPC_PER_h_    // define if the velocities in the final cat are to be given in Mpc/h

// ************************************************************************************************************************************
// ************************************************************************************************************************************
// ************************************************************************************************************************************
// **********************************************************POWER SPECTRUM **********************************************************
// ************************************************************************************************************************************
// Directives for the section of the code measuring Pk,(called with -m at compillation time)
// This definition has to work together with the one in the input parameter file.
// This only works on the method PowerSpectrumF::compute_power_spectrum(book, bool)
// to get power spectrum reading a catalog

//#define _CHECK_PARTICLES_IN_BOX_
//#define _USE_WEIGHTS_IN_POWER_              //This must be defined if weighs, as specified in the parameter file, are to be used in the determination of power spectrum
//#define _GET_BISPECTRUM_NUMBERS_   // This doe snot compute bispctrum, but allows to compute numbers used in the shot noise and normalziation of that statistics. Verify that this is de fined when that option is demanded from parfile

// DEFINE when the option -p is to be used

//If _POWER_ is defiened, the code distinguishes between the observed quantity and the defining (setting) quantity.
//The observed quantity is that with respect to which bins or cuts are to be done in order to measure power
// while the defining quantity is that global cut used to define the full sample.
// That is, we can have a halo catalog with mass above some mcut, and still want to make bins in Vmax
// If _POWER_ is undef, i.e, for BAM,  we shall assume that the catalog is DEFINED by the minimum halo MASS

#define _POWER_  


// These three disjoint options are to be used with the -p compilling flag.
#define _USE_ALL_PK_


#ifdef mode_p
//#define _USE_MASS_BINS_PK_   //aplies for bins in the property specified by _USE_MASS_AS_OBSERVABLE_POWER_
//#define _USE_MASS_CUTS_PK_
#endif

// *******************************************************************************************************************************************
/**
* @brief Define this when measuring power from a grid with uts in number counts: P(k;N>=)
*/
//#define _NCUTS_POWER_
#define N_MAX_OCCUPATION 20
// ********************************************


#ifdef _USE_MASS_BINS_PK_
// Define which property is to be binned when measuring pwoer spectrum. If no binning is desired,
//#define _USE_MASS_AS_OBSERVABLE_POWER_
#define _USE_VMAX_AS_OBSERVABLE_POWER_
//#define _USE_RS_AS_OBSERVABLE_POWER_
//#define _USE_SPIN_AS_OBSERVABLE_POWER_
#endif


#ifdef _USE_MASS_CUTS_PK_
// Define which property is to be binned when measuring pwoer spectrum. If no binning is desired,
//#define _USE_MASS_AS_OBSERVABLE_POWER_
#define _USE_VMAX_AS_OBSERVABLE_POWER_
//#define _USE_RS_AS_OBSERVABLE_POWER_
//#define _USE_SPIN_AS_OBSERVABLE_POWER_
#endif


// This is meant to measure power spectrum when passing the structure tracer.Halo
// This is due to the fact that when one reads the cat and measures P(k), one can pass the minimum cut
#ifdef _USE_MASS_CUTS_PK_
#define _SET_GLOBAL_MASS_CUT_
#ifdef _USE_MASS_AS_OBSERVABLE_POWER_
#define MINIMUM_PROP_CUT_original static_cast<real_prec>(2e13) // put the largest of the mcuts used in power, for comparison purposes
#define MINIMUM_PROP_CUT static_cast<real_prec>(pow(MINIMUM_PROP_CUT_original, exponent_mass_tracer))
#elif defined _USE_VMAX_AS_OBSERVABLE_POWER_
#define MINIMUM_PROP_CUT static_cast<real_prec>(500.0)
#endif
#endif

// Define if the 2D power spectrum in paralllel and perpendicular wavevectors is to be computed and written
//#define _WRITE2DPOWER_

// Define if the the power spectrum will be measured from redshift space in case we want to shift positions with known velocity field.
// If we deal with a survey in equatorial coordinates, RSD are alrady included, so leave undefined.

// *******************************************************************************************************************************************
/**
* @brief Define this when measuring power in redshift space
* @detail Define also when building mocks. Bam will measure real and redshift space
*/
//#define _REDSHIFT_SPACE_
// *******************************************************************************************************************************************
/**
* @brief Identify the line of sight in order to move particles in redshift space
*/
#define LOS 3
// *******************************************************************************************************************************************
/**
* @brief 
*/
#ifdef _REDSHIFT_SPACE_
#define _WRITE_MULTIPOLES_
#endif

// *******************************************************************************************************************************************
/**
* @brief If defined, the code selects redshisft bin interval given in the input parameter file in order to compute the power spectrum.
*/
#ifdef _POWER_
//#define _USE_REDSHIFT_BINS_
#endif
// *******************************************************************************************************************************************

// Define this to use the vectorized version of grid assignment, written by L. Tornatore.
// That version has some memmory issues depending on the computer the code is run at.
// If undef, the code uses my own version which is  efficient enough
// IMPORTANT: when using the standar assignment, I demand here to specify whether PSC
// is to be used, in order to speed the code. I will set a warning in the parameter  file
//#define _USE_VECTORIZED_GRID_ASSIGNMENT_
#ifndef _USE_VECTORIZED_GRID_ASSIGNMENT_
#define MAX_MAS_DEG 5
#define MAX_MAS_DEG_TSC 3
#define CHUNK MAX_MAS_DEG*MAX_MAS_DEG*MAX_MAS_DEG   // this is 5*5*5
#endif


#define KMAX_RESIDUALS_high static_cast<real_prec>(0.5)
#define KMAX_RESIDUALS_low static_cast<real_prec>(0.3)



// ********************************************************************************************************************************************
// ********************************************************************************************************************************************
// ********************************************************************************************************************************************

//BASIC DEFINITIONS
////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// FOURIER
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//#define FOURIER_DEF_1  // only tested with DEF_2
#define FOURIER_DEF_2  // only tested with DEF_2
#define FFTW_OPTION FFTW_ESTIMATE
#define FORWARD FFTW_FORWARD
#define BACKWARD FFTW_BACKWARD
//#define fwd true
//#define inv false
#define fourier_space true
#define real_space false
#define to_Fspace true
#define to_Rspace false
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define _CONVERT_MPC_per_H_TO_KM_per_SECOND_

#define cgs_Mpc num_1
#define cgs_sec num_1
#define cgs_km static_cast<real_prec>(0.3240779290e-19 * cgs_Mpc) // 1 kilometer in 1 Mpc
#define cgs_clight static_cast<real_prec>(0.9715611892e-14 * cgs_Mpc/cgs_sec)

#define eps static_cast<real_prec>(1.e-14)
#define epsint static_cast<real_prec>(1.0e-6) /* numerical accuracy for integrations */
#define NEVAL 1000    /* numerical integration a2com */

#define _MESS_ So.message_screen("ABA", __LINE__);
#define _ACHTUNG_ So.message_warning("ACHTUNG in line ", __LINE__);



// ========================================================================================

// Define if Y is in NGP and want to be converted to CIC in order to smooth contours.
//By default
//#define  _KONV_

#ifdef BIAS_MODE
// Use this to convert NGP to CIC when using number counts in the tracers and want to display the bias
//#define  _NGP2CIC_Y_

//Uset this to convolve the DM with a kernel, which is read from the output directory
//#define  _KONV_




//define if a mask containig redshifts is to be used for bias analysis involving reconstrunction
//#define _USE_REDSHIFT_MASK_

//#define _USE_BINARY_MASK_  // if the file binary_mask is 1 or 0, define this. If not, do not use it



#ifdef _USE_REDSHIFT_MASK_
//#define REDSHIFT_MIN static_cast<real_prec>(0.35)
//#define REDSHIFT_MAX static_cast<real_prec>(2.34)
//#define N_REDSHIFT_BINS static_cast<int>(9)
#define REDSHIFT_MIN static_cast<real_prec>(0)
#define REDSHIFT_MAX static_cast<real_prec>(5)
#define N_REDSHIFT_BINS static_cast<int>(1)

#define DELTA_Z static_cast<real_prec>((REDSHIFT_MAX-REDSHIFT_MIN)/static_cast<real_prec>(N_REDSHIFT_BINS))
#endif

#ifndef _USE_REDSHIFT_MASK_
#define N_REDSHIFT_BINS 1
#endif

#else
#define N_REDSHIFT_BINS 1
#endif



#define __use_new_loops_bias_
//#define _use_random_kernel_  //derpecated

//#define _SHOW_EMPTY_CELLS_


#define DENSITY "density"

// The values are used to get cosmological functions to interpolate upon when using the power spectrum code,
#define Z_MAX static_cast<real_prec>(0.5)
#define Z_MIN static_cast<real_prec>(0)


// if this is defined a test chaning the Invariantes for input foriles from the hydro project is done
//#define _HYDROTEST_





// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************

#ifdef _USE_TIWEB_
#if defined (_USE_CWEB_) || defined (_USE_TWEB_) || defined (_USE_IWEB_) || defined (_USE_IKWEB_) || defined (_USE_PWEB_) || defined (_USE_CWEB_V_) || defined (_USE_TWEB_V_) || defined  (_USE_IWEB_V_) || defined  (_USE_AWEB_) 
#define WARNING_MODELS true
#else
#define WARNING_MODELS false
#endif



#elif defined _USE_CWEB_
#if defined (_USE_TWEB_) || defined (_USE_IWEB_) || defined (_USE_IKWEB_) || defined (_USE_PWEB_) || defined (_USE_CWEB_V_) || defined (_USE_TWEB_V_) || defined  (_USE_IWEB_V_) || defined  (_USE_AWEB_) 
#define WARNING_MODELS true
#else
#define WARNING_MODELS false
#endif

#elif defined _USE_TWEB_
#if defined (_USE_IWEB_) || defined (_USE_IKWEB_) || defined (_USE_PWEB_) || defined (_USE_CWEB_V_) || defined (_USE_TWEB_V_) || defined  (_USE_IWEB_V_) || defined  (_USE_AWEB_) 
#define WARNING_MODELS true
#else
#define WARNING_MODELS false
#endif

#elif defined _USE_IWEB_
#if defined (_USE_IKWEB_) || defined (_USE_PWEB_) || defined (_USE_CWEB_V_) || defined (_USE_TWEB_V_) || defined  (_USE_IWEB_V_) || defined  (_USE_AWEB_) 
#define WARNING_MODELS true
#else
#define WARNING_MODELS false
#endif


#elif defined _USE_IKWEB_
#if defined (_USE_PWEB_) || defined (_USE_CWEB_V_) || defined (_USE_TWEB_V_) || defined  (_USE_IWEB_V_) || defined  (_USE_AWEB_) 
#define WARNING_MODELS true
#else
#define WARNING_MODELS false
#endif

#elif defined _USE_PWEB_
#if defined (_USE_CWEB_V_) || defined (_USE_TWEB_V_) || defined  (_USE_IWEB_V_) || defined  (_USE_AWEB_) 
#define WARNING_MODELS true
#else
#define WARNING_MODELS false
#endif

#elif defined _USE_CWEB_V_
#if defined (_USE_TWEB_V_) || defined  (_USE_IWEB_V_) || defined  (_USE_AWEB_) 
#define WARNING_MODELS true
#else
#define WARNING_MODELS false
#endif

#elif defined _USE_TWEB_V_
#if defined (_USE_IWEB_V_) || defined  (_USE_AWEB_) 
#define WARNING_MODELS true
#else
#define WARNING_MODELS false
#endif

#elif defined _USE_IWEB_V_
#if defined  (_USE_AWEB_) 
#define WARNING_MODELS true
#else
#define WARNING_MODELS false
#endif


#elif defined _USE_AWEB_
#if defined (_USE_CWEB_) || defined (_USE_TWEB_) || defined (_USE_IWEB_) || defined (_USE_IKWEB_) || defined (_USE_PWEB_) || defined (_USE_CWEB_V_) || defined  (_USE_TWEB_V_) || defined  (_USE_IWEB_V_) 
#define WARNING_MODELS true
#else
#define WARNING_MODELS false
#endif


#endif


// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
// ****************************************************************************************
